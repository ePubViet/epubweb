-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 18, 2014 at 03:31 AM
-- Server version: 5.5.38
-- PHP Version: 5.5.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `epw_sphere`
--

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_assets`
--

CREATE TABLE IF NOT EXISTS `zjw8d_assets` (
`id` int(10) unsigned NOT NULL COMMENT 'Primary Key',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set parent.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `level` int(10) unsigned NOT NULL COMMENT 'The cached level in the nested tree.',
  `name` varchar(50) NOT NULL COMMENT 'The unique name for the asset.\n',
  `title` varchar(100) NOT NULL COMMENT 'The descriptive title for the asset.',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=84 ;

--
-- Dumping data for table `zjw8d_assets`
--

INSERT INTO `zjw8d_assets` (`id`, `parent_id`, `lft`, `rgt`, `level`, `name`, `title`, `rules`) VALUES
(1, 0, 1, 519, 0, 'root.1', 'Root Asset', '{"core.login.site":{"6":1,"2":1},"core.login.admin":{"6":1},"core.login.offline":[],"core.admin":{"8":1},"core.manage":{"7":1},"core.create":{"6":1,"3":1},"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(2, 1, 1, 2, 1, 'com_admin', 'com_admin', '{}'),
(3, 1, 3, 6, 1, 'com_banners', 'com_banners', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(4, 1, 7, 8, 1, 'com_cache', 'com_cache', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(5, 1, 9, 10, 1, 'com_checkin', 'com_checkin', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(6, 1, 11, 12, 1, 'com_config', 'com_config', '{}'),
(7, 1, 13, 18, 1, 'com_contact', 'com_contact', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(8, 1, 19, 82, 1, 'com_content', 'com_content', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1},"core.edit.own":[]}'),
(9, 1, 83, 84, 1, 'com_cpanel', 'com_cpanel', '{}'),
(10, 1, 85, 86, 1, 'com_installer', 'com_installer', '{"core.admin":{"7":1},"core.manage":{"7":1},"core.delete":[],"core.edit.state":[]}'),
(11, 1, 87, 88, 1, 'com_languages', 'com_languages', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(12, 1, 89, 90, 1, 'com_login', 'com_login', '{}'),
(13, 1, 91, 92, 1, 'com_mailto', 'com_mailto', '{}'),
(14, 1, 93, 94, 1, 'com_massmail', 'com_massmail', '{}'),
(15, 1, 95, 96, 1, 'com_media', 'com_media', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":{"5":1}}'),
(16, 1, 97, 98, 1, 'com_menus', 'com_menus', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(17, 1, 99, 100, 1, 'com_messages', 'com_messages', '{"core.admin":{"7":1},"core.manage":{"7":1}}'),
(18, 1, 101, 102, 1, 'com_modules', 'com_modules', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(19, 1, 103, 106, 1, 'com_newsfeeds', 'com_newsfeeds', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(20, 1, 107, 108, 1, 'com_plugins', 'com_plugins', '{"core.admin":{"7":1},"core.manage":[],"core.edit":[],"core.edit.state":[]}'),
(21, 1, 109, 110, 1, 'com_redirect', 'com_redirect', '{"core.admin":{"7":1},"core.manage":[]}'),
(22, 1, 111, 112, 1, 'com_search', 'com_search', '{"core.admin":{"7":1},"core.manage":{"6":1}}'),
(23, 1, 113, 114, 1, 'com_templates', 'com_templates', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(24, 1, 115, 116, 1, 'com_users', 'com_users', '{"core.admin":{"7":1},"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.own":{"6":1},"core.edit.state":[]}'),
(25, 1, 117, 122, 1, 'com_weblinks', 'com_weblinks', '{"core.admin":{"7":1},"core.manage":{"6":1},"core.create":{"3":1},"core.delete":[],"core.edit":{"4":1},"core.edit.state":{"5":1},"core.edit.own":[]}'),
(26, 1, 123, 124, 1, 'com_wrapper', 'com_wrapper', '{}'),
(27, 8, 20, 61, 2, 'com_content.category.2', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(28, 3, 4, 5, 2, 'com_banners.category.3', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(29, 7, 14, 15, 2, 'com_contact.category.4', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(30, 19, 104, 105, 2, 'com_newsfeeds.category.5', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(31, 25, 118, 119, 2, 'com_weblinks.category.6', 'Uncategorised', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(32, 8, 62, 75, 2, 'com_content.category.7', 'Blog', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(33, 27, 21, 22, 3, 'com_content.article.1', 'Module Variations', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(34, 27, 23, 24, 3, 'com_content.article.2', 'Icons', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(35, 27, 25, 26, 3, 'com_content.article.3', 'ZOO', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(36, 27, 27, 28, 3, 'com_content.article.4', 'Typography', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(37, 27, 29, 30, 3, 'com_content.article.5', 'Dummy Content', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(38, 27, 31, 32, 3, 'com_content.article.6', 'Features', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(39, 27, 33, 34, 3, 'com_content.article.7', 'Master Theme', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(40, 32, 63, 64, 3, 'com_content.article.8', 'Joomla Templates', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(41, 32, 65, 66, 3, 'com_content.article.9', 'Beautiful Icons', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(42, 32, 67, 68, 3, 'com_content.article.10', 'Warp Theme Framework', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(43, 32, 69, 70, 3, 'com_content.article.11', 'ZOO Extension', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(44, 32, 71, 72, 3, 'com_content.article.12', 'Free Social Icons', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(47, 27, 37, 38, 3, 'com_content.article.14', 'Slideshow', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(48, 27, 39, 40, 3, 'com_content.article.15', 'Lightbox', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(49, 27, 41, 42, 3, 'com_content.article.16', 'Spotlight', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(50, 27, 43, 44, 3, 'com_content.article.17', 'Twitter', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(51, 27, 45, 46, 3, 'com_content.article.18', 'Media Player', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(52, 27, 47, 48, 3, 'com_content.article.19', 'Gallery', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(53, 27, 49, 50, 3, 'com_content.article.20', 'Map', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(54, 27, 51, 52, 3, 'com_content.article.21', 'Accordion', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(55, 27, 53, 54, 3, 'com_content.article.22', 'Slideset', '{"core.delete":[],"core.edit":[],"core.edit.state":[]}'),
(56, 7, 16, 17, 2, 'com_contact.category.8', 'Contacts', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(57, 25, 120, 121, 2, 'com_weblinks.category.9', 'YOOtheme Links', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(59, 1, 480, 481, 1, 'com_finder', 'com_finder', '{"core.admin":[],"core.manage":[]}'),
(63, 1, 484, 485, 1, 'com_joomlaupdate', 'com_joomlaupdate', '{"core.admin":{"8":1},"core.manage":{"7":1},"core.delete":{"6":1},"core.edit.state":{"6":1,"5":1}}'),
(64, 8, 76, 77, 2, 'com_content.category.10', 'Giới thiệu chung', '{"core.create":{"6":1,"3":1},"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1},"core.edit.own":{"6":1,"3":1}}'),
(65, 1, 486, 487, 1, 'com_sh404sef', 'sh404sef', '{"core.admin":[],"core.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(66, 8, 78, 81, 2, 'com_content.category.11', 'sh404SEF custom content', ''),
(67, 66, 79, 80, 3, 'com_content.article.24', '__404__', ''),
(68, 27, 59, 60, 3, 'com_content.article.25', 'Giới thiệu', '{"core.delete":{"6":1},"core.edit":{"6":1,"4":1},"core.edit.state":{"6":1,"5":1}}'),
(69, 1, 488, 511, 1, 'com_zoo', 'com_zoo', '{}'),
(70, 69, 489, 492, 2, 'com_zoo.application.1', 'Bài viết đơn', '{"core.admin":[],"core.manage":[],"zoo.categories.manage":[],"zoo.comments.manage":[],"zoo.frontpage.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(71, 70, 490, 491, 3, 'com_zoo.application.1.page', 'Bài viết đơn (Page)', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(72, 69, 493, 498, 2, 'com_zoo.application.2', 'Liên hệ', '{"core.admin":[],"core.manage":[],"zoo.categories.manage":[],"zoo.comments.manage":[],"zoo.frontpage.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(73, 72, 494, 495, 3, 'com_zoo.application.2.company', 'Liên hệ (Company)', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(74, 72, 496, 497, 3, 'com_zoo.application.2.employee', 'Liên hệ (Employee)', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(75, 69, 499, 508, 2, 'com_zoo.application.3', 'Sách truyện', '{"core.admin":[],"core.manage":[],"zoo.categories.manage":[],"zoo.comments.manage":[],"zoo.frontpage.manage":[],"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(76, 75, 500, 501, 3, 'com_zoo.application.3.movie', 'Sách truyện (Movie)', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(77, 75, 502, 503, 3, 'com_zoo.application.3.person', 'Sách truyện (Person)', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(78, 75, 504, 505, 3, 'com_zoo.application.3.tac.gia', 'Sách truyện (Tac-gia)', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(79, 75, 506, 507, 3, 'com_zoo.application.3.tac.pham', 'Sách truyện (Tac-pham)', '{"core.create":[],"core.delete":[],"core.edit":[],"core.edit.state":[],"core.edit.own":[]}'),
(80, 69, 509, 510, 2, 'com_zoo.application.4', 'Văn hóa đọc', '[]'),
(81, 1, 513, 514, 1, 'com_widgetkit', 'com_widgetkit', '{"core.manage":{"7":1}}'),
(82, 1, 515, 516, 1, 'com_cmc', 'com_cmc', '{"core.admin":[],"core.manage":[]}'),
(83, 1, 517, 518, 1, 'com_kunena', 'com_kunena', '{}');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_associations`
--

CREATE TABLE IF NOT EXISTS `zjw8d_associations` (
  `id` int(11) NOT NULL COMMENT 'A reference to the associated item.',
  `context` varchar(50) NOT NULL COMMENT 'The context of the associated item.',
  `key` char(32) NOT NULL COMMENT 'The key for the association computed from an md5 on associated ids.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_banners`
--

CREATE TABLE IF NOT EXISTS `zjw8d_banners` (
`id` int(11) NOT NULL,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `clickurl` varchar(200) NOT NULL DEFAULT '',
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `custombannercode` varchar(2048) NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `params` text NOT NULL,
  `own_prefix` tinyint(1) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reset` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `language` char(7) NOT NULL DEFAULT '',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `version` int(10) unsigned NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_banner_clients`
--

CREATE TABLE IF NOT EXISTS `zjw8d_banner_clients` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `extrainfo` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `metakey` text NOT NULL,
  `own_prefix` tinyint(4) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(255) NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_banner_tracks`
--

CREATE TABLE IF NOT EXISTS `zjw8d_banner_tracks` (
  `track_date` datetime NOT NULL,
  `track_type` int(10) unsigned NOT NULL,
  `banner_id` int(10) unsigned NOT NULL,
  `count` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_categories`
--

CREATE TABLE IF NOT EXISTS `zjw8d_categories` (
`id` int(11) NOT NULL,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `extension` varchar(50) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned DEFAULT NULL,
  `params` text NOT NULL,
  `metadesc` varchar(1024) NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `zjw8d_categories`
--

INSERT INTO `zjw8d_categories` (`id`, `asset_id`, `parent_id`, `lft`, `rgt`, `level`, `path`, `extension`, `title`, `alias`, `note`, `description`, `published`, `checked_out`, `checked_out_time`, `access`, `params`, `metadesc`, `metakey`, `metadata`, `created_user_id`, `created_time`, `modified_user_id`, `modified_time`, `hits`, `language`, `version`) VALUES
(1, 0, 0, 0, 21, 0, '', 'system', 'ROOT', 'root', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{}', '', '', '', 390, '2009-10-18 16:07:09', 0, '0000-00-00 00:00:00', 0, '*', 1),
(2, 27, 1, 1, 2, 1, 'uncategorised', 'com_content', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 390, '2010-06-28 13:26:37', 0, '0000-00-00 00:00:00', 0, '*', 1),
(3, 28, 1, 3, 4, 1, 'uncategorised', 'com_banners', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":"","foobar":""}', '', '', '{"page_title":"","author":"","robots":""}', 390, '2010-06-28 13:27:35', 0, '0000-00-00 00:00:00', 0, '*', 1),
(4, 29, 1, 5, 6, 1, 'uncategorised', 'com_contact', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 390, '2010-06-28 13:27:57', 0, '0000-00-00 00:00:00', 0, '*', 1),
(5, 30, 1, 7, 8, 1, 'uncategorised', 'com_newsfeeds', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 390, '2010-06-28 13:28:15', 0, '0000-00-00 00:00:00', 0, '*', 1),
(6, 31, 1, 9, 10, 1, 'uncategorised', 'com_weblinks', 'Uncategorised', 'uncategorised', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"target":"","image":""}', '', '', '{"page_title":"","author":"","robots":""}', 390, '2010-06-28 13:28:33', 0, '0000-00-00 00:00:00', 0, '*', 1),
(7, 32, 1, 11, 12, 1, 'blog', 'com_content', 'Blog', 'blog', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 390, '2011-05-02 11:42:21', 0, '0000-00-00 00:00:00', 0, '*', 1),
(8, 56, 1, 13, 14, 1, 'contacts', 'com_contact', 'Contacts', 'contacts', '', '', 1, 42, '2012-01-23 15:30:29', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 390, '2011-11-18 16:32:10', 42, '2011-11-18 16:32:13', 0, '*', 1),
(9, 57, 1, 15, 16, 1, 'yootheme-links', 'com_weblinks', 'YOOtheme Links', 'yootheme-links', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 390, '2012-01-22 12:45:00', 0, '0000-00-00 00:00:00', 0, '*', 1),
(10, 64, 1, 17, 18, 1, 'gioi-thieu-chung', 'com_content', 'Giới thiệu chung', 'gioi-thieu-chung', '', '', 1, 0, '0000-00-00 00:00:00', 1, '{"category_layout":"","image":""}', '', '', '{"author":"","robots":""}', 584, '2014-09-17 08:22:36', 584, '2014-09-17 08:23:09', 0, '*', 1),
(11, 66, 1, 19, 20, 1, 'sh404sef-custom-content', 'com_content', 'sh404SEF custom content', 'sh404sef-custom-content', '', 'Do not delete please!', 1, 0, '0000-00-00 00:00:00', 1, '', '', '', '', 584, '2014-09-17 08:32:30', 0, '0000-00-00 00:00:00', 0, '*', 1);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_cmc_lists`
--

CREATE TABLE IF NOT EXISTS `zjw8d_cmc_lists` (
`id` int(11) NOT NULL,
  `mc_id` varchar(10) NOT NULL,
  `web_id` int(11) NOT NULL,
  `list_name` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL,
  `email_type_option` tinyint(1) NOT NULL DEFAULT '0',
  `use_awesomebar` tinyint(1) NOT NULL DEFAULT '1',
  `default_from_name` varchar(255) NOT NULL,
  `default_from_email` varchar(255) NOT NULL,
  `default_subject` varchar(255) DEFAULT NULL,
  `default_language` varchar(10) NOT NULL DEFAULT 'en',
  `list_rating` float(5,4) NOT NULL DEFAULT '0.0000',
  `subscribe_url_short` varchar(255) NOT NULL,
  `subscribe_url_long` varchar(255) NOT NULL,
  `beamer_address` varchar(255) NOT NULL,
  `visibility` varchar(255) NOT NULL DEFAULT 'pub',
  `created_user_id` int(11) NOT NULL,
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(11) NOT NULL,
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) NOT NULL DEFAULT '0',
  `query_data` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_cmc_register`
--

CREATE TABLE IF NOT EXISTS `zjw8d_cmc_register` (
`id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `params` text NOT NULL,
  `plg` tinyint(2) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_cmc_users`
--

CREATE TABLE IF NOT EXISTS `zjw8d_cmc_users` (
`id` int(11) NOT NULL,
  `mc_id` varchar(255) DEFAULT NULL,
  `list_id` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(500) DEFAULT NULL,
  `email` varchar(500) NOT NULL,
  `email_type` varchar(500) NOT NULL DEFAULT 'html',
  `interests` text,
  `merges` text,
  `status` varchar(255) NOT NULL DEFAULT 'subscribed',
  `ip_signup` varchar(255) DEFAULT NULL,
  `timestamp_signup` datetime NOT NULL,
  `ip_opt` varchar(255) DEFAULT NULL,
  `timestamp_opt` datetime NOT NULL,
  `member_rating` tinyint(2) NOT NULL DEFAULT '2',
  `campaign_id` int(11) NOT NULL,
  `lists` varchar(255) DEFAULT NULL,
  `timestamp` datetime NOT NULL,
  `info_changed` datetime NOT NULL,
  `web_id` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT 'en',
  `is_gmonkey` tinyint(1) NOT NULL DEFAULT '0',
  `geo` text COMMENT 'json',
  `clients` text COMMENT 'json',
  `static_segments` text COMMENT 'json',
  `created_user_id` int(11) NOT NULL,
  `created_time` datetime NOT NULL,
  `modified_user_id` int(11) NOT NULL,
  `modified_time` datetime NOT NULL,
  `query_data` text COMMENT 'json'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_contact_details`
--

CREATE TABLE IF NOT EXISTS `zjw8d_contact_details` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `con_position` varchar(255) DEFAULT NULL,
  `address` text,
  `suburb` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `misc` mediumtext,
  `image` varchar(255) DEFAULT NULL,
  `email_to` varchar(255) DEFAULT NULL,
  `default_con` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned DEFAULT NULL,
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `webpage` varchar(255) NOT NULL DEFAULT '',
  `sortname1` varchar(255) NOT NULL,
  `sortname2` varchar(255) NOT NULL,
  `sortname3` varchar(255) NOT NULL,
  `language` char(7) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `zjw8d_contact_details`
--

INSERT INTO `zjw8d_contact_details` (`id`, `name`, `alias`, `con_position`, `address`, `suburb`, `state`, `country`, `postcode`, `telephone`, `fax`, `misc`, `image`, `email_to`, `default_con`, `published`, `checked_out`, `checked_out_time`, `ordering`, `params`, `user_id`, `catid`, `access`, `mobile`, `webpage`, `sortname1`, `sortname2`, `sortname3`, `language`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `metakey`, `metadesc`, `metadata`, `featured`, `xreference`, `publish_up`, `publish_down`, `version`, `hits`) VALUES
(1, 'John Q. Public', 'john-q-public', 'Chief Information Officer', '1 Infinite Loop', 'Cupertino', 'California', 'USA', '95014', '1-212-555555-1', '1-212-555555-2', 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.', '', 'email@0.0.0.0', 0, 1, 0, '0000-00-00 00:00:00', 1, '{"show_contact_category":"","show_contact_list":"","presentation_style":"","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_profile":"","show_links":"","linka_name":"","linka":"","linkb_name":"","linkb":"","linkc_name":"","linkc":"","linkd_name":"","linkd":"","linke_name":"","linke":"","contact_layout":"","show_email_form":"","show_email_copy":"","banned_email":"","banned_subject":"","banned_text":"","validate_session":"","custom_reply":"","redirect":""}', 0, 8, 1, '', '', '', '', '', '*', '2011-11-18 16:33:47', 390, '', '2012-01-23 15:36:01', 42, '', '', '{"robots":"","rights":""}', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0),
(2, 'Jane Q. Public', 'jane-q-public', 'Chief Information Officer', '1 Infinite Loop', 'Cupertino', 'California', 'USA', '95014', '1-212-555555-1', '1-212-555555-2', 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.', '', 'email@0.0.0.0', 0, 1, 0, '0000-00-00 00:00:00', 2, '{"show_contact_category":"","show_contact_list":"","presentation_style":"","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_profile":"","show_links":"","linka_name":"","linka":"","linkb_name":"","linkb":"","linkc_name":"","linkc":"","linkd_name":"","linkd":"","linke_name":"","linke":"","contact_layout":"","show_email_form":"","show_email_copy":"","banned_email":"","banned_subject":"","banned_text":"","validate_session":"","custom_reply":"","redirect":""}', 0, 8, 1, '', '', '', '', '', '*', '2011-11-18 16:35:05', 390, '', '2012-01-19 16:37:23', 42, '', '', '{"robots":"","rights":""}', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_content`
--

CREATE TABLE IF NOT EXISTS `zjw8d_content` (
`id` int(10) unsigned NOT NULL,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` varchar(5120) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `language` char(7) NOT NULL COMMENT 'The language code for the article.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `zjw8d_content`
--

INSERT INTO `zjw8d_content` (`id`, `asset_id`, `title`, `alias`, `introtext`, `fulltext`, `state`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `featured`, `language`, `xreference`) VALUES
(1, 33, 'Module Variations', 'module-variations', '<p>This theme comes with different module styles, badges and icons. For each module you can pick a style and combine it with an icon or badge to create your own unique look. Here is a list of the available options:</p>\r\n\r\n<table class="zebra">\r\n  <tbody>\r\n    <tr class="odd">\r\n      <td class="bold">Styles</td>\r\n      <td>Box, line, Inset, Corner</td>\r\n    </tr>\r\n    <tr>\r\n      <td class="bold">Badges</td>\r\n      <td>Hot, New, Free, Top</td>\r\n    </tr>\r\n    <tr class="odd">\r\n      <td class="bold">Icons</td>\r\n      <td>Download, Twitter, Mail, Bubble, Login, Cart, Plus, Arrow, Box, Rss</td>\r\n    </tr>\r\n  </tbody>\r\n</table>', '', 1, 2, '2011-05-02 11:45:23', 390, '', '2012-07-24 11:47:14', 42, 0, '0000-00-00 00:00:00', '2011-05-02 11:45:23', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 5, 11, '', '', 1, 1467, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(2, 34, 'Icons', 'icons', '<div>\r\n\r\n  <p>YOOtheme is a well-known template and extension provider for Joomla and WordPress who helps you to create professional websites. But to make your website or interface design a real eye-catcher we had one thing missing: Icons! Icons are an essential tool to simplify user interfaces and today almost every major website uses icons to highlight important parts in their content.</p>\r\n\r\n  <p>This is why we created a great resource of beautiful and handcrafted icons for web and print projects. We got commercial icon sets including e-commerce, community, file and folder icons and many more as well as many freebies.</p>\r\n\r\n  <p>As a member of our icon club you will get access to hundreds of handcrafted and detailed icons. New icon sets are added continuously!</p>\r\n\r\n</div>\r\n\r\n\r\n<div>\r\n\r\n  <div class="box-content bfc-o remove-margin">\r\n\r\n    <img class="size-auto align-left" width="200" height="280" src="images/yootheme/icons_club.png"/>\r\n\r\n    <div class="bfc-o">\r\n\r\n      <h2 class="remove-margin-t">Club Icons</h2>\r\n\r\n      <ul class="check">\r\n        <li>Pixel perfect design</li>\r\n        <li>PNGs in 8 sizes from 16x16 to 512x512 pixels</li>\r\n        <li>Handmade and optimized for each size</li>\r\n        <li>Scalable vector sources</li>\r\n        <li>Change the colors and customize easily</li>\r\n      </ul>\r\n\r\n    </div>\r\n    <p><a class="button-default" href="http://www.yootheme.com/icons" target="_blank">Visit Website</a></p>\r\n        \r\n  </div>\r\n\r\n</div>\r\n\r\n', '', 1, 2, '2011-05-02 11:47:01', 390, '', '2012-06-29 13:17:25', 42, 0, '0000-00-00 00:00:00', '2011-05-02 11:47:01', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 32, 12, '', '', 1, 172, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(3, 35, 'ZOO', 'zoo', '<a class="align-right" data-lightbox="width:852;height:480;autoplay:true;" href="http://www.yootheme.com/videos/zoo_video_tour.mp4"><img class="size-auto" src="images/yootheme/zoo_video_tour.png" width="250" height="110" alt="Take the video tour on the ZOO!" title="Take the video tour on the ZOO!" /></a>\r\n\r\n<p>ZOO is a flexible and powerful content application builder to manage your content. It provides a much improved Joomla experience. The key feature is the ability to create your very own custom content types. You define what a type is made up of - e.g. text, images or a file download. Any combination is imaginable! You bring the content, ZOO brings the elements to structure it and make it look good!</p>\r\n\r\n<h2>Apps for every Purpose</h2>\r\n\r\n<p>ZOO moves from simply being a CCK to an Application Builder. Apps are extensions for ZOO which are optimized for different purposes and types of content catalogs. ZOO offers a wide range of apps to get you started right away. There is a blog, a product catalog, a cookbook, a business directory, a documentation, a download archive and a movie database app!</p>\r\n\r\n<img class="size-auto align-center" src="images/yootheme/zoo_apps.png" width="635" height="219" alt="ZOO Apps for every Purpose" title="ZOO Apps for every Purpose" />\r\n\r\n<h2>Joomla Integration</h2>\r\n\r\n<p>By now ZOO has developed a thriving ecosystem, with new ZOO extensions appearing regularly. It also integrates well with many popular Joomla extensions. Besides the ZOO component itself offers additional modules and plugins. They allow a seamless integration into Joomla and provide a richer tool set to create your website.</p>\r\n\r\n<a class="button-default" href="http://www.yootheme.com/zoo" target="_blank">Visit Website</a>', '', 1, 2, '2011-05-02 11:47:22', 390, '', '2012-06-05 09:11:17', 42, 0, '0000-00-00 00:00:00', '2011-05-02 11:47:22', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 6, 13, '', '', 1, 70, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(4, 36, 'Typography', 'typography', '<p>You can create some beautiful content by using some simple HTML elements. The Warp theme framework offers some neat styles for all HTML elements and a great set of CSS classes to style your content. Basic HTML is very easy to learn and this small guide shows you how to use all styles provided by the Warp framework.</p>\r\n\r\n<h2>Basic HTML Elements</h2>\r\n\r\n<p>Here is a short demonstration of text-level semanticts. The &lt;p&gt; element creates a new paragraph. It will have some space before and after itself. To turn your text into hypertext just use the <a href="#">&lt;a&gt; element</a>.</p>\r\n\r\n<h3>Text-Level Semantics</h3>\r\n\r\n<p>You can emphasize text using the <em>&lt;em&gt; element</em> or to imply any extra importance the <strong>&lt;strong&gt; element</strong>. Highlight text with no semantic meaning using the <mark>&lt;mark&gt; element</mark>. Markup document changes like inserted or deleted text with the <del>&lt;del&gt; element</del> or <ins>&lt;ins&gt; element</ins>. To define an abbreviation use the <abbr title="Abbreviation Element">&lt;abbr&gt; element</abbr> and to define a definition term use the <dfn title="Defines a definition term">&lt;dfn&gt; element</dfn>.</p>\r\n\r\n<h3>Short List with Links</h3>\r\n\r\n<ul>\r\n	<li><a href="http://www.yootheme.com" target="_blank">YOOtheme</a> - Premium Joomla Templates and WordPress Themes</li>\r\n	<li><a href="http://www.yootheme.com/warp" target="_blank">Warp Framework</a> - Fast and Slick Theme Framework</li>\r\n	<li><a href="http://www.yootheme.com/zoo" target="_blank">ZOO</a> - Content Application Builder</li>\r\n	<li><a href="http://www.yootheme.com/icons" target="_blank">Stock Icons</a> - For Web and Print Projects</li>\r\n</ul>\r\n\r\n<h3>Quotations and Code</h3>\r\n\r\n<p>Inline quotations can be defined by using the <q>&lt;q&gt; element</q>.</p>\r\n\r\n<blockquote>The &lt;blockquote&gt; element defines a long quotation which also creates a new block by inserting white space before and after the blockquote element.</blockquote>\r\n\r\n<p>To define a short inline computer code use the <code>&lt;code&gt; element</code>. For a larger code snippet use the &lt;pre&gt; element which defines preformatted text. It creates a new text block which preserves both spaces and line breaks.</p>\r\n\r\n<pre>\r\npre {\r\n    margin: 15px 0;\r\n    padding: 10px;\r\n    font-family: "Courier New", Courier, monospace;\r\n    font-size: 12px;\r\n    line-height: 18px;\r\n    white-space: pre-wrap;\r\n}\r\n</pre>\r\n\r\n<small>Use the &lt;small&gt; element for side comments and small print.</small>\r\n\r\n<hr />\r\n\r\n<h2>Useful CSS Classes</h2>\r\n\r\n<p>Here is a short demonstration of all style related CSS classes provided by the Warp framework.</p>\r\n\r\n<h3>Highlight Content</h3>\r\n\r\n<p class="dropcap">Drop caps are the first letter of a paragraph which are displayed bigger than the rest of the text. You can create a drop cap using the CSS class <code>dropcap</code>. To emphasize text with some small boxes use <em class="box">&lt;em&gt; element</em> with the CSS class <code>box</code>.</p>\r\n\r\n<div class="box-content">This simple box is intended to group large parts of your content using the CSS class <code>box-content</code>.</div>\r\n<div class="box-note">This is a simple box to highlight some text using the CSS class <code>box-note</code>.</div>\r\n<div class="box-info">This is a simple box with useful information using the CSS class <code>box-info</code>.</div>\r\n<div class="box-warning">This is a simple box with important notes and warnings using the CSS class <code>box-warning</code>.</div>\r\n<div class="box-hint">This is a simple box with additional hints using the CSS class <code>box-hint</code>.</div>\r\n<div class="box-download">This is a simple box with download information using the CSS class <code>box-download</code>.</div>\r\n\r\n<p>Use the CSS class <code>dotted</code> to create a dotted horizontal rule.</p>\r\n\r\n<hr class="dotted" />\r\n\r\n<h3>Tables</h3>\r\n\r\n<p>Create a zebra stripped table using using the CSS class <code>zebra</code>.</p>\r\n\r\n<table class="zebra">\r\n	<caption>Table caption</caption>\r\n	<thead>\r\n		<tr>\r\n			<th>Table Heading</th>\r\n			<th>Table Heading</th>\r\n			<th class="center">Table Heading</th>\r\n		</tr>\r\n	</thead>\r\n	<tfoot>\r\n		<tr>\r\n			<td>Table Footer</td>\r\n			<td>Table Footer</td>\r\n			<td class="center">Table Footer</td>\r\n		</tr>\r\n	</tfoot>\r\n	<tbody>\r\n		<tr class="odd">\r\n			<td>Table Data</td>\r\n			<td>Table Data</td>\r\n			<td class="center">Data Centered</td>\r\n		</tr>\r\n		<tr>\r\n			<td class="bold">Data Bold</td>\r\n			<td>Table Data</td>\r\n			<td class="center">Data Centered</td>\r\n		</tr>\r\n		<tr class="odd">\r\n			<td>Table Data</td>\r\n			<td>Table Data</td>\r\n			<td class="center">Data Centered</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<h3>Definition Lists</h3>\r\n\r\n<p>Create a nice looking definition list separated with a line by using the CSS class <code>separator</code>.</p>\r\n\r\n<dl class="separator">\r\n	<dt>Definition List</dt>\r\n	<dd>A definition list is a list of terms and corresponding definitions. To create a definition list use the &lt;dl&gt; element in conjunction with &lt;dt&gt; to define the definition term and &lt;dd&gt; to define the definition description.</dd>\r\n	<dt>Definition Term</dt>\r\n	<dd>This is a definition description.</dd>\r\n	<dt>Definition Term</dt>\r\n	<dd>This is a definition description.</dd>\r\n	<dd>This is another definition description.</dd>\r\n</dl>\r\n\r\n<h3>Forms</h3>\r\n\r\n<p>Create a clearly arranged form layout with fieldset boxes using the CSS class <code>box</code>.</p>\r\n\r\n<form action="#" class="box style">\r\n\r\n	<fieldset>\r\n		<legend>Form legend</legend>\r\n		<div><label for="f1">Text input:</label> <input type="text" value="input text" id="f1"/></div>\r\n		<div><label for="f2">Radio input:</label> <input type="radio" id="f2"/></div>\r\n		<div><label for="f3">Checkbox input:</label> <input type="checkbox" id="f3"/></div>\r\n		<div><label for="f4">Select field:</label> <select id="f4"><option>Option 01</option><option>Option 02</option></select></div>\r\n		<div><label for="f5">Textarea:</label><br/><textarea rows="5" cols="30" id="f5">Textarea text</textarea></div>\r\n	</fieldset>\r\n	\r\n	<button>Button</button> <input type="button" value="Input Button" />\r\n	\r\n</form>', '', 1, 2, '2011-05-02 11:47:45', 390, '', '2012-06-07 07:28:09', 42, 0, '0000-00-00 00:00:00', '2011-05-02 11:47:45', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 5, 14, '', '', 1, 448, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(5, 37, 'Dummy Content', 'dummy-content', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '', 1, 2, '2011-05-02 11:48:08', 390, '', '2011-05-02 13:45:48', 42, 0, '0000-00-00 00:00:00', '2011-05-02 11:48:08', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":""}', 2, 15, '', '', 1, 107, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(6, 38, 'Features', 'features', '<p>This theme utilizes the latest features of the fast and slick Warp theme framework. It comes with a broad range of layout and <a href="index.php?option=com_content&amp;view=article&amp;id=1&amp;Itemid=103">module variations</a> as well as a neat <a href="index.php?option=com_content&amp;view=article&amp;id=4&amp;Itemid=104">typography</a> to style your content. Read on to learn more about this theme and its features:</p>\r\n\r\n<ul class="check">\r\n  <li>Available for Joomla and WordPress</li>\r\n  <li>8 style variations available</li>\r\n  <li>Choose from 9 fonts</li>\r\n  <li>4 module style combinable with 4 badges and 8 icons</li>\r\n  <li>Selectable background color for inner top and inner bottom</li>\r\n  <li>Flexible template and column widths</li>\r\n  <li>All Warp framework features are available</li>\r\n</ul>\r\n\r\n<h2>Theme Styles</h2>\r\n<p>We provide different style variations of the default theme. In addition to these styles we added several other style settings like colors and fonts. Combining the different style options allows you to create your own unique theme design.</p>\r\n<p><img class="size-auto" src="images/yootheme/features_style_settings.png" height="160" width="620" alt="Combinable Styles" title="" /></p>\r\n\r\n<h2>Theme Profiles</h2>\r\n<p>We created some nice theme profiles using the different styles, colors and fonts, you can choose from in the theme administration. You can create your own profiles and even assign them to different menu items. Click on one of the profile images to load it.</p>\r\n<div class="bfc-o text-center">\r\n  <a class="align-left" href="index.php?option=com_content&amp;view=article&amp;id=7&amp;Itemid=101&amp;profile=default">\r\n    <figure class="remove-margin-t">\r\n      <img class="size-auto" src="images/yootheme/features_profile01.png" width="190" height="150" alt="Load Profile White Noise" title=" Load Profile White Noise" />\r\n      <figcaption>White Noise</figcaption>\r\n    </figure>\r\n  </a>\r\n  <a class="align-left" href="index.php?option=com_content&amp;view=article&amp;id=7&amp;Itemid=101&amp;profile=blueprint">\r\n    <figure class="remove-margin-t">\r\n      <img class="size-auto" src="images/yootheme/features_profile02.png" width="190" height="150" alt="Load Profile Blueprint" title="Load Profile Blueprint" />\r\n      <figcaption>Blueprint</figcaption>\r\n    </figure>\r\n  </a>\r\n  <a class="align-left" href="index.php?option=com_content&amp;view=article&amp;id=7&amp;Itemid=101&amp;profile=beigepaper">\r\n    <figure class="remove-margin-t">\r\n      <img class="size-auto" src="images/yootheme/features_profile03.png" width="190" height="150" alt="Load Profile Beige Paper" title="Load Profile Beige Paper" />\r\n      <figcaption>Beige Paper</figcaption>\r\n    </figure>\r\n  </a>\r\n  <a class="align-left" href="index.php?option=com_content&amp;view=article&amp;id=7&amp;Itemid=101&amp;profile=whitegradient">\r\n    <figure class="remove-margin-t">\r\n      <img class="size-auto" src="images/yootheme/features_profile04.png" width="190" height="150" alt="Load Profile White Gradient" title="Load Profile White Gradient" />\r\n      <figcaption>White Gradient</figcaption>\r\n    </figure>\r\n  </a>\r\n  <a class="align-left" href="index.php?option=com_content&amp;view=article&amp;id=7&amp;Itemid=101&amp;profile=redfabric">\r\n    <figure class="remove-margin-t">\r\n      <img class="size-auto" src="images/yootheme/features_profile05.png" width="190" height="150" alt="Load Profile Red Fabric" title="Load Profile Red Fabric" />\r\n      <figcaption>Red Fabric</figcaption>\r\n    </figure>\r\n  </a>\r\n  <a class="align-left" href="index.php?option=com_content&amp;view=article&amp;id=7&amp;Itemid=101&amp;profile=colorwave">\r\n    <figure class="remove-margin-t">\r\n      <img class="size-auto" src="images/yootheme/features_profile06.png" width="190" height="150" alt="Load Profile Colorwave" title="Load Profile Colorwave" />\r\n      <figcaption>Colorwave</figcaption>\r\n    </figure>\r\n  </a>\r\n  <a class="align-left" href="index.php?option=com_content&amp;view=article&amp;id=7&amp;Itemid=101&amp;profile=blue">\r\n    <figure class="remove-margin">\r\n      <img class="size-auto" src="images/yootheme/features_profile07.png" width="190" height="150" alt="Load Profile Blue" title="Load Profile Blue" />\r\n      <figcaption>Blue</figcaption>\r\n    </figure>\r\n    </a>\r\n  <a class="align-left" href="index.php?option=com_content&amp;view=article&amp;id=7&amp;Itemid=101&amp;profile=blackpaper">\r\n    <figure class="remove-margin">\r\n      <img class="size-auto" src="images/yootheme/features_profile08.png" width="190" height="150" alt="Load Profile Black Paper" title="Load Profile Black Paper" />\r\n      <figcaption>Black Paper</figcaption>\r\n    </figure>\r\n  </a>\r\n</div>\r\n\r\n<h2>Theme Layout</h2>\r\n<p>This theme comes with the default Warp6 module layout. The blue module positions allow to choose a module layout which defines the module alignment and proportions: <em>equal</em>, <em>double</em> or <em>stack</em>. You can easily add your own module layouts. The two available sidebars, highlighted in red, can be switched to the left or right side and their widths can easily be set in the theme administration. For modules in the blue and red positions you can choose different module styles. Take a look at the <a href="index.php?option=com_content&amp;view=article&amp;id=1&amp;Itemid=103">module variations</a> page to get an overview.</p>\r\n\r\n<div class="grid-block grid-gutter">\r\n  <div class="grid-box width50">\r\n    <figure class="remove-margin">\r\n      <img class="size-auto" src="images/yootheme/features_module_positions.png" width="290" height="403" alt="Module Positions" title="Module Positions" />\r\n      <figcaption>Module Positions</figcaption>\r\n    </figure>\r\n  </div>\r\n  <div class="grid-box width50">\r\n    <figure class="remove-margin-t">\r\n      <img class="size-auto" src="images/yootheme/features_module_layouts.png" width="295" height="202" alt="Module Layouts" title="Module Layouts" />\r\n      <figcaption>Module Layouts</figcaption>\r\n    </figure>\r\n    <figure class="remove-margin-b">\r\n      <img class="size-auto" src="images/yootheme/features_column_layouts.png" width="295" height="175" alt="Colum Layouts" title="Column Layouts" />\r\n      <figcaption>Column Layouts</figcaption>\r\n    </figure>\r\n  </div>\r\n</div>\r\n\r\n<hr class="dotted" />\r\n\r\n<h2>Special Features</h2>\r\n\r\n<p>The Sphere theme comes with some additional features.</p>\r\n\r\n<h3>Custom Widgetkit Styles</h3>\r\n\r\n<p>We created some custom styles for our <a href="index.php?option=com_content&amp;view=article&amp;id=14&amp;Itemid=133">Widgetkit Slideshow Tabs</a> and <a href="index.php?option=com_content&amp;view=article&amp;id=22&amp;Itemid=144">Widgetkit Slideset</a>, perfectly fitting the theme. To apply these styles, follow these steps:</p>\r\n\r\n<h4>Slideshow Tabs</h4>\r\n<ol>\r\n  <li>Download and unzip the bonus styles package for Widgetkit available in the download area</li>\r\n  <li>Copy the folder <strong>slideshow/styles/sphere_tabs</strong></li>\r\n  <li>\r\n    Joomla: Paste it to <strong>media/widgetkit/widgets/slideshow/styles</strong><br/>\r\n    WordPress: Paste it to <strong>wp-content/plugins/widgetkit/widgets/slideshow/styles</strong>\r\n  </li>\r\n  <li>Now you can select the style "Sphere tabs" in the settings of your Widgetkit Slideshow.</li>\r\n</ol>\r\n\r\n<h4>Slideset</h4>\r\n<ol>\r\n  <li>Download and unzip the bonus styles package for Widgetkit available in the download area</li>\r\n  <li>Copy the folder <strong>slideset/styles/sphere</strong></li>\r\n  <li>\r\n    Joomla: Paste it to <strong>media/widgetkit/widgets/slideset/styles</strong><br/>\r\n    WordPress: Paste it to <strong>wp-content/plugins/widgetkit/widgets/slideset/styles</strong>\r\n  </li>\r\n  <li>Now you can select the style "Sphere" in the settings of your Widgetkit Slideset</li>\r\n</ol>\r\n\r\n<h3>Social Icons</h3>\r\n<p>As a little extra, the Sphere theme offers a set of social icons. They are easy to add to your content and are part of our editable Adobe Fireworks Image Source Files.</p>\r\n\r\n<ul class="social-icons">\r\n  <li class="twitter"><a href="#"></a></li>\r\n  <li class="rss"><a href="#"></a></li>\r\n  <li class="facebook"><a href="#"></a></li>\r\n  <li class="linkedin"><a href="#"></a></li>\r\n  <li class="flickr"><a href="#"></a></li>\r\n  <li class="xing"><a href="#"></a></li>\r\n  <li class="google-plus"><a href="#"></a></li>  \r\n  <li class="youtube"><a href="#"></a></li>\r\n  <li class="vimeo"><a href="#"></a></li>\r\n  <li class="github"><a href="#"></a></li>\r\n</ul>\r\n\r\n<p>Here is a little code example how to add them:</p>\r\n\r\n<pre>\r\n&lt;ul class=&quot;social-icons&quot;&gt;\r\n  &lt;li class=&quot;twiiter&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;/a&gt;&lt;/li&gt;\r\n  &lt;li class=&quot;rss&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;/a&gt;&lt;/li&gt;\r\n  &lt;li class=&quot;facebook&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;/a&gt;&lt;/li&gt;\r\n  &lt;li class=&quot;linkedin&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;/a&gt;&lt;/li&gt;\r\n  &lt;li class=&quot;flickr&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;/a&gt;&lt;/li&gt;\r\n  &lt;li class=&quot;xing&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;/a&gt;&lt;/li&gt;\r\n  &lt;li class=&quot;google-plus&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;/a&gt;&lt;/li&gt;\r\n  &lt;li class=&quot;youtube&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;/a&gt;&lt;/li&gt;\r\n  &lt;li class=&quot;vimeo&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;/a&gt;&lt;/li&gt;\r\n  &lt;li class=&quot;github&quot;&gt;&lt;a href=&quot;#&quot;&gt;&lt;/a&gt;&lt;/li&gt;\r\n&lt;/ul&gt;\r\n</pre>\r\n\r\n<p>Possible class names are <strong>twitter, rss, facebook, linkedin, flickr, xing, google-plus, youtube, vimeo</strong> and <strong>github</strong>.</p>', '', 1, 2, '2011-05-02 11:48:41', 390, '', '2012-07-26 16:27:14', 42, 0, '0000-00-00 00:00:00', '2011-05-02 11:48:41', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 56, 16, '', '', 1, 265, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(7, 39, 'Master Theme', 'master-theme', '<p>This is the Master theme of our fast and slick Warp theme framework! It is optimized and streamlined to serve as a blueprint to build your own custom themes.</p>\r\n\r\n<p>The Master theme takes full advantage of all the latest Warp6 features like a completely responsive layout, semantic HTML5 markup, a nice and clean administration UI and much more.</p>\r\n\r\n<a class="button-default" href="index.php?option=com_content&view=article&id=7:master-theme&catid=2&Itemid=101">Read more</a>', '', 1, 2, '2011-05-02 11:49:24', 390, '', '2012-06-05 13:58:34', 42, 0, '0000-00-00 00:00:00', '2011-05-02 11:49:24', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 8, 17, '', '', 1, 7640, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(8, 40, 'Joomla Templates', 'joomla-templates', '<p><a href="index.php?option=com_content&amp;view=article&amp;id=8:joomla-templates&amp;catid=7&amp;Itemid=126"><img class="size-auto" width="760" height="300" alt="Joomla Templates and WordPress Themes" title="Joomla Templates and WordPress Themes" src="images/yootheme/blog_themes.jpg" /></a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n', '\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 1, 7, '2012-04-12 11:50:02', 390, '', '2012-06-18 15:08:16', 42, 0, '0000-00-00 00:00:00', '2012-04-12 11:50:02', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 32, 1, '', '', 1, 67, '{"robots":"","author":"","rights":"","xreference":""}', 1, '*', ''),
(9, 41, 'Beautiful Icons', 'beautiful-icons', '<p><a href="index.php?option=com_content&amp;view=article&amp;id=9:beautiful-icons&amp;catid=7&amp;Itemid=126"><img class="size-auto" width="760" height="300" alt="Beautiful and handcrafted icons for web and print projects" title="Beautiful and handcrafted icons for web and print projects" src="images/yootheme/blog_icons.jpg" /></a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n', '\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 1, 7, '2012-03-15 11:50:30', 390, '', '2012-07-24 11:47:01', 42, 0, '0000-00-00 00:00:00', '2012-03-15 11:50:30', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 7, 3, '', '', 1, 14, '{"robots":"","author":"","rights":"","xreference":""}', 1, '*', ''),
(10, 42, 'Warp Theme Framework', 'warp-theme-framework', '<p><a href="index.php?option=com_content&amp;view=article&amp;id=10:warp-theme-framework&amp;catid=7&amp;Itemid=126"><img class="size-auto" width="760" height="300" alt="Warp Theme Framework" title="Warp Theme Framework" src="images/yootheme/blog_warp.jpg" /></a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n', '\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 1, 7, '2012-03-20 11:50:55', 390, '', '2012-06-18 15:12:58', 42, 0, '0000-00-00 00:00:00', '2012-03-20 11:50:55', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 6, 2, '', '', 1, 14, '{"robots":"","author":"","rights":"","xreference":""}', 1, '*', ''),
(11, 43, 'ZOO Extension', 'zoo-extension', '<p><img class="size-auto" width="760" height="300" alt="ZOO is a flexible and powerful content application builder to manage your content" title="ZOO is a flexible and powerful content application builder to manage your content" src="images/yootheme/blog_zoo.png" /></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n', '\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 1, 7, '2012-02-28 11:51:30', 390, '', '2012-06-18 15:09:55', 42, 0, '0000-00-00 00:00:00', '2012-02-28 11:51:30', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 4, 5, '', '', 1, 5, '{"robots":"","author":"","rights":"","xreference":""}', 1, '*', ''),
(12, 44, 'Free Social Icons', 'free-social-icons', '<p><a href="index.php?option=com_content&amp;view=article&amp;id=12:free-social-icons&amp;catid=7&amp;Itemid=126"><img class="size-auto" width="760" height="300" alt="Free Social Icons Set" title="Free Social Icons Set" src="images/yootheme/blog_social_icons.jpg" /></a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n', '\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 1, 7, '2012-01-14 11:51:53', 390, '', '2012-07-24 11:47:10', 42, 0, '0000-00-00 00:00:00', '2012-01-14 11:51:53', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 6, 6, '', '', 1, 2, '{"robots":"","author":"","rights":"","xreference":""}', 1, '*', ''),
(13, 61, 'Widgetkit', 'widgetkit', '<p>Widgetkit is the next generation tool set for Joomla and WordPress. This toolkit is the first of its kind! It provides a simple and user-friendly way to enrich your websites experience with slideshows, galleries, lightboxes and much more. All widgets make use of modern web technologies like HTML5 markup, CSS3 features and jQuery based JavaScripts. Widgetkit is fully responsive and all widgets and their effects adapt perfectly for all device resolutions. It supports touch gestures and makes use of smooth CSS3 animations. Here is a short feature roundup:</p>\r\n\r\n<h2>Features</h2>\r\n\r\n<ul class="check">\r\n	<li>Available for Joomla and WordPress</li>\r\n	<li>All widgets are fully responsive</li>\r\n	<li>Use shortcodes to show widgets anywhere</li>\r\n	<li>Clean and lightweight code</li>\r\n	<li>Semantic HTML5 markup</li>\r\n	<li>Asset file minification and compression</li>\r\n	<li>Supports touch gestures for mobile devices</li>\r\n	<li>Uses hardware accelerated CSS3 animations</li>\r\n	<li>Built with HTML5, CSS3, PHP 5.2+, latest jQuery version</li>\r\n</ul>\r\n\r\n<h2>How It Works</h2>\r\n\r\n<p>Widgetkit basically acts as a platform for all our widgets. It installs as a single component in Joomla or as a plugin in WordPress. The Widgetkit dashboard presents you an overview of all widgets. You can create, edit or delete all widgets and their content in one place. And after you have created the content for your first widget you can either use a shortcode or a module to display your widget anywhere on your website. In fact you can do both because once have you created a widget you are able to display it multiple times and reuse it on different parts of your website.</p>\r\n\r\n<a class="button-default" href="http://www.yootheme.com/widgetkit" target="_blank">Visit Website</a>', '', 1, 2, '2011-06-08 11:15:54', 390, '', '2012-06-06 13:08:58', 42, 0, '0000-00-00 00:00:00', '2011-06-08 11:15:54', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 16, 10, '', '', 1, 117, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(14, 47, 'Slideshow', 'slideshow', '<p>The Widgetkit Slideshow is the ultimate image and content slideshow for Joomla and WordPress. It''s flexible, easy to customize and completely build with HTML5 and CSS3. </p>\r\n\r\n<h2>Features</h2>\r\n\r\n<ul class="check">\r\n	<li>Clean and very lightweight code</li>\r\n	<li>17 eye-catching transition effects</li>\r\n	<li>Fully responsive including all effects</li>\r\n	<li>Uses hardware accelerated CSS3 animations</li>\r\n	<li>Support for HTML captions</li>\r\n	<li>Swipe navigation on mobile phones</li>\r\n	<li>Built with HTML5, CSS3, PHP 5.2+, and the latest jQuery version</li>\r\n	<li>Works with Joomla and WordPress</li>\r\n</ul>\r\n\r\n<h2>Slideshow Screen Example</h2>\r\n<p>This is an image slideshow with the famous Ken Burns effect.</p>\r\n[widgetkit id=45]\r\n\r\n<h2>Slideshow Default Example</h2>\r\n<p>This is an image slideshow with eye-catching transition effects.</p>\r\n[widgetkit id=10]\r\n\r\n<h2>Showcase Box Example</h2>\r\n<p>This a content showcase using all the features from the Slideset widget as navigation. Any kind of HTML content can be used in the navigation.</p>\r\n[widgetkit id=37]\r\n\r\n<h2>Showcase Button Example</h2>\r\n<p>This is an image slideshow with some nice navigation buttons. You can place any kind of HTML in the navigation buttons.</p>\r\n[widgetkit id=41]\r\n\r\n<h2>Tabs Example</h2>\r\n<p>This is a classic, tabbed slideshow. Tabs can be aligned to the left, right and center.</p>\r\n[widgetkit id=35]\r\n\r\n<h2>Tabs Bar Example</h2>\r\n<p>This is a slideshow with a tabbed navigation bar. Tabs can be aligned to the left, right and center.</p>\r\n[widgetkit id=34]\r\n\r\n<h2>List Example</h2>\r\n<p>This is a slideshow with a vertical tabbed list as navigation.</p>\r\n[widgetkit id=36]\r\n\r\n<h2>How To Use</h2>\r\n\r\n<p>The Widgetkit Slideshow takes full advantage of the very user-friendly Widgetkit administration user interface. It has never been easier to create and manage all the slideshows and their different slides in one place. After you created a slideshow you can load it anywhere in your theme using shortcodes or the universal Widgetkit Joomla module or WordPress widget.</p>', '', 1, 2, '2011-06-08 11:16:09', 390, '', '2012-06-06 13:19:51', 42, 0, '0000-00-00 00:00:00', '2011-06-08 11:16:09', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 10, 9, '', '', 1, 60, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', '');
INSERT INTO `zjw8d_content` (`id`, `asset_id`, `title`, `alias`, `introtext`, `fulltext`, `state`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`, `featured`, `language`, `xreference`) VALUES
(15, 48, 'Lightbox', 'lightbox', '<p>The Widgetkit Lightbox allows you to view images, HTML and multi-media content on a dark dimmed overlay without having to leave the current page.</p>\r\n\r\n<h2>Features</h2>\r\n\r\n<ul class="check">\r\n	<li>Display images, videos, HTML, Iframes, Ajax requests and SWF</li>\r\n	<li>Supports YouTube, Vimeo, MP4 (h.264), WebM and FLV movies</li>\r\n	<li>Group lightboxes and mix different content types</li>\r\n	<li>Responsive design to fit all device resolutions</li>\r\n	<li>Load other widgets in lightbox</li>\r\n	<li>3 different opening and closing transitions</li>\r\n	<li>4 different caption styles</li>\r\n	<li>Keyboard and mouse scroll wheel navigation</li>\r\n	<li>Build on the latest jQuery version</li>\r\n	<li>Works with Joomla and WordPress</li>\r\n</ul>\r\n\r\n<h2>Examples</h2>\r\n\r\n<p>Different animations - <code>fade</code>, <code>elastic</code> and <code>none</code></p>\r\n<p class="gallery">\r\n	<a data-lightbox="transitionIn:fade;transitionOut:fade;" href="images/yootheme/widgetkit/lightbox/image1_lightbox.jpg"><img src="images/yootheme/widgetkit/lightbox/image1.jpg" width="180" height="120" alt="Lightbox Image" /></a>\r\n	<a data-lightbox="transitionIn:elastic;transitionOut:elastic;" href="images/yootheme/widgetkit/lightbox/image2_lightbox.jpg"><img src="images/yootheme/widgetkit/lightbox/image2.jpg" width="180" height="120" alt="Lightbox Image" /></a>\r\n	<a data-lightbox="transitionIn:none;transitionOut:none;" href="images/yootheme/widgetkit/lightbox/image3_lightbox.jpg"><img src="images/yootheme/widgetkit/lightbox/image3.jpg" width="180" height="120" alt="Lightbox Image" /></a>\r\n</p>\r\n\r\n<p>Different title positions - <code>float</code>, <code>inside</code> and <code>over</code></p>\r\n<p class="gallery">\r\n	<a data-lightbox="group:mygroup1;titlePosition:float" href="images/yootheme/widgetkit/lightbox/image4_lightbox.jpg" title="Title Position: Float"><img src="images/yootheme/widgetkit/lightbox/image4.jpg" width="180" height="120" alt="Lightbox Image" /></a>\r\n	<a data-lightbox="group:mygroup1;titlePosition:inside" href="images/yootheme/widgetkit/lightbox/image5_lightbox.jpg" title="Title Position: Inside"><img src="images/yootheme/widgetkit/lightbox/image5.jpg" width="180" height="120" alt="Lightbox Image" /></a>\r\n	<a data-lightbox="group:mygroup1;titlePosition:over;padding:0" href="images/yootheme/widgetkit/lightbox/image6_lightbox.jpg" title="Title Position: Over and Padding set to 0"><img src="images/yootheme/widgetkit/lightbox/image6.jpg" width="180" height="120" alt="Lightbox Image" /></a>\r\n</p>\r\n\r\n<p>Various examples in one gallery (try also using the keyboard and mouse scroll wheel)</p>\r\n<ul>\r\n	<li><a data-lightbox="group:mygroup2" href="http://www.youtube.com/watch?v=R55e-uHQna0" title="YouTube Video">YouTube</a></li>\r\n	<li><a data-lightbox="group:mygroup2" href="http://vimeo.com/15261921" title="Vimeo Video">Vimeo</a></li>\r\n	<li><a data-lightbox="group:mygroup2;autoplay:true;" href="http://www.yootheme.com/videos/mediaplayer.mp4" title="MP4 (h.264)">MP4 (h.264)</a></li>\r\n	<li><a data-lightbox="group:mygroup2" href="http://www.adobe.com/jp/events/cs3_web_edition_tour/swfs/perform.swf" title="Flash Swf">Swf</a></li>\r\n	<li><a data-lightbox="group:mygroup2" href="#inline" title="Inline Content from the Website">Inline</a></li>\r\n	<li><a data-lightbox="group:mygroup2;width:1000;height:600" title="Iframe" href="http://www.wikipedia.org">Iframe</a></li>\r\n</ul>\r\n\r\n<div style="display: none;">\r\n	<div id="inline" style="width: 400px; height: 100px; overflow: auto;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</div>\r\n</div>\r\n\r\n<h2>Load Widgets In A Lightbox</h2>\r\n<p>Use <code>#wk-ID</code> to load widgets like slideshows or galleries in a lightbox. For example: <a data-lightbox="width:600;height:300;" href="#wk-50" title="Widgetkit Slideshow">Widgetkit Slideshow</a></p>\r\n<pre>&lt;a data-lightbox=&quot;width:600;height:300;&quot; href=&quot;#wk-10&quot;&gt;Lightbox&lt;/a&gt;</pre>\r\n\r\n<h2>How To Use</h2>\r\n\r\n<p>Use the HTML5 custom data attribute <code>data-lightbox</code> to activate the lightbox. You can set various lightbox parameters to the data attribute. For example:</p>\r\n\r\n<pre>&lt;a data-lightbox=&quot;width:1000;height:600;&quot; href=&quot;http://www.wikipedia.org&quot;&gt;Lightbox&lt;/a&gt;</pre>\r\n\r\n<p>Here is a list of the most common parameters:</p>\r\n\r\n<ul>\r\n	<li><strong>titlePosition</strong> - How should the title show up? (<code>float</code>, <code>outside</code>, <code>inside</code> or <code>over</code>)</li>\r\n	<li><strong>transitionIn</strong> - Set a opening transition. (<code>fade</code>, <code>elastic</code>, or <code>none</code>)</li>\r\n	<li><strong>transitionOut</strong> - Set a closing transition (<code>fade</code>, <code>elastic</code>, or <code>none</code>)</li>\r\n	<li><strong>overlayShow</strong> - Set to <code>true</code> or <code>false</code></li>\r\n	<li><strong>scrolling</strong> - Set to <code>yes</code> or <code>no</code></li>\r\n	<li><strong>width</strong> - Set a width in pixel</li>\r\n	<li><strong>height</strong> - Set a height in pixel</li>\r\n	<li><strong>padding</strong> - Set a padding in pixel</li>\r\n</ul>', '', 1, 2, '2011-06-08 11:16:20', 390, '', '2012-06-06 13:26:20', 42, 0, '0000-00-00 00:00:00', '2011-06-08 11:16:20', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 6, 8, '', '', 1, 19, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(16, 49, 'Spotlight', 'spotlight', '<p>The Widgetkit Spotlight allows you to add an overlay to your images which fades or moves in on mouse hover. The overlay can be an image or HTML content. The default magnifier spotlight is a perfect match to be used with a lightbox.</p>\r\n\r\n<h2>Features</h2>\r\n\r\n<ul class="check">\r\n	<li>Create nicely animated image overlays</li>\r\n	<li>Supports custom image or HTML content overlays</li>\r\n	<li>5 different animation modes</li>\r\n	<li>Responsive design to fit all device resolutions</li>\r\n	<li>Built with the latest jQuery version</li>\r\n	<li>Works with Joomla and WordPress</li>\r\n</ul>\r\n\r\n<h2>Examples</h2>\r\n\r\n<p>If no custom overlay is set the default spotlight fades in an overlay with an magnifier image. If you define a custom overlay you can choose between different animations - <code>fade</code>, <code>bottom</code>, <code>top</code>, <code>right</code> and <code>left</code>.</p>\r\n\r\n<div>\r\n	<a data-spotlight="on" data-lightbox="transitionIn:elastic;transitionOut:elastic;" href="images/yootheme/widgetkit/lightbox/image1_lightbox.jpg">\r\n		<img src="images/yootheme/widgetkit/lightbox/image1.jpg" width="180" height="120" alt="Spotlight Image" />\r\n	</a>\r\n	<a data-spotlight="effect:bottom;" data-lightbox="transitionIn:elastic;transitionOut:elastic;" href="images/yootheme/widgetkit/lightbox/image2_lightbox.jpg">\r\n		<img src="images/yootheme/widgetkit/lightbox/image2.jpg" width="180" height="120" alt="Spotlight Image" />\r\n		<div class="overlay">Custom Overlay (Bottom)</div>\r\n	</a>\r\n	<a data-spotlight="effect:right;" data-lightbox="transitionIn:elastic;transitionOut:elastic;" href="images/yootheme/widgetkit/lightbox/image3_lightbox.jpg">\r\n		<img src="images/yootheme/widgetkit/lightbox/image3.jpg" width="180" height="120" alt="Spotlight Image" />\r\n		<div class="overlay">Custom Overlay (Right)</div>\r\n	</a>\r\n</div>\r\n\r\n<div>\r\n	<a data-spotlight="effect:fade;" data-lightbox="transitionIn:elastic;transitionOut:elastic;" href="images/yootheme/widgetkit/lightbox/image4_lightbox.jpg">\r\n		<img src="images/yootheme/widgetkit/lightbox/image4.jpg" width="180" height="120" alt="Spotlight Image" />\r\n		<div class="overlay remove-padding"><img src="images/yootheme/widgetkit/lightbox/image4_spotlight.jpg" width="180" height="120" alt="Spotlight Image" /></div>\r\n	</a>\r\n	<a data-spotlight="effect:top;" data-lightbox="transitionIn:elastic;transitionOut:elastic;" href="images/yootheme/widgetkit/lightbox/image5_lightbox.jpg">\r\n		<img src="images/yootheme/widgetkit/lightbox/image5.jpg" width="180" height="120" alt="Spotlight Image" />\r\n		<div class="overlay">Custom Overlay (Top)</div>\r\n	</a>\r\n	<a data-spotlight="effect:left;" data-lightbox="transitionIn:elastic;transitionOut:elastic;" href="images/yootheme/widgetkit/lightbox/image6_lightbox.jpg">\r\n		<img src="images/yootheme/widgetkit/lightbox/image6.jpg" width="180" height="120" alt="Spotlight Image" />\r\n		<div class="overlay">Custom Overlay (Left)</div>\r\n	</a>\r\n</div>\r\n\r\n<h2>How To Use</h2>\r\n\r\n<p>Use the HTML5 custom data attribute <code>data-spotlight</code> to activate the spotlight.\r\n\r\n<pre>&lt;a data-spotlight="on" href="/mypage.html"&gt;\r\n	&lt;img src="/image.jpg" width="180" height="120" alt="" /&gt;\r\n&lt;/a&gt;</pre>\r\n\r\n<p>To create a custom overlay use a div element with the CSS class <code>overlay</code>. You can set the effect parameter to the data attribute. For example:</p>\r\n\r\n<pre>&lt;a data-spotlight="effect:bottom;" href="/mypage.html"&gt;\r\n	&lt;img src="/image.jpg" width="180" height="120" alt="" /&gt;\r\n	&lt;div class="overlay"&gt;Custom Overlay&lt;/div&gt;\r\n&lt;/a></pre>\r\n\r\n<p>You can set the effect parameter to <code>fade</code>, <code>bottom</code>, <code>top</code>, <code>right</code> and <code>left</code>.', '', 1, 2, '2011-06-08 11:16:32', 390, '', '2012-06-06 13:28:54', 42, 0, '0000-00-00 00:00:00', '2011-06-08 11:16:32', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 5, 7, '', '', 1, 13, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(17, 50, 'Twitter', 'twitter', '<p>The Widgetkit Twitter module is the neatest way to display tweets directly on your website. All displayed tweets get cached so they show up super fast, even if Twitter is not available.</p>\r\n\r\n<h2>Features</h2>\r\n\r\n<ul class="check">\r\n	<li>Filter tweets by hashtags, words, from users, to users, referencing users</li>\r\n	<li>Block tweets using a blacklist</li>\r\n	<li>Tweets are cached for high performance</li>\r\n	<li>Tweets show up even if Twitter is not available</li>\r\n	<li>3 different styles to show your tweets</li>\r\n	<li>Responsive design to fit all device resolutions</li>\r\n	<li>Built with HTML5 using article and time elements</li>\r\n	<li>Works with Joomla and WordPress</li>\r\n</ul>\r\n\r\n<h2>How To Use</h2>\r\n\r\n<p>Create a Twitter module in Joomla or a Twitter widget in WordPress and publish it in a module position. A lot of options are available to choose which tweets you want to show.</p>\r\n\r\n<p>For example you can show only tweets from a specific user or tweets that contain a certain hash-tag or a specific word. All options can be combined. To filter by more than one word or user use a space between them. For example: <code>yootheme joomla</code>.</p>', '', 1, 2, '2011-06-08 11:16:47', 390, '', '2012-06-06 13:29:45', 42, 0, '0000-00-00 00:00:00', '2011-06-08 11:16:47', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 4, 6, '', '', 1, 171, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(18, 51, 'Media Player', 'media-player', '<p>The Widgetkit Media Player is a HTML5 audio and video player completely built HTML and CSS. You can easily embed video files into your website by using the HTML5 video element. A Flash player fallback is included for all unsupported browsers.</p>\r\n\r\n<h2>Features</h2>\r\n\r\n<ul class="check">\r\n	<li>Native playback for modern HTML5 browsers</li>\r\n	<li>Supports MP4 (h.264), WebM, FLV, WMV and MP3 files</li>\r\n	<li>Completely built with HTML and CSS</li>\r\n	<li>Responsive design to fit all device resolutions</li>\r\n	<li>Same UI in all browsers</li>\r\n	<li>Create your own skins</li>\r\n	<li>Flash player fallback for unsupported browsers</li>\r\n	<li>Works with Joomla and WordPress</li>\r\n</ul>\r\n\r\n<h2>Examples</h2>\r\n\r\n<video width="640" height="360" poster="http://www.yootheme.com/videos/mediaplayer.jpg" controls="controls" preload="none">\r\n	<source type="video/mp4" src="http://www.yootheme.com/videos/mediaplayer.mp4" />\r\n</video>\r\n\r\n<p>This is a MP3 Audio Sample:</p>\r\n\r\n<audio src="http://www.yootheme.com/videos/mediaplayer.mp3" type="audio/mp3" controls="control" preload="none"></audio>\r\n\r\n<h2>How To Use</h2>\r\n\r\n<p>Use the HTML5 <code>video</code> element to embed video in your website. For example:</p>\r\n\r\n<pre>&lt;video src="/video.mp4" width="320" height="240"&gt;&lt;/video&gt;</pre>\r\n\r\n<p>You can also provide multiple sources, to add support for the different video formats like h.264, WebM or Ogg:</p>\r\n\r\n<pre>&lt;video width="320" height="240"&gt;\r\n	&lt;source type="video/mp4"  src="/video.mp4" /&gt;\r\n	&lt;source type="video/webm" src="/video.webm" /&gt;\r\n	&lt;source type="video/ogg"  src="/video.ogv" /&gt;\r\n&lt;/video&gt;\r\n</pre>\r\n\r\n\r\n<p>Use the HTML5 <code>audio</code> element to embed MP3 files in your website. For example:</p>\r\n\r\n<pre>&lt;audio src="/audio.mp3" type="audio/mp3"&gt;&lt;/audio&gt;</pre>', '', 1, 2, '2011-07-31 16:01:48', 390, '', '2012-06-06 13:30:08', 42, 0, '0000-00-00 00:00:00', '2011-07-31 16:01:48', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 4, 5, '', '', 1, 14, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(19, 52, 'Gallery', 'gallery', '<p>The Widgetkit Gallery provides a smart and automated way to publish images on your website. You only need to select the image folders and the whole gallery is generated automatically.</p>\r\n\r\n<h2>Features</h2>\r\n\r\n<ul class="check">\r\n	<li>Fully responsive including all effects</li>\r\n	<li>Folder based image selection</li>\r\n	<li>Support for multiple image folders</li>\r\n	<li>Automatic thumbnail creation</li>\r\n	<li>Support for image captions and custom links</li>\r\n	<li>Uses the Widgetkit Spotlight and Lightbox</li>\r\n	<li>Built with HTML5, CSS3, PHP 5.2+, and the latest jQuery version</li>\r\n	<li>Works with Joomla and WordPress</li>\r\n</ul>\r\n\r\n<h2>Showcase Box Example</h2>\r\n<p>This is an image showcase with eye-catching transition effects and a thumbnail navigation.</p>\r\n[widgetkit id=39]\r\n\r\n<h2>Image Wall Example</h2>\r\n<p>This is an image wall with zoom effect, no margins and squared corners using the lightbox.</p>\r\n[widgetkit id=24]\r\n\r\n<h2>Polaroid Example</h2>\r\n<p>This is an image wall with scattered polaroid pictures using the lightbox.</p>\r\n[widgetkit id=25]\r\n\r\n<h2>Slider Example 1</h2>\r\n<p>This is an image slider where the image centers automatically during the effect. It also features a spotlight caption and the lightbox.</p>\r\n[widgetkit id=27]\r\n\r\n<h2>Slider Example 2</h2>\r\n<p>This is an image slider where the image stays left during the effect.</p>\r\n[widgetkit id=31]\r\n\r\n<h2>Slideshow Screen Example</h2>\r\n<p>This is an image gallery using the nice swipe effect from the slideshow widget.</p>\r\n[widgetkit id=48]\r\n\r\n<h2>Slideshow Default Example</h2>\r\n<p>This is an image gallery using all the features from the slideshow widget.</p>\r\n[widgetkit id=19]\r\n\r\n<h2>Showcase Example</h2>\r\n<p>This is a simple image showcase mashing up all the features from the slideshow and slideset widget.</p>\r\n[widgetkit id=40]\r\n\r\n<h2>Spotlight Example</h2>\r\n<p>This is an image wall with some margins and rounded corners using the spotlight and lightbox.</p>\r\n[widgetkit id=23]\r\n\r\n<h2>Slideset Example</h2>\r\n<p>This is an image gallery using all the features from the slideset widget.</p>\r\n[widgetkit id=44]\r\n\r\n<h2>How To Use</h2>\r\n\r\n<p>The Widgetkit Gallery comes with a user-friendly administration user interface which let''s you create new galleries with just a few clicks. The integrated directory browser let''s you easily add or remove source directories of your images. All galleries can be loaded anywhere in your theme using shortcodes or the universal Widgetkit Joomla module or WordPress widget.</p>', '', 1, 2, '2011-07-31 16:02:04', 390, '', '2012-06-06 13:21:00', 42, 0, '0000-00-00 00:00:00', '2011-07-31 16:02:04', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 6, 4, '', '', 1, 33, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(20, 53, 'Map', 'map', '<p>The Widgetkit Map provides a simple solution for adding a map to your website. Various features let you customize the map like changing colors and adding markers or directions.</p>\r\n\r\n<h2>Features</h2>\r\n\r\n<ul class="check">\r\n	<li>Location selection with auto geocoding</li>\r\n	<li>Support for multiple map markers with text popups</li>\r\n	<li>Option to get the direction to the active marker</li>\r\n	<li>Support for custom map styles and colors</li>\r\n	<li>Uses the latest Google Maps API</li>\r\n	<li>Built with HTML5, CSS3, PHP 5.2+, and the latest jQuery version</li>\r\n	<li>Works with Joomla and WordPress</li>\r\n</ul>\r\n\r\n<h2>Direction Example</h2>\r\n<p>This map features all map controls, multiple markers and you can get the direction.</p>\r\n[widgetkit id=26]\r\n\r\n<h2>Color Scheme Example</h2>\r\n<p>Set or invert the hue, saturation, lightness and gamma of a map.</p>\r\n[widgetkit id=28]\r\n\r\n<h2>Minimal Example</h2>\r\n<p>This map has a fixed width, no controls and no markers.</p>\r\n[widgetkit id=29]\r\n\r\n<h2>How To Use</h2>\r\n\r\n<p>With the Widgetkit Map you can quickly create and manage simple maps with features like multiple markers, text popups and custom color schemes. Once you have created a map you can load it anywhere on your website using shortcodes or the universal Widgetkit Joomla module or WordPress widget.</p>', '', 1, 2, '2011-07-31 16:02:22', 390, '', '2011-08-02 14:26:06', 42, 0, '0000-00-00 00:00:00', '2011-07-31 16:02:22', '0000-00-00 00:00:00', '', '', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","alternative_readmore":"","article_layout":""}', 3, 3, '', '', 1, 15, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(21, 54, 'Accordion', 'accordion', '<p>The Widgetkit Accordion enables you to display a set of items in a compact space, by clicking on each items header it expands or collapses it''s content section.</p>\r\n\r\n<h2>Features</h2>\r\n\r\n<ul class="check">\r\n	<li>Clean and very lightweight code</li>\r\n	<li>Responsive design to fit all device resolutions</li>\r\n	<li>Smooth transitions on content section toggle</li>\r\n	<li>Option to match automatically the height of varying content</li>\r\n	<li>Option to auto collapse or allow multiple opened items</li>\r\n	<li>Built with HTML5, CSS3, PHP 5.2+, and the latest jQuery version</li>\r\n	<li>Works with Joomla and WordPress</li>\r\n</ul>\r\n\r\n<h2>Example</h2>\r\n\r\n[widgetkit id=30]\r\n\r\n<h2>How To Use</h2>\r\n\r\n<p>The Widgetkit Accordion lets you easily create and manage all the accordions contents through the user-friendly Widgetkit administration user interface. After you have created an accordion you can load it anywhere on your website using shortcodes or the universal Widgetkit Joomla module or WordPress widget.</p>', '', 1, 2, '2011-07-31 16:02:38', 390, '', '2012-06-06 13:26:30', 42, 0, '0000-00-00 00:00:00', '2011-07-31 16:02:38', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 5, 2, '', '', 1, 22, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(22, 55, 'Slideset', 'slideset', '<p>The Widgetkit Slideset takes your product showcase to the next level. It provides a sleek way to show multiple sets of items and uses smooth effects while looping through them.</p>\r\n\r\n<h2>Features</h2>\r\n\r\n<ul class="check">\r\n	<li>Clean and very lightweight code</li>\r\n	<li>Eye-catching transition effects</li>\r\n	<li>Fully responsive including all effects</li>\r\n	<li>Support of named custom sets</li>\r\n	<li>Swipe navigation on mobile phones</li>\r\n	<li>Built with HTML5, CSS3, PHP 5.2+, and the latest jQuery version</li>\r\n	<li>Works with Joomla and WordPress</li>\r\n</ul>\r\n\r\n<h2>Slide Example</h2>\r\n<p>The sets are auto generated (4 items per set), item names are shown and it uses the slide effect and navigation buttons.</p>\r\n[widgetkit id=32]\r\n\r\n<h2>Zoom Example</h2>\r\n<p>The sets are arranged manually, the sets names are used as navigation and it uses the zoom effect.</p>\r\n[widgetkit id=33]\r\n\r\n<h2>Drops Example</h2>\r\n<p>The sets show the item names and it uses the drops effect and navigation buttons.</p>\r\n[widgetkit id=49]\r\n\r\n<h2>Deck Example</h2>\r\n<p>This auto generated sets uses prev/next buttons as navigation and the deck effect.</p>\r\n[widgetkit id=43]\r\n\r\n<h2>How To Use</h2>\r\n\r\n<p>The Widgetkit Slideset takes full advantage of the very user-friendly Widgetkit administration user interface. You can create and manage all the slidesets and their different items in one place. After you have created a slideset you can load it anywhere on your website using shortcodes or the universal Widgetkit Joomla module or WordPress widget.</p>', '', 1, 2, '2011-07-31 16:02:55', 390, '', '2012-06-06 13:19:21', 42, 0, '0000-00-00 00:00:00', '2011-07-31 16:02:55', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 6, 1, '', '', 1, 36, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', ''),
(23, 62, 'Widgetkit', 'widgetkit-extension', '<p><a href="index.php?option=com_content&amp;view=article&amp;id=23:widgetkit-extension&amp;catid=7&amp;Itemid=126"><img class="size-auto" width="760" height="300" alt="Widgetkit" title="Widgetkit" src="images/yootheme/blog_widgetkit.jpg" /></a></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\r\n\r\n', '\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 1, 7, '2012-03-13 11:50:55', 390, '', '2012-06-18 15:27:09', 42, 0, '0000-00-00 00:00:00', '2012-03-13 11:50:55', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":null,"urlatext":"","targeta":"","urlb":null,"urlbtext":"","targetb":"","urlc":null,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 7, 4, '', '', 1, 2, '{"robots":"","author":"","rights":"","xreference":""}', 1, '*', ''),
(24, 67, '__404__', '404', '<h1>Bad karma: we can''t find that page!</h1><p>You asked for <strong>{%sh404SEF_404_URL%}</strong>, but despite our computers looking very hard, we could not find it. What happened ?</p><ul><li>the link you clicked to arrive here has a typo in it</li><li>or somehow we removed that page, or gave it another name</li><li>or, quite unlikely for sure, maybe you typed it yourself and there was a little mistake ?</li></ul><h4>{sh404sefSimilarUrlsCommentStart}It''s not the end of everything though : you may be interested in the following pages on our site:{sh404sefSimilarUrlsCommentEnd}</h4><p>{sh404sefSimilarUrls}</p><p></p>', '', 1, 11, '2014-09-17 08:32:30', 584, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '{"menu_image":"-1","show_title":"0","show_section":"0","show_category":"0","show_vote":"0","show_author":"0","show_create_date":"0","show_modify_date":"0","show_pdf_icon":"0","show_print_icon":"0","show_email_icon":"0","pageclass_sfx":""', 1, 0, '', '', 1, 0, '', 0, '*', ''),
(25, 68, 'Giới thiệu', 'gioi-thieu', '<p class="MsoNormal" style="text-align: justify;">Sách là một trong những phát minh vĩ đại và là tài sản quý giá nhất của loài người trong quá trình nhận thức về giới tự nhiên và các quy luật xã hội. Sách lưu giữ và truyền bá tri thức; là người thầy và cũng là bạn, vừa bồi dưỡng tâm hồn, hun đúc nên bản lĩnh đồng thời cũng mách bảo, sẻ chia vui buồn, nâng đỡ những ước mơ, khát vọng và đam mê. Sách như tấm gương phản chiếu hiện thực xã hội, chỉ báo tin cậy về trí tuệ và phẩm cách của một con người, một thời kỳ, một quốc gia, dân tộc. Có người ví sách như một bảo tàng bằng ngôn ngữ. Nhưng sách đâu chỉ lưu giữ những gì đã qua, mà còn dẫn dắt người đọc vượt lên trước thời gian để đắm mình trong xã hội tương lai. Ngày nay, khi kinh tế tri thức đang ngày càng chứng minh sức mạnh và hiệu quả của nó thì sách trở thành công cụ trí tuệ không thể thiếu được. Để có được một nghề: cần có sách. Để giữ được chỗ làm hoặc có chỗ làm việc với thu nhập cao hơn cũng cần đọc, hiểu và biến những con chữ bất động trong những trang sách thành khả năng và kỹ năng được thể hiện sinh động trong cuộc sống. Với ePub Việt sách thực sự là một người Bạn thủy chung, một người Thầy tin cậy.</p>\r\n<p class="MsoNormal" style="text-align: justify;">Sáng tạo là đứng trên vai những người khổng lồ ! Và sách sẽ giúp bạn thực hiện điều đó. Nhưng so sánh thế hệ thanh niên Việt Nam hiện nay: Tây - Rảnh lên Thư viện, có những phát minh sáng tạo từ năm 6,7 tuổi; Việt Nam - Rảnh đi “Trà chanh - Chém gió”, “Buôn dưa lê”, game online, game offline,...</p>\r\n<p class="MsoNormal" style="text-align: justify;">Cùng thời điểm hiện tại, với sự phát triển mạnh mẽ của công nghệ cùng những hệ điều hành di động như iOS (Apple), Android (Google), BlackBerry 10 - Blackberry Tablet OS (RIM ~ BlackBerry), Windows Phone (Microsoft),... Thư viện ePub Việt (eBook Library ePubViet) được xây dựng với nguyện vọng phát triển một Thư viện sách điện tử định dạng ePub chuẩn chia sẻ miễn phí tới tất cả bạn đọc yêu sách, ủng hộ tinh thần,hoạt động đọc sách.</p>\r\n<p class="MsoNormal" style="text-align: justify;">Với Thư viện ePub Việt, Sách truyện sai chính tả, loạn font chữ,... như một món ăn bề ngoài nhìn trông đẹp nhưng khi thưởng thức lại không mùi, không vị, chỉ như là “Rác”.”Chính vì vậy, ePub Việt sẽ cố gắng chỉnh sửa, kiểm tra, kiểm soát, xuất bản những sách ebook “chuẩn” nhất có thể:</p>\r\n<p class="MsoNormal" style="text-align: justify;">+ Tất cả các sách đều có các mục thông tin bắt buộc: [Tiêu đề Tác phẩm + Nguyên tác (nếu có) + Bút danh Tác giả + Dịch giả (nếu có)] + Giới thiệu Tác giả + Giới thiệu Tác phẩm + Nội dung Tác phẩm.</p>\r\n<p class="MsoNormal" style="text-align: justify;">+ Hạn chế lỗi sai chính tả - gần như 100%.</p>\r\n<p class="MsoNormal" style="text-align: justify;">+ Hạn chế loạn font chữ- gần như 100%.</p>\r\n<p class="MsoNormal" style="text-align: justify;">+ Chỉnh sửa các từ phiên âm, phiên dịch của các tác phẩm dịch sang tiếng Việt về đúng theo nguyên bản tác phẩm.</p>\r\n<p class="MsoNormal" style="text-align: justify;">Ví dụ: tên một số nhân vật, địa danh trong tác phẩm “Robinson trên đảo hoang”: "Ai-ớc" - "York"; "Bờ-rem" - "Bremen"; "Hơn" - "Hull"; "Luân-đôn" - "Luân Đôn",...</p>\r\n<p class="MsoNormal" style="text-align: justify;">+ Mỗi eBook ePUB đều có đánh dấu "HẾT." khi kết thúc tác phẩm.</p>\r\n<p class="MsoNormal" style="text-align: justify;">+ Nội dung chỉ ePubViet có: Phụ lục + Định dạng chữ - Ví dụ: eBook Mặt trời thi ca Nga của Aleksandre Pushkin.</p>\r\n<p>Phương châm làm việc của Thư viện ePubViet là cố gắng mang tới cho bạn những tác phẩm sách truyện chuẩn để các bạn thưởng thức nhưng trong quá trình làm việc, không tránh khỏi những sơ sót,trong eBook ePub vẫn còn một vài hạt những sạn: lỗi sai chính tả, bị thiếu nội dung,... ePub Việt rất mong nhận được ý kiến phản hồi, đóng góp của các bạn thông qua địa chỉ email: <a href="mailto:contact.epubviet@gmail.com">contact.epubviet@gmail.com</a></p>', '', 1, 2, '2014-09-17 09:27:50', 584, '', '2014-09-17 09:38:05', 584, 0, '0000-00-00 00:00:00', '2014-09-17 09:27:50', '0000-00-00 00:00:00', '{"image_intro":"","float_intro":"","image_intro_alt":"","image_intro_caption":"","image_fulltext":"","float_fulltext":"","image_fulltext_alt":"","image_fulltext_caption":""}', '{"urla":false,"urlatext":"","targeta":"","urlb":false,"urlbtext":"","targetb":"","urlc":false,"urlctext":"","targetc":""}', '{"show_title":"","link_titles":"","show_tags":"","show_intro":"","info_block_position":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_vote":"","show_hits":"","show_noauth":"","urls_position":"","alternative_readmore":"","article_layout":"","show_publishing_options":"","show_article_options":"","show_urls_images_backend":"","show_urls_images_frontend":""}', 4, 0, '', '', 1, 0, '{"robots":"","author":"","rights":"","xreference":""}', 0, '*', '');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_contentitem_tag_map`
--

CREATE TABLE IF NOT EXISTS `zjw8d_contentitem_tag_map` (
  `type_alias` varchar(255) NOT NULL DEFAULT '',
  `core_content_id` int(10) unsigned NOT NULL COMMENT 'PK from the core content table',
  `content_item_id` int(11) NOT NULL COMMENT 'PK from the content type table',
  `tag_id` int(10) unsigned NOT NULL COMMENT 'PK from the tag table',
  `tag_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date of most recent save for this tag-item',
  `type_id` mediumint(8) NOT NULL COMMENT 'PK from the content_type table'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Maps items from content tables to tags';

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_content_frontpage`
--

CREATE TABLE IF NOT EXISTS `zjw8d_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_content_frontpage`
--

INSERT INTO `zjw8d_content_frontpage` (`content_id`, `ordering`) VALUES
(8, 1),
(9, 6),
(10, 5),
(11, 4),
(12, 3),
(23, 2);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_content_rating`
--

CREATE TABLE IF NOT EXISTS `zjw8d_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(10) unsigned NOT NULL DEFAULT '0',
  `rating_count` int(10) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(50) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_content_types`
--

CREATE TABLE IF NOT EXISTS `zjw8d_content_types` (
`type_id` int(10) unsigned NOT NULL,
  `type_title` varchar(255) NOT NULL DEFAULT '',
  `type_alias` varchar(255) NOT NULL DEFAULT '',
  `table` varchar(255) NOT NULL DEFAULT '',
  `rules` text NOT NULL,
  `field_mappings` text NOT NULL,
  `router` varchar(255) NOT NULL DEFAULT '',
  `content_history_options` varchar(5120) DEFAULT NULL COMMENT 'JSON string for com_contenthistory options'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `zjw8d_content_types`
--

INSERT INTO `zjw8d_content_types` (`type_id`, `type_title`, `type_alias`, `table`, `rules`, `field_mappings`, `router`, `content_history_options`) VALUES
(1, 'Article', 'com_content.article', '{"special":{"dbtable":"#__content","key":"id","type":"Content","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"state","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"introtext", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"attribs", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"urls", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"asset_id"}, "special":{"fulltext":"fulltext"}}', 'ContentHelperRoute::getArticleRoute', '{"formFile":"administrator\\/components\\/com_content\\/models\\/forms\\/article.xml", "hideFields":["asset_id","checked_out","checked_out_time","version"],"ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "hits"],"convertToInt":["publish_up", "publish_down", "featured", "ordering"],"displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]}'),
(2, 'Weblink', 'com_weblinks.weblink', '{"special":{"dbtable":"#__weblinks","key":"id","type":"Weblink","prefix":"WeblinksTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"state","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"description", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"urls", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"null"}, "special":{}}', 'WeblinksHelperRoute::getWeblinkRoute', '{"formFile":"administrator\\/components\\/com_weblinks\\/models\\/forms\\/weblink.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","featured","images"], "ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "hits"], "convertToInt":["publish_up", "publish_down", "featured", "ordering"], "displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]}'),
(3, 'Contact', 'com_contact.contact', '{"special":{"dbtable":"#__contact_details","key":"id","type":"Contact","prefix":"ContactTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"name","core_state":"published","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"address", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"image", "core_urls":"webpage", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"null"}, "special":{"con_position":"con_position","suburb":"suburb","state":"state","country":"country","postcode":"postcode","telephone":"telephone","fax":"fax","misc":"misc","email_to":"email_to","default_con":"default_con","user_id":"user_id","mobile":"mobile","sortname1":"sortname1","sortname2":"sortname2","sortname3":"sortname3"}}', 'ContactHelperRoute::getContactRoute', '{"formFile":"administrator\\/components\\/com_contact\\/models\\/forms\\/contact.xml","hideFields":["default_con","checked_out","checked_out_time","version","xreference"],"ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "hits"],"convertToInt":["publish_up", "publish_down", "featured", "ordering"], "displayLookup":[ {"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ] }'),
(4, 'Newsfeed', 'com_newsfeeds.newsfeed', '{"special":{"dbtable":"#__newsfeeds","key":"id","type":"Newsfeed","prefix":"NewsfeedsTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"name","core_state":"published","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"description", "core_hits":"hits","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"link", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"xreference", "asset_id":"null"}, "special":{"numarticles":"numarticles","cache_time":"cache_time","rtl":"rtl"}}', 'NewsfeedsHelperRoute::getNewsfeedRoute', '{"formFile":"administrator\\/components\\/com_newsfeeds\\/models\\/forms\\/newsfeed.xml","hideFields":["asset_id","checked_out","checked_out_time","version"],"ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "hits"],"convertToInt":["publish_up", "publish_down", "featured", "ordering"],"displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]}'),
(5, 'User', 'com_users.user', '{"special":{"dbtable":"#__users","key":"id","type":"User","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"name","core_state":"null","core_alias":"username","core_created_time":"registerdate","core_modified_time":"lastvisitDate","core_body":"null", "core_hits":"null","core_publish_up":"null","core_publish_down":"null","access":"null", "core_params":"params", "core_featured":"null", "core_metadata":"null", "core_language":"null", "core_images":"null", "core_urls":"null", "core_version":"null", "core_ordering":"null", "core_metakey":"null", "core_metadesc":"null", "core_catid":"null", "core_xreference":"null", "asset_id":"null"}, "special":{}}', 'UsersHelperRoute::getUserRoute', ''),
(6, 'Article Category', 'com_content.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', 'ContentHelperRoute::getCategoryRoute', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(7, 'Contact Category', 'com_contact.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', 'ContactHelperRoute::getCategoryRoute', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(8, 'Newsfeeds Category', 'com_newsfeeds.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', 'NewsfeedsHelperRoute::getCategoryRoute', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(9, 'Weblinks Category', 'com_weblinks.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', 'WeblinksHelperRoute::getCategoryRoute', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(10, 'Tag', 'com_tags.tag', '{"special":{"dbtable":"#__tags","key":"tag_id","type":"Tag","prefix":"TagsTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"featured", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"urls", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"null", "core_xreference":"null", "asset_id":"null"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path"}}', 'TagsHelperRoute::getTagRoute', '{"formFile":"administrator\\/components\\/com_tags\\/models\\/forms\\/tag.xml", "hideFields":["checked_out","checked_out_time","version", "lft", "rgt", "level", "path", "urls", "publish_up", "publish_down"],"ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"],"convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"}, {"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}]}'),
(11, 'Banner', 'com_banners.banner', '{"special":{"dbtable":"#__banners","key":"id","type":"Banner","prefix":"BannersTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"name","core_state":"published","core_alias":"alias","core_created_time":"created","core_modified_time":"modified","core_body":"description", "core_hits":"null","core_publish_up":"publish_up","core_publish_down":"publish_down","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"images", "core_urls":"link", "core_version":"version", "core_ordering":"ordering", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"catid", "core_xreference":"null", "asset_id":"null"}, "special":{"imptotal":"imptotal", "impmade":"impmade", "clicks":"clicks", "clickurl":"clickurl", "custombannercode":"custombannercode", "cid":"cid", "purchase_type":"purchase_type", "track_impressions":"track_impressions", "track_clicks":"track_clicks"}}', '', '{"formFile":"administrator\\/components\\/com_banners\\/models\\/forms\\/banner.xml", "hideFields":["checked_out","checked_out_time","version", "reset"],"ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time", "version", "imptotal", "impmade", "reset"], "convertToInt":["publish_up", "publish_down", "ordering"], "displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}, {"sourceColumn":"cid","targetTable":"#__banner_clients","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"} ]}'),
(12, 'Banners Category', 'com_banners.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special": {"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', '', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["asset_id","checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"], "convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}'),
(13, 'Banner Client', 'com_banners.client', '{"special":{"dbtable":"#__banner_clients","key":"id","type":"Client","prefix":"BannersTable"}}', '', '', '', '{"formFile":"administrator\\/components\\/com_banners\\/models\\/forms\\/client.xml", "hideFields":["checked_out","checked_out_time"], "ignoreChanges":["checked_out", "checked_out_time"], "convertToInt":[], "displayLookup":[]}'),
(14, 'User Notes', 'com_users.note', '{"special":{"dbtable":"#__user_notes","key":"id","type":"Note","prefix":"UsersTable"}}', '', '', '', '{"formFile":"administrator\\/components\\/com_users\\/models\\/forms\\/note.xml", "hideFields":["checked_out","checked_out_time", "publish_up", "publish_down"],"ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time"], "convertToInt":["publish_up", "publish_down"],"displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}, {"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}]}'),
(15, 'User Notes Category', 'com_users.category', '{"special":{"dbtable":"#__categories","key":"id","type":"Category","prefix":"JTable","config":"array()"},"common":{"dbtable":"#__ucm_content","key":"ucm_id","type":"Corecontent","prefix":"JTable","config":"array()"}}', '', '{"common":{"core_content_item_id":"id","core_title":"title","core_state":"published","core_alias":"alias","core_created_time":"created_time","core_modified_time":"modified_time","core_body":"description", "core_hits":"hits","core_publish_up":"null","core_publish_down":"null","core_access":"access", "core_params":"params", "core_featured":"null", "core_metadata":"metadata", "core_language":"language", "core_images":"null", "core_urls":"null", "core_version":"version", "core_ordering":"null", "core_metakey":"metakey", "core_metadesc":"metadesc", "core_catid":"parent_id", "core_xreference":"null", "asset_id":"asset_id"}, "special":{"parent_id":"parent_id","lft":"lft","rgt":"rgt","level":"level","path":"path","extension":"extension","note":"note"}}', '', '{"formFile":"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml", "hideFields":["checked_out","checked_out_time","version","lft","rgt","level","path","extension"], "ignoreChanges":["modified_user_id", "modified_time", "checked_out", "checked_out_time", "version", "hits", "path"], "convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"created_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}, {"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_user_id","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"parent_id","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"}]}');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_core_log_searches`
--

CREATE TABLE IF NOT EXISTS `zjw8d_core_log_searches` (
  `search_term` varchar(128) NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_extensions`
--

CREATE TABLE IF NOT EXISTS `zjw8d_extensions` (
`extension_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `element` varchar(100) NOT NULL,
  `folder` varchar(100) NOT NULL,
  `client_id` tinyint(3) NOT NULL,
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  `access` int(10) unsigned DEFAULT NULL,
  `protected` tinyint(3) NOT NULL DEFAULT '0',
  `manifest_cache` text NOT NULL,
  `params` text NOT NULL,
  `custom_data` text NOT NULL,
  `system_data` text NOT NULL,
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10094 ;

--
-- Dumping data for table `zjw8d_extensions`
--

INSERT INTO `zjw8d_extensions` (`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES
(1, 'com_mailto', 'component', 'com_mailto', '', 0, 1, 1, 1, '{"legacy":false,"name":"com_mailto","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_MAILTO_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(2, 'com_wrapper', 'component', 'com_wrapper', '', 0, 1, 1, 1, '{"legacy":false,"name":"com_wrapper","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_WRAPPER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(3, 'com_admin', 'component', 'com_admin', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_admin","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_ADMIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(4, 'com_banners', 'component', 'com_banners', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_banners","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_BANNERS_XML_DESCRIPTION","group":""}', '{"purchase_type":"3","track_impressions":"0","track_clicks":"0","metakey_prefix":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(5, 'com_cache', 'component', 'com_cache', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_cache","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CACHE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(6, 'com_categories', 'component', 'com_categories', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_categories","type":"component","creationDate":"December 2007","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CATEGORIES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(7, 'com_checkin', 'component', 'com_checkin', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_checkin","type":"component","creationDate":"Unknown","author":"Joomla! Project","copyright":"(C) 2005 - 2008 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CHECKIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(8, 'com_contact', 'component', 'com_contact', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_contact","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CONTACT_XML_DESCRIPTION","group":""}', '{"contact_layout":"_:default","show_contact_category":"hide","show_contact_list":"0","presentation_style":"sliders","show_name":"1","show_position":"1","show_email":"0","show_street_address":"1","show_suburb":"1","show_state":"1","show_postcode":"1","show_country":"1","show_telephone":"1","show_mobile":"1","show_fax":"1","show_webpage":"1","show_misc":"1","show_image":"1","image":"","allow_vcard":"0","show_articles":"0","show_profile":"0","show_links":"0","linka_name":"","linkb_name":"","linkc_name":"","linkd_name":"","linke_name":"","contact_icons":"0","icon_address":"","icon_email":"","icon_telephone":"","icon_mobile":"","icon_fax":"","icon_misc":"","category_layout":"_:default","show_category_title":"1","show_description":"1","show_description_image":"0","maxLevel":"-1","show_empty_categories":"0","show_subcat_desc":"1","show_cat_items":"1","show_base_description":"1","maxLevelcat":"-1","show_empty_categories_cat":"0","show_subcat_desc_cat":"1","show_cat_items_cat":"1","show_pagination_limit":"1","show_headings":"1","show_position_headings":"1","show_email_headings":"0","show_telephone_headings":"1","show_mobile_headings":"0","show_fax_headings":"0","show_suburb_headings":"1","show_state_headings":"1","show_country_headings":"1","show_pagination":"2","show_pagination_results":"1","initial_sort":"ordering","show_email_form":"1","show_email_copy":"1","banned_email":"","banned_subject":"","banned_text":"","validate_session":"1","custom_reply":"0","redirect":"","show_feed_link":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(9, 'com_cpanel', 'component', 'com_cpanel', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_cpanel","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CPANEL_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10, 'com_installer', 'component', 'com_installer', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_installer","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_INSTALLER_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(11, 'com_languages', 'component', 'com_languages', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_languages","type":"component","creationDate":"2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_LANGUAGES_XML_DESCRIPTION","group":""}', '{"administrator":"en-GB","site":"vi-VN"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(12, 'com_login', 'component', 'com_login', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_login","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_LOGIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(13, 'com_media', 'component', 'com_media', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_media","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_MEDIA_XML_DESCRIPTION","group":""}', '{"upload_extensions":"bmp,csv,doc,gif,ico,jpg,jpeg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,GIF,ICO,JPG,JPEG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS","upload_maxsize":"10","file_path":"images","image_path":"images","restrict_uploads":"1","allowed_media_usergroup":"3","check_mime":"1","image_extensions":"bmp,gif,jpg,png","ignore_extensions":"","upload_mime":"image\\/jpeg,image\\/gif,image\\/png,image\\/bmp,application\\/x-shockwave-flash,application\\/msword,application\\/excel,application\\/pdf,application\\/powerpoint,text\\/plain,application\\/x-zip","upload_mime_illegal":"text\\/html","enable_flash":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(14, 'com_menus', 'component', 'com_menus', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_menus","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_MENUS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(15, 'com_messages', 'component', 'com_messages', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_messages","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_MESSAGES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(16, 'com_modules', 'component', 'com_modules', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_modules","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_MODULES_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(17, 'com_newsfeeds', 'component', 'com_newsfeeds', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_newsfeeds","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_NEWSFEEDS_XML_DESCRIPTION","group":""}', '{"show_feed_image":"1","show_feed_description":"1","show_item_description":"1","feed_word_count":"0","show_headings":"1","show_name":"1","show_articles":"0","show_link":"1","show_description":"1","show_description_image":"1","display_num":"","show_pagination_limit":"1","show_pagination":"1","show_pagination_results":"1","show_cat_items":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(18, 'com_plugins', 'component', 'com_plugins', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_plugins","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_PLUGINS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(19, 'com_search', 'component', 'com_search', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_search","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_SEARCH_XML_DESCRIPTION","group":""}', '{"enabled":"0","show_date":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(20, 'com_templates', 'component', 'com_templates', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_templates","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_TEMPLATES_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(21, 'com_weblinks', 'component', 'com_weblinks', '', 1, 1, 1, 0, '{"legacy":false,"name":"com_weblinks","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\n\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_WEBLINKS_XML_DESCRIPTION","group":""}', '{"target":"0","count_clicks":"1","icons":1,"link_icons":"","category_layout":"_:default","show_category_title":"1","show_description":"1","show_description_image":"1","maxLevel":"-1","show_empty_categories":"0","show_subcat_desc":"1","show_cat_num_links":"1","show_base_description":"1","maxLevelcat":"-1","show_empty_categories_cat":"0","show_subcat_desc_cat":"1","show_cat_num_links_cat":"1","show_pagination_limit":"1","show_headings":"1","show_link_description":"1","show_link_hits":"1","show_pagination":"2","show_pagination_results":"1","show_feed_link":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(22, 'com_content', 'component', 'com_content', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_content","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CONTENT_XML_DESCRIPTION","group":""}', '{"article_layout":"_:default","show_title":"1","link_titles":"1","show_intro":"1","show_category":"1","link_category":"1","show_parent_category":"0","link_parent_category":"0","show_author":"1","link_author":"0","show_create_date":"1","show_modify_date":"0","show_publish_date":"1","show_item_navigation":"1","show_vote":"0","show_readmore":"1","show_readmore_title":"1","readmore_limit":"100","show_icons":"1","show_print_icon":"0","show_email_icon":"0","show_hits":"1","show_noauth":"0","urls_position":"0","show_publishing_options":"1","show_article_options":"1","show_urls_images_frontend":"1","show_urls_images_backend":"1","targeta":0,"targetb":0,"targetc":0,"float_intro":"right","float_fulltext":"right","category_layout":"_:blog","show_category_title":"0","show_description":"0","show_description_image":"0","maxLevel":"1","show_empty_categories":"0","show_no_articles":"1","show_subcat_desc":"1","show_cat_num_articles":"0","show_base_description":"1","maxLevelcat":"-1","show_empty_categories_cat":"0","show_subcat_desc_cat":"1","show_cat_num_articles_cat":"1","num_leading_articles":"1","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"0","show_subcategory_content":"0","show_pagination_limit":"1","filter_field":"hide","show_headings":"1","list_show_date":"0","date_format":"","list_show_hits":"1","list_show_author":"1","orderby_pri":"order","orderby_sec":"rdate","order_date":"published","show_pagination":"2","show_pagination_results":"1","show_feed_link":"1","feed_summary":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(23, 'com_config', 'component', 'com_config', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_config","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_CONFIG_XML_DESCRIPTION","group":""}', '{"filters":{"1":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"9":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"6":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"7":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"2":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"3":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"4":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"5":{"filter_type":"BL","filter_tags":"","filter_attributes":""},"8":{"filter_type":"NONE","filter_tags":"","filter_attributes":""}}}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(24, 'com_redirect', 'component', 'com_redirect', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_redirect","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_REDIRECT_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(25, 'com_users', 'component', 'com_users', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_users","type":"component","creationDate":"April 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.\\t","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"COM_USERS_XML_DESCRIPTION","group":""}', '{"allowUserRegistration":"1","new_usertype":"2","useractivation":"1","frontend_userparams":"1","mailSubjectPrefix":"","mailBodySuffix":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(27, 'com_finder', 'component', 'com_finder', '', 1, 1, 0, 0, '', '{"show_description":"1","description_length":255,"allow_empty_query":"0","show_url":"0","show_autosuggest":"1","show_advanced":"1","expand_advanced":"0","show_date_filters":"0","sort_order":"relevance","sort_direction":"desc","highlight_terms":"1","opensearch_name":"","opensearch_description":"","batch_size":"50","memory_table_limit":30000,"title_multiplier":"1.7","text_multiplier":"0.7","meta_multiplier":"1.2","path_multiplier":"2.0","misc_multiplier":"0.3","stem":"1","stemmer":"porter_en"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(28, 'com_joomlaupdate', 'component', 'com_joomlaupdate', '', 1, 1, 0, 1, '{"legacy":false,"name":"com_joomlaupdate","type":"component","creationDate":"February 2012","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.2","description":"COM_JOOMLAUPDATE_XML_DESCRIPTION","group":""}', '{"updatesource":"sts","customurl":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(29, 'com_tags', 'component', 'com_tags', '', 1, 1, 1, 1, '{"legacy":false,"name":"com_tags","type":"component","creationDate":"March 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"COM_TAGS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(100, 'PHPMailer', 'library', 'phpmailer', '', 0, 1, 1, 1, '{"legacy":false,"name":"PHPMailer","type":"library","creationDate":"2001","author":"PHPMailer","copyright":"(c) 2001-2003, Brent R. Matzelle, (c) 2004-2009, Andy Prevost. All Rights Reserved., (c) 2010-2011, Jim Jagielski. All Rights Reserved.","authorEmail":"jimjag@gmail.com","authorUrl":"https:\\/\\/code.google.com\\/a\\/apache-extras.org\\/p\\/phpmailer\\/","version":"5.2","description":"LIB_PHPMAILER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(101, 'SimplePie', 'library', 'simplepie', '', 0, 1, 1, 1, '{"legacy":false,"name":"SimplePie","type":"library","creationDate":"2004","author":"SimplePie","copyright":"Copyright (c) 2004-2009, Ryan Parman and Geoffrey Sneddon","authorEmail":"","authorUrl":"http:\\/\\/simplepie.org\\/","version":"1.2","description":"LIB_SIMPLEPIE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(102, 'phputf8', 'library', 'phputf8', '', 0, 1, 1, 1, '{"legacy":false,"name":"phputf8","type":"library","creationDate":"2006","author":"Harry Fuecks","copyright":"Copyright various authors","authorEmail":"hfuecks@gmail.com","authorUrl":"http:\\/\\/sourceforge.net\\/projects\\/phputf8","version":"0.5","description":"LIB_PHPUTF8_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(103, 'Joomla! Platform', 'library', 'joomla', '', 0, 1, 1, 1, '{"legacy":false,"name":"Joomla! Platform","type":"library","creationDate":"2008","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"http:\\/\\/www.joomla.org","version":"11.4","description":"LIB_JOOMLA_XML_DESCRIPTION","group":""}', '{"mediaversion":"fe9efdd5a65910f3bc14f64b6d64de19"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(200, 'mod_articles_archive', 'module', 'mod_articles_archive', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_articles_archive","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters.\\n\\t\\tAll rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_ARTICLES_ARCHIVE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(201, 'mod_articles_latest', 'module', 'mod_articles_latest', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_articles_latest","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LATEST_NEWS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(202, 'mod_articles_popular', 'module', 'mod_articles_popular', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_articles_popular","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_POPULAR_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(203, 'mod_banners', 'module', 'mod_banners', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_banners","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_BANNERS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(204, 'mod_breadcrumbs', 'module', 'mod_breadcrumbs', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_breadcrumbs","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_BREADCRUMBS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(205, 'mod_custom', 'module', 'mod_custom', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_custom","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_CUSTOM_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(206, 'mod_feed', 'module', 'mod_feed', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_feed","type":"module","creationDate":"July 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_FEED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(207, 'mod_footer', 'module', 'mod_footer', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_footer","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_FOOTER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(208, 'mod_login', 'module', 'mod_login', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_login","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LOGIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(209, 'mod_menu', 'module', 'mod_menu', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_menu","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_MENU_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(210, 'mod_articles_news', 'module', 'mod_articles_news', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_articles_news","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_ARTICLES_NEWS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(211, 'mod_random_image', 'module', 'mod_random_image', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_random_image","type":"module","creationDate":"July 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_RANDOM_IMAGE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(212, 'mod_related_items', 'module', 'mod_related_items', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_related_items","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_RELATED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(213, 'mod_search', 'module', 'mod_search', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_search","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_SEARCH_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(214, 'mod_stats', 'module', 'mod_stats', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_stats","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_STATS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(215, 'mod_syndicate', 'module', 'mod_syndicate', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_syndicate","type":"module","creationDate":"May 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_SYNDICATE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(216, 'mod_users_latest', 'module', 'mod_users_latest', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_users_latest","type":"module","creationDate":"December 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_USERS_LATEST_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(217, 'mod_weblinks', 'module', 'mod_weblinks', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_weblinks","type":"module","creationDate":"July 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_WEBLINKS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(218, 'mod_whosonline', 'module', 'mod_whosonline', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_whosonline","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_WHOSONLINE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(219, 'mod_wrapper', 'module', 'mod_wrapper', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_wrapper","type":"module","creationDate":"October 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_WRAPPER_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(220, 'mod_articles_category', 'module', 'mod_articles_category', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_articles_category","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_ARTICLES_CATEGORY_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(221, 'mod_articles_categories', 'module', 'mod_articles_categories', '', 0, 1, 1, 0, '{"legacy":false,"name":"mod_articles_categories","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_ARTICLES_CATEGORIES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(222, 'mod_languages', 'module', 'mod_languages', '', 0, 1, 1, 1, '{"legacy":false,"name":"mod_languages","type":"module","creationDate":"February 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LANGUAGES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(223, 'mod_finder', 'module', 'mod_finder', '', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(300, 'mod_custom', 'module', 'mod_custom', '', 1, 1, 1, 1, '{"legacy":false,"name":"mod_custom","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_CUSTOM_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(301, 'mod_feed', 'module', 'mod_feed', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_feed","type":"module","creationDate":"July 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_FEED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(302, 'mod_latest', 'module', 'mod_latest', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_latest","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LATEST_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(303, 'mod_logged', 'module', 'mod_logged', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_logged","type":"module","creationDate":"January 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LOGGED_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(304, 'mod_login', 'module', 'mod_login', '', 1, 1, 1, 1, '{"legacy":false,"name":"mod_login","type":"module","creationDate":"March 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_LOGIN_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(305, 'mod_menu', 'module', 'mod_menu', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_menu","type":"module","creationDate":"March 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_MENU_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(307, 'mod_popular', 'module', 'mod_popular', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_popular","type":"module","creationDate":"July 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_POPULAR_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(308, 'mod_quickicon', 'module', 'mod_quickicon', '', 1, 1, 1, 1, '{"legacy":false,"name":"mod_quickicon","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_QUICKICON_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(309, 'mod_status', 'module', 'mod_status', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_status","type":"module","creationDate":"Feb 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_STATUS_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(310, 'mod_submenu', 'module', 'mod_submenu', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_submenu","type":"module","creationDate":"Feb 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_SUBMENU_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(311, 'mod_title', 'module', 'mod_title', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_title","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_TITLE_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(312, 'mod_toolbar', 'module', 'mod_toolbar', '', 1, 1, 1, 1, '{"legacy":false,"name":"mod_toolbar","type":"module","creationDate":"Nov 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_TOOLBAR_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(313, 'mod_multilangstatus', 'module', 'mod_multilangstatus', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_multilangstatus","type":"module","creationDate":"September 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_MULTILANGSTATUS_XML_DESCRIPTION","group":""}', '{"cache":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(314, 'mod_version', 'module', 'mod_version', '', 1, 1, 1, 0, '{"legacy":false,"name":"mod_version","type":"module","creationDate":"January 2012","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"MOD_VERSION_XML_DESCRIPTION","group":""}', '{"format":"short","product":"1","cache":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(315, 'mod_stats_admin', 'module', 'mod_stats_admin', '', 1, 1, 1, 0, '{"name":"mod_stats_admin","type":"module","creationDate":"September 2012","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"MOD_STATS_XML_DESCRIPTION","group":""}', '{"serverinfo":"0","siteinfo":"0","counter":"0","increase":"0","cache":"1","cache_time":"900","cachemode":"static"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(316, 'mod_tags_popular', 'module', 'mod_tags_popular', '', 0, 1, 1, 0, '{"name":"mod_tags_popular","type":"module","creationDate":"January 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.1.0","description":"MOD_TAGS_POPULAR_XML_DESCRIPTION","group":""}', '{"maximum":"5","timeframe":"alltime","owncache":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(317, 'mod_tags_similar', 'module', 'mod_tags_similar', '', 0, 1, 1, 0, '{"name":"mod_tags_similar","type":"module","creationDate":"January 2013","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.1.0","description":"MOD_TAGS_SIMILAR_XML_DESCRIPTION","group":""}', '{"maximum":"5","matchtype":"any","owncache":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(400, 'plg_authentication_gmail', 'plugin', 'gmail', 'authentication', 0, 0, 1, 0, '{"legacy":false,"name":"plg_authentication_gmail","type":"plugin","creationDate":"February 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_GMAIL_XML_DESCRIPTION","group":""}', '{"applysuffix":"0","suffix":"","verifypeer":"1","user_blacklist":""}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(401, 'plg_authentication_joomla', 'plugin', 'joomla', 'authentication', 0, 1, 1, 1, '{"legacy":false,"name":"plg_authentication_joomla","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_AUTH_JOOMLA_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(402, 'plg_authentication_ldap', 'plugin', 'ldap', 'authentication', 0, 0, 1, 0, '{"legacy":false,"name":"plg_authentication_ldap","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_LDAP_XML_DESCRIPTION","group":""}', '{"host":"","port":"389","use_ldapV3":"0","negotiate_tls":"0","no_referrals":"0","auth_method":"bind","base_dn":"","search_string":"","users_dn":"","username":"admin","password":"bobby7","ldap_fullname":"fullName","ldap_email":"mail","ldap_uid":"uid"}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(404, 'plg_content_emailcloak', 'plugin', 'emailcloak', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_emailcloak","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CONTENT_EMAILCLOAK_XML_DESCRIPTION","group":""}', '{"mode":"1"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(405, 'plg_content_geshi', 'plugin', 'geshi', 'content', 0, 0, 1, 0, '{"legacy":false,"name":"plg_content_geshi","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"","authorUrl":"qbnz.com\\/highlighter","version":"2.5.0","description":"PLG_CONTENT_GESHI_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(406, 'plg_content_loadmodule', 'plugin', 'loadmodule', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_loadmodule","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_LOADMODULE_XML_DESCRIPTION","group":""}', '{"style":"none"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(407, 'plg_content_pagebreak', 'plugin', 'pagebreak', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_pagebreak","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CONTENT_PAGEBREAK_XML_DESCRIPTION","group":""}', '{"title":"1","multipage_toc":"1","showall":"1"}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(408, 'plg_content_pagenavigation', 'plugin', 'pagenavigation', 'content', 0, 0, 1, 0, '{"legacy":false,"name":"plg_content_pagenavigation","type":"plugin","creationDate":"January 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_PAGENAVIGATION_XML_DESCRIPTION","group":""}', '{"position":"1"}', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(409, 'plg_content_vote', 'plugin', 'vote', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_vote","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_VOTE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(410, 'plg_editors_codemirror', 'plugin', 'codemirror', 'editors', 0, 1, 1, 1, '{"legacy":false,"name":"plg_editors_codemirror","type":"plugin","creationDate":"28 March 2011","author":"Marijn Haverbeke","copyright":"","authorEmail":"N\\/A","authorUrl":"","version":"1.0","description":"PLG_CODEMIRROR_XML_DESCRIPTION","group":""}', '{"linenumbers":"0","tabmode":"indent"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(411, 'plg_editors_none', 'plugin', 'none', 'editors', 0, 1, 1, 1, '{"legacy":false,"name":"plg_editors_none","type":"plugin","creationDate":"August 2004","author":"Unknown","copyright":"","authorEmail":"N\\/A","authorUrl":"","version":"2.5.0","description":"PLG_NONE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(412, 'plg_editors_tinymce', 'plugin', 'tinymce', 'editors', 0, 1, 1, 0, '{"legacy":false,"name":"plg_editors_tinymce","type":"plugin","creationDate":"2005-2012","author":"Moxiecode Systems AB","copyright":"Moxiecode Systems AB","authorEmail":"N\\/A","authorUrl":"tinymce.moxiecode.com\\/","version":"3.5.2","description":"PLG_TINY_XML_DESCRIPTION","group":""}', '{"mode":"1","skin":"0","compressed":"0","cleanup_startup":"0","cleanup_save":"2","entity_encoding":"raw","lang_mode":"0","lang_code":"en","text_direction":"ltr","content_css":"1","content_css_custom":"","relative_urls":"1","newlines":"0","invalid_elements":"script,applet,iframe","extended_elements":",@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight],@[data-lightbox],@[data-spotlight]","toolbar":"top","toolbar_align":"left","html_height":"550","html_width":"750","element_path":"1","fonts":"1","paste":"1","searchreplace":"1","insertdate":"1","format_date":"%Y-%m-%d","inserttime":"1","format_time":"%H:%M:%S","colors":"1","table":"1","smilies":"1","media":"1","hr":"1","directionality":"1","fullscreen":"1","style":"1","layer":"1","xhtmlxtras":"1","visualchars":"1","nonbreaking":"1","template":"1","blockquote":"1","wordcount":"1","advimage":"1","advlink":"1","autosave":"1","contextmenu":"1","inlinepopups":"1","safari":"0","custom_plugin":"","custom_button":""}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(413, 'plg_editors-xtd_article', 'plugin', 'article', 'editors-xtd', 0, 1, 1, 1, '{"legacy":false,"name":"plg_editors-xtd_article","type":"plugin","creationDate":"October 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_ARTICLE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(414, 'plg_editors-xtd_image', 'plugin', 'image', 'editors-xtd', 0, 1, 1, 0, '{"legacy":false,"name":"plg_editors-xtd_image","type":"plugin","creationDate":"August 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_IMAGE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(415, 'plg_editors-xtd_pagebreak', 'plugin', 'pagebreak', 'editors-xtd', 0, 1, 1, 0, '{"legacy":false,"name":"plg_editors-xtd_pagebreak","type":"plugin","creationDate":"August 2004","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_EDITORSXTD_PAGEBREAK_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(416, 'plg_editors-xtd_readmore', 'plugin', 'readmore', 'editors-xtd', 0, 1, 1, 0, '{"legacy":false,"name":"plg_editors-xtd_readmore","type":"plugin","creationDate":"March 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_READMORE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(417, 'plg_search_categories', 'plugin', 'categories', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_categories","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEARCH_CATEGORIES_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(418, 'plg_search_contacts', 'plugin', 'contacts', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_contacts","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEARCH_CONTACTS_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(419, 'plg_search_content', 'plugin', 'content', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_content","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEARCH_CONTENT_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(420, 'plg_search_newsfeeds', 'plugin', 'newsfeeds', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_newsfeeds","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEARCH_NEWSFEEDS_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(421, 'plg_search_weblinks', 'plugin', 'weblinks', 'search', 0, 1, 1, 0, '{"legacy":false,"name":"plg_search_weblinks","type":"plugin","creationDate":"November 2005","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEARCH_WEBLINKS_XML_DESCRIPTION","group":""}', '{"search_limit":"50","search_content":"1","search_archived":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0);
INSERT INTO `zjw8d_extensions` (`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES
(422, 'plg_system_languagefilter', 'plugin', 'languagefilter', 'system', 0, 0, 1, 1, '{"legacy":false,"name":"plg_system_languagefilter","type":"plugin","creationDate":"July 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SYSTEM_LANGUAGEFILTER_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(423, 'plg_system_p3p', 'plugin', 'p3p', 'system', 0, 1, 1, 0, '{"legacy":false,"name":"plg_system_p3p","type":"plugin","creationDate":"September 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_P3P_XML_DESCRIPTION","group":""}', '{"headers":"NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM"}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(424, 'plg_system_cache', 'plugin', 'cache', 'system', 0, 0, 1, 1, '{"legacy":false,"name":"plg_system_cache","type":"plugin","creationDate":"February 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CACHE_XML_DESCRIPTION","group":""}', '{"browsercache":"0","cachetime":"15"}', '', '', 0, '0000-00-00 00:00:00', 9, 0),
(425, 'plg_system_debug', 'plugin', 'debug', 'system', 0, 1, 1, 0, '{"legacy":false,"name":"plg_system_debug","type":"plugin","creationDate":"December 2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_DEBUG_XML_DESCRIPTION","group":""}', '{"profile":"1","queries":"1","memory":"1","language_files":"1","language_strings":"1","strip-first":"1","strip-prefix":"","strip-suffix":""}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(426, 'plg_system_log', 'plugin', 'log', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_log","type":"plugin","creationDate":"April 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_LOG_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(427, 'plg_system_redirect', 'plugin', 'redirect', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_redirect","type":"plugin","creationDate":"April 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_REDIRECT_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(428, 'plg_system_remember', 'plugin', 'remember', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_remember","type":"plugin","creationDate":"April 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_REMEMBER_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 7, 0),
(429, 'plg_system_sef', 'plugin', 'sef', 'system', 0, 1, 1, 0, '{"legacy":false,"name":"plg_system_sef","type":"plugin","creationDate":"December 2007","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SEF_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 8, 0),
(430, 'plg_system_logout', 'plugin', 'logout', 'system', 0, 1, 1, 1, '{"legacy":false,"name":"plg_system_logout","type":"plugin","creationDate":"April 2009","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SYSTEM_LOGOUT_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(431, 'plg_user_contactcreator', 'plugin', 'contactcreator', 'user', 0, 0, 1, 0, '{"legacy":false,"name":"plg_user_contactcreator","type":"plugin","creationDate":"August 2009","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CONTACTCREATOR_XML_DESCRIPTION","group":""}', '{"autowebpage":"","category":"34","autopublish":"0"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(432, 'plg_user_joomla', 'plugin', 'joomla', 'user', 0, 1, 1, 0, '{"legacy":false,"name":"plg_user_joomla","type":"plugin","creationDate":"December 2006","author":"Joomla! Project","copyright":"(C) 2005 - 2009 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_USER_JOOMLA_XML_DESCRIPTION","group":""}', '{"autoregister":"1"}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(433, 'plg_user_profile', 'plugin', 'profile', 'user', 0, 0, 1, 0, '{"legacy":false,"name":"plg_user_profile","type":"plugin","creationDate":"January 2008","author":"Joomla! Project","copyright":"(C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_USER_PROFILE_XML_DESCRIPTION","group":""}', '{"register-require_address1":"1","register-require_address2":"1","register-require_city":"1","register-require_region":"1","register-require_country":"1","register-require_postal_code":"1","register-require_phone":"1","register-require_website":"1","register-require_favoritebook":"1","register-require_aboutme":"1","register-require_tos":"1","register-require_dob":"1","profile-require_address1":"1","profile-require_address2":"1","profile-require_city":"1","profile-require_region":"1","profile-require_country":"1","profile-require_postal_code":"1","profile-require_phone":"1","profile-require_website":"1","profile-require_favoritebook":"1","profile-require_aboutme":"1","profile-require_tos":"1","profile-require_dob":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(434, 'plg_extension_joomla', 'plugin', 'joomla', 'extension', 0, 1, 1, 1, '{"legacy":false,"name":"plg_extension_joomla","type":"plugin","creationDate":"May 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_EXTENSION_JOOMLA_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(435, 'plg_content_joomla', 'plugin', 'joomla', 'content', 0, 1, 1, 0, '{"legacy":false,"name":"plg_content_joomla","type":"plugin","creationDate":"November 2010","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CONTENT_JOOMLA_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(436, 'plg_system_languagecode', 'plugin', 'languagecode', 'system', 0, 0, 1, 0, '{"legacy":false,"name":"plg_system_languagecode","type":"plugin","creationDate":"November 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_SYSTEM_LANGUAGECODE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 10, 0),
(437, 'plg_quickicon_joomlaupdate', 'plugin', 'joomlaupdate', 'quickicon', 0, 1, 1, 1, '{"legacy":false,"name":"plg_quickicon_joomlaupdate","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_QUICKICON_JOOMLAUPDATE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(438, 'plg_quickicon_extensionupdate', 'plugin', 'extensionupdate', 'quickicon', 0, 1, 1, 1, '{"legacy":false,"name":"plg_quickicon_extensionupdate","type":"plugin","creationDate":"August 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_QUICKICON_EXTENSIONUPDATE_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(439, 'plg_captcha_recaptcha', 'plugin', 'recaptcha', 'captcha', 0, 1, 1, 0, '{"legacy":false,"name":"plg_captcha_recaptcha","type":"plugin","creationDate":"December 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.0","description":"PLG_CAPTCHA_RECAPTCHA_XML_DESCRIPTION","group":""}', '{"public_key":"6Ld__eMSAAAAAKD1DRBRwpP7YQu1boE0WwmYYPih","private_key":"6Ld__eMSAAAAAErli3Nbe_kHyrNvI5qMIkvjmsyJ","theme":"clean"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(440, 'plg_system_highlight', 'plugin', 'highlight', 'system', 0, 1, 1, 0, '', '{}', '', '', 0, '0000-00-00 00:00:00', 7, 0),
(441, 'plg_content_finder', 'plugin', 'finder', 'content', 0, 0, 1, 0, '{"legacy":false,"name":"plg_content_finder","type":"plugin","creationDate":"December 2011","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"1.7.0","description":"PLG_CONTENT_FINDER_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(442, 'plg_finder_categories', 'plugin', 'categories', 'finder', 0, 1, 1, 0, '', '{}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(443, 'plg_finder_contacts', 'plugin', 'contacts', 'finder', 0, 1, 1, 0, '', '{}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(444, 'plg_finder_content', 'plugin', 'content', 'finder', 0, 1, 1, 0, '', '{}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(445, 'plg_finder_newsfeeds', 'plugin', 'newsfeeds', 'finder', 0, 1, 1, 0, '', '{}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(446, 'plg_finder_weblinks', 'plugin', 'weblinks', 'finder', 0, 1, 1, 0, '', '{}', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(447, 'plg_finder_tags', 'plugin', 'tags', 'finder', 0, 1, 1, 0, '{"name":"plg_finder_tags","type":"plugin","creationDate":"February 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.0.0","description":"PLG_FINDER_TAGS_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(505, 'beez5', 'template', 'beez5', '', 0, 1, 1, 0, '{"legacy":false,"name":"beez5","type":"template","creationDate":"21 May 2010","author":"Angie Radtke","copyright":"Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.","authorEmail":"a.radtke@derauftritt.de","authorUrl":"http:\\/\\/www.der-auftritt.de","version":"2.5.0","description":"TPL_BEEZ5_XML_DESCRIPTION","group":""}', '{"wrapperSmall":"53","wrapperLarge":"72","sitetitle":"","sitedescription":"","navposition":"center","html5":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(600, 'English (United Kingdom)', 'language', 'en-GB', '', 0, 1, 1, 1, '{"legacy":false,"name":"English (United Kingdom)","type":"language","creationDate":"2008-03-15","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.5","description":"en-GB site language","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(601, 'English (United Kingdom)', 'language', 'en-GB', '', 1, 1, 1, 1, '{"legacy":false,"name":"English (United Kingdom)","type":"language","creationDate":"2008-03-15","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"2.5.5","description":"en-GB administrator language","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(700, 'files_joomla', 'file', 'joomla', '', 0, 1, 1, 1, '{"legacy":false,"name":"files_joomla","type":"file","creationDate":"April 2013","author":"Joomla! Project","copyright":"(C) 2005 - 2013 Open Source Matters. All rights reserved","authorEmail":"admin@joomla.org","authorUrl":"www.joomla.org","version":"3.1.1","description":"FILES_JOOMLA_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10000, 'yoo_sphere', 'template', 'yoo_sphere', '', 0, 1, 1, 0, '{"name":"yoo_sphere","type":"template","creationDate":"August 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"1.0.1","description":"Sphere is the August 2012 theme of the YOOtheme club. It is based on YOOtheme''s Warp theme framework. NOTE: It is not free or public. This theme is for members of the YOOtheme club only.","group":""}', '{"config":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10001, 'Widgetkit', 'module', 'mod_widgetkit', '', 0, 1, 0, 0, '{"name":"Widgetkit","type":"module","creationDate":"May 2011","author":"YOOtheme","copyright":"Copyright (C) 2007 - 2011 YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"1.0.0","description":"Widgetkit module for Widgetkit developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{"widget_id":"","moduleclass_sfx":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10002, 'Widgetkit Twitter', 'module', 'mod_widgetkit_twitter', '', 0, 1, 0, 0, '{"name":"Widgetkit Twitter","type":"module","creationDate":"May 2011","author":"YOOtheme","copyright":"Copyright (C) 2007 - 2011 YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"1.0.0","description":"Twitter module for Widgetkit developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{"style":"list","from_user":"","to_user":"","ref_user":"","hashtag":"","word":"","nots":"","limit":"5","image_size":"48","show_image":"1","show_author":"1","show_date":"1","moduleclass_sfx":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10003, 'System - Widgetkit', 'plugin', 'widgetkit_system', 'system', 0, 1, 1, 0, '{"name":"System - Widgetkit","type":"plugin","creationDate":"May 2011","author":"YOOtheme","copyright":"Copyright (C) 2007 - 2011 YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"1.0.0","description":"Plugin for Widgetkit developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10004, 'Content - Widgetkit', 'plugin', 'widgetkit_content', 'content', 0, 1, 1, 0, '{"name":"Content - Widgetkit","type":"plugin","creationDate":"May 2011","author":"YOOtheme","copyright":"Copyright (C) 2007 - 2011 YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"1.0.0","description":"Plugin for Widgetkit developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10005, 'widgetkit', 'component', 'com_widgetkit', '', 1, 1, 0, 0, '{"name":"Widgetkit","type":"component","creationDate":"September 2014","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"1.5.5","description":"Widgetkit - A widget toolkit by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10006, 'PKG_JOOMLA', 'package', 'pkg_joomla', '', 0, 1, 1, 1, '{"legacy":false,"name":"PKG_JOOMLA","type":"package","creationDate":"2006","author":"Joomla! Project","copyright":"Copyright (C) 2005 - 2012 Open Source Matters. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"http:\\/\\/www.joomla.org","version":"2.5.0","description":"PKG_JOOMLA_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10007, 'System - Widgetkit ZOO', 'plugin', 'widgetkit_zoo', 'system', 0, 1, 1, 0, '{"name":"System - Widgetkit ZOO","type":"plugin","creationDate":"August 2013","author":"YOOtheme","copyright":"Copyright (C) 2007 - 2013 YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.1.0","description":"ZOO plugin for Widgetkit developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10008, 'System - Widgetkit Joomla', 'plugin', 'widgetkit_joomla', 'system', 0, 1, 1, 0, '{"name":"System - Widgetkit Joomla","type":"plugin","creationDate":"December 2011","author":"YOOtheme","copyright":"Copyright (C) 2007 - 2011 YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"1.0.0","description":"Joomla Content plugin for Widgetkit developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10027, 'Ø§Ù„Ù„ØºØ© Ø§Ù„Ø¹Ø±Ø¨ÙØ© Ù„Ù„Ù…Ø­Ø±Ø± TinyMCE', 'file', 'TinyMCE_ar-AA', '', 0, 1, 0, 0, '{"legacy":false,"name":"\\u0627\\u0644\\u0644\\u063a\\u0629 \\u0627\\u0644\\u0639\\u0631\\u0628\\u064a\\u0629 \\u0644\\u0644\\u0645\\u062d\\u0631\\u0631 TinyMCE","type":"file","creationDate":"20 March 2012","author":"Dr. Ashraf Damra","copyright":"(C) 2010-2011 Arabic Translation Team","authorEmail":"","authorUrl":"http:\\/\\/joomlacode.org\\/gf\\/project\\/arabic_unitag\\/","version":"3.4.3.2","description":"\\n\\t\\t<h3>\\u062a\\u0645 \\u0628\\u0646\\u062c\\u0627\\u062d \\u062a\\u0646\\u0635\\u064a\\u0628 \\u062d\\u0632\\u0645\\u0629 \\u0627\\u0644\\u0644\\u063a\\u0629 \\u0627\\u0644\\u0639\\u0631\\u0628\\u064a\\u0629 \\u0644\\u0644\\u0645\\u062d\\u0631\\u0631 TinyMCE 3 \\u0627\\u0644\\u0645\\u0639\\u062a\\u0645\\u062f \\u0641\\u064a \\u062c\\u0648\\u0645\\u0644\\u0627! 2.5<\\/h3>\\n\\t\\t<div style=\\"font-weight:normal\\">\\u062a\\u0630\\u0643\\u0631 \\u0623\\u0646\\u0647 \\u0645\\u0646 \\u0627\\u0644\\u0648\\u0627\\u062c\\u0628 \\u0627\\u062f\\u062e\\u0627\\u0644 \\u0643\\u0648\\u062f \\u0627\\u0644\\u0644\\u063a\\u0629 \\u0627\\u0644\\u0639\\u0631\\u0628\\u064a\\u0629 ar \\u0641\\u064a \\u062e\\u0627\\u0646\\u0629 \\u0627\\u0644\\u0644\\u063a\\u0629 \\u0639\\u0646\\u062f<a href=\\"index.php?option=com_plugins&view=plugins&filter_search=TinyMCE\\"><strong> \\u0627\\u062f\\u0627\\u0631\\u0629 \\u0627\\u0644\\u062a\\u0637\\u0628\\u064a\\u0642 \\u0627\\u0644\\u0645\\u0633\\u0627\\u0639\\u062f \\u0627\\u0644\\u0645\\u062d\\u0631\\u0631-TinyMCE <\\/strong><\\/a><br \\/>\\n\\t\\t\\n\\t","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10029, 'isis', 'template', 'isis', '', 1, 1, 1, 0, '{"name":"isis","type":"template","creationDate":"3\\/30\\/2012","author":"Kyle Ledbetter","copyright":"Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"","version":"1.0","description":"TPL_ISIS_XML_DESCRIPTION","group":""}', '{"templateColor":"","logoFile":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10030, 'protostar', 'template', 'protostar', '', 0, 1, 1, 0, '{"name":"protostar","type":"template","creationDate":"4\\/30\\/2012","author":"Kyle Ledbetter","copyright":"Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.","authorEmail":"admin@joomla.org","authorUrl":"","version":"1.0","description":"TPL_PROTOSTAR_XML_DESCRIPTION","group":""}', '{"templateColor":"","logoFile":"","googleFont":"1","googleFontName":"Open+Sans","fluidContainer":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10031, 'sh404sef', 'component', 'com_sh404sef', '', 1, 1, 0, 0, '{"name":"sh404SEF","type":"component","creationDate":"2014-07-01","author":"Yannick Gaultier","copyright":"(c) Yannick Gaultier 2014","authorEmail":"yannick@weeblr.com","authorUrl":"http:\\/\\/weeblr.com","version":"4.4.4.1791","description":"","group":""}', '{"version":"4.4.4.1791","Enabled":0,"replacement":"-","pagerep":"-","stripthese":",|~|!|@|%|^|(|)|<|>|:|;|{|}|[|]|&|`|\\u201e|\\u2039|\\u2019|\\u2018|\\u201c|\\u201d|\\u2022|\\u203a|\\u00ab|\\u00b4|\\u00bb|\\u00b0","shReplacements":"\\u0160|S, \\u0152|O, \\u017d|Z, \\u0161|s, \\u0153|oe, \\u017e|z, \\u0178|Y, \\u00a5|Y, \\u00b5|u, \\u00c0|A, \\u00c1|A, \\u00c2|A, \\u00c3|A, \\u00c4|A, \\u00c5|A, \\u00c6|A, \\u00c7|C, \\u00c8|E, \\u00c9|E, \\u00ca|E, \\u00cb|E, \\u00cc|I, \\u00cd|I, \\u00ce|I, \\u00cf|I, \\u00d0|D, \\u00d1|N, \\u00d2|O, \\u00d3|O, \\u00d4|O, \\u00d5|O, \\u00d6|O, \\u00d8|O, \\u00d9|U, \\u00da|U, \\u00db|U, \\u00dc|U, \\u00dd|Y, \\u00df|s, \\u00e0|a, \\u00e1|a, \\u00e2|a, \\u00e3|a, \\u00e4|a, \\u00e5|a, \\u00e6|a, \\u00e7|c, \\u00e8|e, \\u00e9|e, \\u00ea|e, \\u00eb|e, \\u00ec|i, \\u00ed|i, \\u00ee|i, \\u00ef|i, \\u00f0|o, \\u00f1|n, \\u00f2|o, \\u00f3|o, \\u00f4|o, \\u00f5|o, \\u00f6|o, \\u00f8|o, \\u00f9|u, \\u00fa|u, \\u00fb|u, \\u00fc|u, \\u00fd|y, \\u00ff|y, \\u00df|ss, \\u0103|a, \\u015f|s, \\u0163|t, \\u021b|t, \\u021a|T, \\u0218|S, \\u0219|s, \\u015e|S","suffix":".html","addFile":"","friendlytrim":"-|.","LowerCase":0,"ShowSection":0,"ShowCat":1,"UseAlias":1,"page404":0,"predefined":[],"shLog404Errors":1,"shUseURLCache":1,"shMaxURLInCache":10000,"shTranslateURL":1,"shInsertLanguageCode":1,"shInsertGlobalItemidIfNone":0,"shInsertTitleIfNoItemid":0,"shAlwaysInsertMenuTitle":0,"shAlwaysInsertItemid":0,"shDefaultMenuItemName":"","shAppendRemainingGETVars":1,"shVmInsertShopName":0,"shInsertProductId":0,"shVmUseProductSKU":0,"shVmInsertManufacturerName":0,"shInsertManufacturerId":0,"shVMInsertCategories":1,"shVmAdditionalText":1,"shVmInsertFlypage":1,"shInsertCategoryId":0,"shInsertNumericalId":0,"shInsertNumericalIdCatList":"","shRedirectNonSefToSef":1,"shRedirectJoomlaSefToSef":0,"shConfig_live_secure_site":"","shActivateIJoomlaMagInContent":1,"shInsertIJoomlaMagIssueId":0,"shInsertIJoomlaMagName":0,"shInsertIJoomlaMagMagazineId":0,"shInsertIJoomlaMagArticleId":0,"shInsertCBName":0,"shCBInsertUserName":0,"shCBInsertUserId":1,"shCBUseUserPseudo":1,"shLMDefaultItemid":0,"shInsertFireboardName":1,"shFbInsertCategoryName":1,"shFbInsertCategoryId":0,"shFbInsertMessageSubject":1,"shFbInsertMessageId":1,"shInsertMyBlogName":0,"shMyBlogInsertPostId":1,"shMyBlogInsertTagId":0,"shMyBlogInsertBloggerId":1,"shInsertDocmanName":0,"shDocmanInsertDocId":1,"shDocmanInsertDocName":1,"shDMInsertCategories":1,"shDMInsertCategoryId":0,"shEncodeUrl":0,"guessItemidOnHomepage":0,"shForceNonSefIfHttps":0,"shRewriteMode":0,"shRewriteStrings":["\\/","\\/index.php\\/","\\/index.php?\\/"],"shRecordDuplicates":1,"shRemoveGeneratorTag":1,"shPutH1Tags":0,"shMetaManagementActivated":1,"shInsertContentTableName":1,"shContentTableName":"Table","shAutoRedirectWww":0,"shVmInsertProductName":1,"shForcedHomePage":"","shInsertContentBlogName":0,"shContentBlogName":"","shInsertMTreeName":0,"shMTreeInsertListingName":1,"shMTreeInsertListingId":1,"shMTreePrependListingId":1,"shMTreeInsertCategories":1,"shMTreeInsertCategoryId":0,"shMTreeInsertUserName":1,"shMTreeInsertUserId":1,"shInsertNewsPName":0,"shNewsPInsertCatId":0,"shNewsPInsertSecId":0,"shInsertRemoName":0,"shRemoInsertDocId":1,"shRemoInsertDocName":1,"shRemoInsertCategories":1,"shRemoInsertCategoryId":0,"shCBShortUserURL":0,"shKeepStandardURLOnUpgrade":1,"shKeepCustomURLOnUpgrade":1,"shKeepMetaDataOnUpgrade":1,"shKeepModulesSettingsOnUpgrade":1,"shMultipagesTitle":1,"encode_page_suffix":"","encode_space_char":"","encode_lowercase":"","encode_strip_chars":"","spec_chars_d":null,"spec_chars":null,"content_page_format":null,"content_page_name":null,"shKeepConfigOnUpgrade":1,"shSecEnableSecurity":0,"shSecLogAttacks":0,"shSecOnlyNumVars":["itemid","limit","limitstart"],"shSecAlphaNumVars":[],"shSecNoProtocolVars":["task","option","no_html","mosmsg","lang"],"ipWhiteList":[],"ipBlackList":[],"uAgentWhiteList":[],"uAgentBlackList":[],"shSecCheckHoneyPot":0,"shSecHoneyPotKey":"","shSecEntranceText":"<p>Sorry. You are visiting this site from a suspicious IP address, which triggered our protection system.<\\/p>\\r\\n    <p>If you <strong>ARE NOT<\\/strong> a malware robot of any kind, please accept our apologies for the inconvenience. You can access the page by clicking here : ","shSecSmellyPotText":"The following link is here to further trap malicious internet robots, so please don''t click on it : ","monthsToKeepLogs":1,"shSecActivateAntiFlood":0,"shSecAntiFloodOnlyOnPOST":0,"shSecAntiFloodPeriod":10,"shSecAntiFloodCount":10,"shAdminInterfaceType":1,"shInsertNoFollowPDFPrint":1,"shInsertReadMorePageTitle":0,"shMultipleH1ToH2":0,"shVmUsingItemsPerPage":1,"shSecCheckPOSTData":1,"shSecCurMonth":0,"shSecLastUpdated":0,"shSecTotalAttacks":0,"shSecTotalConfigVars":0,"shSecTotalBase64":0,"shSecTotalScripts":0,"shSecTotalStandardVars":0,"shSecTotalImgTxtCmd":0,"shSecTotalIPDenied":0,"shSecTotalUserAgentDenied":0,"shSecTotalFlooding":0,"shSecTotalPHP":0,"shSecTotalPHPUserClicked":0,"shInsertSMFName":1,"shSMFItemsPerPage":20,"shInsertSMFBoardId":1,"shInsertSMFTopicId":1,"shinsertSMFUserName":0,"shInsertSMFUserId":1,"appendToPageTitle":"","prependToPageTitle":"","debugToLogFile":0,"debugStartedAt":0,"debugDuration":3600,"shInsertOutboundLinksImage":0,"shImageForOutboundLinks":"external-black.png","defaultParamList":"","useCatAlias":0,"useSecAlias":0,"useMenuAlias":0,"alwaysAppendItemsPerPage":0,"redirectToCorrectCaseUrl":1,"jclInsertEventId":0,"jclInsertCategoryId":0,"jclInsertCalendarId":0,"jclInsertCalendarName":0,"jclInsertDate":0,"jclInsertDateInEventView":1,"ContentTitleShowSection":0,"ContentTitleShowCat":1,"ContentTitleUseAlias":0,"ContentTitleUseCatAlias":0,"ContentTitleUseSecAlias":0,"pageTitleSeparator":" | ","ContentTitleInsertArticleId":0,"shInsertContentArticleIdCatList":"","shJSInsertJSName":1,"shJSShortURLToUserProfile":1,"shJSInsertUsername":1,"shJSInsertUserFullName":0,"shJSInsertUserId":0,"shJSInsertGroupCategory":1,"shJSInsertGroupCategoryId":0,"shJSInsertGroupId":0,"shJSInsertGroupBulletinId":0,"shJSInsertDiscussionId":1,"shJSInsertMessageId":1,"shJSInsertPhotoAlbum":1,"shJSInsertPhotoAlbumId":0,"shJSInsertPhotoId":1,"shJSInsertVideoCat":1,"shJSInsertVideoCatId":0,"shJSInsertVideoId":1,"shFbInsertUserName":1,"shFbInsertUserId":1,"shFbShortUrlToProfile":1,"shPageNotFoundItemid":0,"autoCheckNewVersion":1,"error404SubTemplate":"index","enablePageId":1,"analyticsEnabled":0,"analyticsReportsEnabled":1,"analyticsType":"ga","analyticsId":"","analyticsExcludeIP":[],"analyticsMaxUserLevel":"","analyticsUser":"","analyticsPassword":"","analyticsAccount":"","analyticsProfile":"","autoCheckNewAnalytics":1,"analyticsDashboardDateRange":"week","analyticsEnableTimeCollection":1,"analyticsEnableUserCollection":1,"analyticsDashboardDataType":"ga:pageviews","slowServer":0,"insertShortlinkTag":1,"insertRevCanTag":0,"insertAltShorterTag":0,"canReadRemoteConfig":0,"stopCreatingShurls":0,"shurlBlackList":"","shurlNonSefBlackList":"","includeContentCat":2,"includeContentCatCategories":4,"contentCategoriesSuffix":"all","contentTitleIncludeCat":0,"useContactCatAlias":0,"contactCategoriesSuffix":"all","includeContactCat":5,"includeContactCatCategories":2,"useWeblinksCatAlias":0,"weblinksCategoriesSuffix":"all","includeWeblinksCat":2,"includeWeblinksCatCategories":2,"liveSites":{"en-GB":""},"alternateTemplate":"","slugForUncategorizedContent":0,"slugForUncategorizedContact":0,"slugForUncategorizedWeblinks":0,"enableMultiLingualSupport":1,"enableOpenGraphData":0,"ogEnableDescription":1,"ogType":"article","ogImage":"","ogEnableSiteName":1,"ogSiteName":"","ogEnableLocation":0,"ogLatitude":"","ogLongitude":"","ogStreetAddress":"","ogLocality":"","ogPostalCode":"","ogRegion":"","ogCountryName":"","ogEnableContact":0,"ogEmail":"","ogPhoneNumber":"","ogFaxNumber":"","fbAdminIds":"","socialButtonType":"facebook","insertPaginationTags":1,"UrlCacheHandler":"File","displayUrlCacheStats":0,"analyticsUserGroups":null,"removeOtherCanonicals":1,"analyticsEdition":"none","analyticsUgaId":"","update_credentials_access":"","update_credentials_secret":"","analyticsGtmId":"","enableTwitterCards":0,"twitterCardsSiteAccount":"","twitterCardsCreatorAccount":"","twitterCardsCategories":"","enableGoogleAuthorship":0,"googleAuthorshipAuthorProfile":"","googleAuthorshipAuthorName":"","googleAuthorshipCategories":"","analyticsEnableAnonymization":0,"enableGooglePublisher":0,"googlePublisherUrl":"","com_events___manageURL":1,"languages_en-GB_translateURL":0,"languages_en-GB_insertCode":0,"languages_en-GB_pageText":"Page-%s","com_contact___compEnablePageId":1,"com_content___compEnablePageId":1,"com_newsfeeds___compEnablePageId":1,"com_poll___compEnablePageId":1,"com_user___compEnablePageId":1,"com_weblinks___compEnablePageId":1,"mobile_switch_enabled":"0","mobile_template":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10032, 'sh404sef - System plugin', 'plugin', 'sh404sef', 'system', 0, 1, 1, 0, '{"name":"sh404sef - System plugin","type":"plugin","creationDate":"2014-07-01","author":"Yannick Gaultier","copyright":"(c) Yannick Gaultier 2014","authorEmail":"yannick@weeblr.com","authorUrl":"http:\\/\\/weeblr.com","version":"4.4.4.1791","description":"Sh404sef main system plugin","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 10, 0),
(10033, 'plg_system_shlib', 'plugin', 'shlib', 'system', 0, 1, 1, 0, '{"name":"plg_system_shlib","type":"plugin","creationDate":"2014-06-11","author":"Yannick Gaultier","copyright":"(c) Yannick Gaultier 2013","authorEmail":"yannick@weeblr.com","authorUrl":"http:\\/\\/weeblr.com","version":"0.2.9.370","description":"PLG_SYSTEM_SHLIB_DESC","group":""}', '{"log_error":"0","log_alert":"0","log_debug":"0","log_info":"0","sharedmemory_cache_handler":"apc","sharedmemory_cache_host":"127.0.0.1","sharedmemory_cache_port":"11211","enable_query_cache":"0","enable_joomla_query_cache":"0"}', '', '', 0, '0000-00-00 00:00:00', -100, 0),
(10034, 'sh404sef - System mobile template switcher', 'plugin', 'shmobile', 'system', 0, 1, 1, 0, '{"name":"sh404sef - System mobile template switcher","type":"plugin","creationDate":"2014-07-01","author":"Yannick Gaultier","copyright":"(c) Yannick Gaultier 2014","authorEmail":"yannick@weeblr.com","authorUrl":"http:\\/\\/weeblr.com","version":"4.4.4.1791","description":"Switch site template for mobile devices","group":""}', '{"mobile_switch_enabled":"0","mobile_template":""}', '', '', 0, '0000-00-00 00:00:00', 10, 0),
(10035, 'sh404sef - Analytics plugin', 'plugin', 'sh404sefanalytics', 'sh404sefcore', 0, 1, 1, 0, '{"name":"sh404sef - Analytics plugin","type":"plugin","creationDate":"2014-07-01","author":"Yannick Gaultier","copyright":"(c) Yannick Gaultier 2014","authorEmail":"yannick@weeblr.com","authorUrl":"http:\\/\\/weeblr.com","version":"4.4.4.1791","description":"Create analytics custom tags\\n\\t","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 10, 0),
(10036, 'sh404sef - Offline code plugin', 'plugin', 'sh404sefofflinecode', 'sh404sefcore', 0, 1, 1, 0, '{"name":"sh404sef - Offline code plugin","type":"plugin","creationDate":"2014-07-01","author":"Yannick Gaultier","copyright":"(c) Yannick Gaultier 2014","authorEmail":"yannick@weeblr.com","authorUrl":"http:\\/\\/weeblr.com","version":"4.4.4.1791","description":"Render Joomla''s offline page with the appropriate http\\tresponse code\\t","group":""}', '{"disallowAdminAccess":"0","retry_after_delay":"7400"}', '', '', 0, '0000-00-00 00:00:00', 10, 0),
(10037, 'sh404sef - Similar urls plugin', 'plugin', 'sh404sefsimilarurls', 'sh404sefcore', 0, 1, 1, 0, '{"name":"sh404sef - Similar urls plugin","type":"plugin","creationDate":"2014-07-01","author":"Yannick Gaultier","copyright":"(c) Yannick Gaultier 2014","authorEmail":"yannick@weeblr.com","authorUrl":"http:\\/\\/weeblr.com","version":"4.4.4.1791","description":"Search for urls similar to that of the current page","group":""}', '{"max_number_of_urls":"5","min_segment_length":"3","include_pdf":"0","include_print":"0","excluded_words_sef":"__404__","excluded_words_non_sef":""}', '', '', 0, '0000-00-00 00:00:00', 10, 0),
(10038, 'PLG_SH404SEFCORE_SH404SEFSOCIAL', 'plugin', 'sh404sefsocial', 'sh404sefcore', 0, 1, 1, 0, '{"name":"PLG_SH404SEFCORE_SH404SEFSOCIAL","type":"plugin","creationDate":"2014-07-01","author":"Yannick Gaultier","copyright":"(c) Yannick Gaultier 2014","authorEmail":"yannick@weeblr.com","authorUrl":"http:\\/\\/weeblr.com","version":"4.4.4.1791","description":"PLG_SH404SEFCORE_SH404SEFSOCIAL_XML_DESCRIPTION","group":""}', '{"enableSocialAnalyticsIntegration":"1","enableGoogleSocialEngagement":"1","onlyDisplayOnCanonicalUrl":"1","buttonsContentLocation":"onlytags","useShurl":"1","enabledCategories":"show_on_all","enableFbLike":"1","enableFbShare":"1","enableFbSend":"1","fbLayout":"button_count","fbAction":"like","fbShowFaces":"1","fbColorscheme":"","fbWidth":"","fbUseHtml5":"0","enableTweet":"1","tweetLayout":"none","viaAccount":"","enablePinterestPinIt":"1","pinItCountLayout":"none","pinItButtonText":"","enablePlusOne":"1","plusOneSize":"","plusOneAnnotation":"none","enableGooglePlusPage":"1","googlePlusPage":"","googlePlusCustomText":"","googlePlusCustomText2":"","googlePlusPageSize":"medium","enableLinkedIn":"1","linkedinlayout":"none"}', '', '', 0, '0000-00-00 00:00:00', 10, 0),
(10039, 'plg_installer_sh404sef', 'plugin', 'sh404sef', 'installer', 0, 1, 1, 0, '{"name":"plg_installer_sh404sef","type":"plugin","creationDate":"2014-07-01","author":"Yannick Gaultier","copyright":"(c) Yannick Gaultier 2014","authorEmail":"yannick@weeblr.com","authorUrl":"http:\\/\\/weeblr.com","version":"4.4.4.1791","description":"Handle sh404SEF subscribers updates","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 10, 0),
(10040, 'sh404sef - Default component support plugin', 'plugin', 'sh404sefextplugindefault', 'sh404sefextplugins', 0, 1, 1, 0, '{"name":"sh404sef - Default component support plugin","type":"plugin","creationDate":"2014-07-01","author":"Yannick Gaultier","copyright":"(c) Yannick Gaultier 2014","authorEmail":"admin@anything-digital.com\\t","authorUrl":"anything-digital.com","version":"4.4.4.1791","description":"Provide default support for sef urls and meta data","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 10, 0),
(10041, 'sh404sef control panel icon', 'module', 'mod_sh404sef_cpicon', '', 1, 1, 3, 0, '{"name":"sh404sef control panel icon","type":"module","creationDate":"2014-07-01","author":"Yannick Gaultier","copyright":"(c) Yannick Gaultier 2014","authorEmail":"yannick@weeblr.com","authorUrl":"http:\\/\\/weeblr.com","version":"4.4.4.1791","description":"Quick access icon to reach sh404sef panel and analytics","group":""}', '{"moduleclass_sfx":"","cache":"0","cache_time":"900"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10042, 'System - AntiCopy', 'plugin', 'anticopy', 'system', 0, 1, 1, 0, '{"name":"System - AntiCopy","type":"plugin","creationDate":"2011-05-17","author":"Galaa","copyright":"Copyright (C) 2011-2013 Galaa","authorEmail":"contact@galaa.mn","authorUrl":"http:\\/\\/galaa.mn","version":"1.8.2","description":"This plugin restricts framing whole site, printing web page, and copying site contents by disabling the right click, highlight and copy functions using javascript. Copyright (C) 2011-2013 Galaa (http:\\/\\/galaa.mn\\/)","group":""}', '{"disallow_framing":"1","disallow_print":"1","disallow_printscreen":"1","disallow_r_click":"1","disallow_copy":"1","show_message":"1","message":"Stop copying the copyrighted material!"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10043, 'com_zoo', 'component', 'com_zoo', '', 1, 1, 0, 0, '{"name":"com_zoo","type":"component","creationDate":"August 2014","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.2.2","description":"ZOO component for Joomla 2.5+ developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10044, 'ZOO Category', 'module', 'mod_zoocategory', '', 0, 1, 0, 0, '{"name":"ZOO Category","type":"module","creationDate":"October 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.0.0","description":"Category module for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{"theme":"","application":"","depth":"0","add_count":"0","menu_item":"","moduleclass_sfx":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10045, 'ZOO Comment', 'module', 'mod_zoocomment', '', 0, 1, 0, 0, '{"name":"ZOO Comment","type":"module","creationDate":"October 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.0.0","description":"Comment module for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{"theme":"","application":"","subcategories":"0","count":"10","show_avatar":"1","avatar_size":"40","show_author":"1","show_meta":"1","moduleclass_sfx":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10046, 'ZOO Item', 'module', 'mod_zooitem', '', 0, 1, 0, 0, '{"name":"ZOO Item","type":"module","creationDate":"October 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.0.1","description":"Item module for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{"theme":"","layout":"","media_position":"left","application":"","subcategories":"0","count":"4","order":"_itemname","moduleclass_sfx":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10047, 'ZOO Quick Icons', 'module', 'mod_zooquickicon', '', 1, 1, 2, 0, '{"name":"ZOO Quick Icons","type":"module","creationDate":"October 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.0.0","description":"Quick Icons module for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(10048, 'ZOO Tag', 'module', 'mod_zootag', '', 0, 1, 0, 0, '{"name":"ZOO Tag","type":"module","creationDate":"October 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.0.0","description":"Tag module for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{"theme":"","application":"","subcategories":"0","count":"10","order":"alpha","menu_item":"","moduleclass_sfx":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10049, 'Content - ZOO Shortcode', 'plugin', 'zooshortcode', 'content', 0, 1, 1, 0, '{"name":"Content - ZOO Shortcode","type":"plugin","creationDate":"October 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.0.0","description":"Shortcode plugin for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com) Usage: {zooitem OR zoocategory: ID OR alias} Optionally: {zooitem: ID text: MYTEXT}","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10050, 'Smart Search - ZOO', 'plugin', 'zoosmartsearch', 'finder', 0, 1, 1, 0, '{"name":"Smart Search - ZOO","type":"plugin","creationDate":"Febuary 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"2.5.0","description":"Smart Search plugin for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10051, 'Search - ZOO', 'plugin', 'zoosearch', 'search', 0, 1, 1, 0, '{"name":"Search - ZOO","type":"plugin","creationDate":"October 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.0.0","description":"Search plugin for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{"search_fulltext":"0","search_limit":"50"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10052, 'System - ZOO Event', 'plugin', 'zooevent', 'system', 0, 1, 1, 0, '{"name":"System - ZOO Event","type":"plugin","creationDate":"October 2012","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.0.0","description":"Event plugin for ZOO developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10053, 'zoo', 'package', 'pkg_zoo', '', 0, 1, 1, 0, '{"name":"ZOO Package","type":"package","creationDate":"August 2014","author":"YOOtheme","copyright":"Copyright (C) YOOtheme GmbH","authorEmail":"info@yootheme.com","authorUrl":"http:\\/\\/www.yootheme.com","version":"3.2.2","description":"ZOO component and extensions for Joomla 2.5+ developed by YOOtheme (http:\\/\\/www.yootheme.com)","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10054, 'Vietnamese-VN', 'language', 'vi-VN', '', 0, 1, 0, 0, '{"name":"Vietnamese-VN","type":"language","creationDate":"December 2013","author":"Vietnamese Translation Team Translation Team","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"info@joomlaviet.info","authorUrl":"http:\\/\\/joomlaviet.info","version":"3.2.1.1","description":"Vietnamese language pack for Joomla! 3.2","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10055, 'Vietnamese-VN', 'language', 'vi-VN', '', 1, 1, 0, 0, '{"name":"Vietnamese-VN","type":"language","creationDate":"December 2013","author":"Vietnamese Translation Team","copyright":"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.","authorEmail":"info@joomlaviet.info","authorUrl":"http:\\/\\/joomlaviet.info","version":"3.2.1.1","description":"Vietnamese administration language for Joomla! 3.2","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10056, 'vi-VN', 'package', 'pkg_vi-VN', '', 0, 1, 1, 0, '{"name":"Vietnamese Language Pack","type":"package","creationDate":"December 2013","author":"Vietnamese Translation Team","copyright":"Copyright (C) 2013 joomlaviet.info and Open Source Matters. All rights reserved.","authorEmail":"info@joomlaviet.info","authorUrl":"http:\\/\\/joomlaviet.info","version":"3.2.1.1","description":"3.2.1.1 Joomla Vietnamese Language Package","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10057, 'System - Vinaora Vietnamese Alias', 'plugin', 'vinaora_vietalias', 'system', 0, 0, 1, 0, '{"name":"System - Vinaora Vietnamese Alias","type":"plugin","creationDate":"2012-06-17","author":"VINAORA","copyright":"Copyright (C) 2010-2012 VINAORA. All rights reserved.","authorEmail":"info@vinaora.com","authorUrl":"http:\\/\\/vinaora.com","version":"2.5.0","description":"PLG_SYSTEM_VINAORA_VIETALIAS_XML_DESCRIPTION","group":""}', '{"active_on":"1","active_on_specific":"com_content,com_categories,com_menus,com_banners,com_contact,com_newsfeeds,com_weblinks","auto_complete":"1","auto_complete_on_specific":"com_abc,com_xyz"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10058, 'plg_system_sl_scrolltotop', 'plugin', 'sl_scrolltotop', 'system', 0, 1, 1, 0, '{"name":"plg_system_sl_scrolltotop","type":"plugin","creationDate":"January 2012","author":"Pham Minh Tuan","copyright":"Copyright (c) 2013 Skyline. All rights reserved.","authorEmail":"admin@extstore.com","authorUrl":"http:\\/\\/extstore.com","version":"2.0.0","description":"\\n\\t\\n\\t\\tSkyline Scroll To Top Plugin For Joomla 1.7+<br \\/><br \\/>Developed by Skyline Software (<a target=\\"_blank\\" href=\\"http:\\/\\/extstore.com\\">http:\\/\\/extstore.com<\\/a>).\\n\\t\\n\\t","group":""}', '{"admin_enable":"1","engine":"jquery","image":"","text":"^ back to top","title":"Scroll to Top","background_color":"#262626","color":"#ffffff","hover_background_color":"#0088cc","hover_color":"#ffffff","position":"bottom_right","border_radius":"3","offset_x":"00","offset_y":"0","padding_x":"10","padding_y":"6","duration":"500","transition":"Fx.Transitions.linear","custom_css":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10059, 'MOD_TQUOTES', 'module', 'mod_tquotes', '', 0, 1, 0, 0, '{"name":"MOD_TQUOTES","type":"module","creationDate":"Jan 2013","author":"Kevin Burke","copyright":"(C) 2012-2013 Kevin Burke","authorEmail":"kevin@mytidbits.us","authorUrl":"www.mytidbits.us","version":"1.1.1","description":"MOD_TQUOTES_XML_DESCRIPTION","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10060, 'com_cmc', 'component', 'com_cmc', '', 1, 1, 0, 0, '{"name":"COM_CMC","type":"component","creationDate":"2014-10-08","author":"Compojoom.com","copyright":"(C) 2014 - compojoom.com","authorEmail":"contact-us@compojoom.com","authorUrl":"www.compojoom.com","version":"1.5.2","description":"Mailchimp list management for Joomla!","group":""}', '{"api_key":"8d32230513d964c4f43fb1b624998ec8-us7","webhooks_key":"391c147c14d23455104ea38ff0a17c7d"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10061, 'Community - CMC Registration plugin', 'plugin', 'cmc', 'community', 0, 0, 1, 0, '{"name":"Community - CMC Registration plugin","type":"plugin","creationDate":"2014-10-08","author":"compojoom.com","copyright":"Copyright (C) 2013 Daniel Dimitrov - compojoom.com. All rights reserved.","authorEmail":"","authorUrl":"http:\\/\\/compojoom.com","version":"1.5.2","description":"PLG_COMMUNITY_USER_REGISTRATION_DESCRIPTION","group":""}', '{"intro-text":"","outro-text-1":"","listid":"","fields":"","interests":"","dateFormat":"%Y-%m-%d","phoneFormat":"inter","address2":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10062, 'System - CMC Mailchimp ecommerce360', 'plugin', 'ecom360', 'system', 0, 0, 1, 0, '{"name":"System - CMC Mailchimp ecommerce360","type":"plugin","creationDate":"2014-10-08","author":"compojoom.com","copyright":"Copyright (C) 2012 Yves Hoppe - compojoom.com. All rights reserved.","authorEmail":"","authorUrl":"http:\\/\\/compojoom.com","version":"1.5.2","description":"PLG_SYSTEM_ECOMMERCE360_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10063, 'System - CMC Ecom360 Akeebasubs', 'plugin', 'ecom360akeeba', 'system', 0, 0, 1, 0, '{"name":"System - CMC Ecom360 Akeebasubs","type":"plugin","creationDate":"2014-10-08","author":"compojoom.com","copyright":"Copyright (C) 2012 Yves Hoppe - compojoom.com. All rights reserved.","authorEmail":"","authorUrl":"http:\\/\\/compojoom.com","version":"1.5.2","description":"PLG_SYSTEM_ECOM360_AKEEBA_DESCRIPTION","group":""}', '{"store_name":"AkeebaSubs store","store_id":"42"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10064, 'CMC - Ecom360 Hika', 'plugin', 'ecom360hika', 'system', 0, 0, 1, 0, '{"name":"CMC - Ecom360 Hika","type":"plugin","creationDate":"2014-10-08","author":"compojoom.com","copyright":"Copyright (C) 2012 Yves Hoppe - compojoom.com. All rights reserved.","authorEmail":"","authorUrl":"http:\\/\\/compojoom.com","version":"1.5.2","description":"PLG_SYSTEM_ECOM360_HIKA_DESCRIPTION","group":""}', '{"store_name":"HIKA store","store_id":"42"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10065, 'System - CMC ecom360 Matukio', 'plugin', 'ecom360matukio', 'system', 0, 0, 1, 0, '{"name":"System - CMC ecom360 Matukio","type":"plugin","creationDate":"2014-10-08","author":"compojoom.com","copyright":"Copyright (C) 2012 Yves Hoppe - compojoom.com. All rights reserved.","authorEmail":"","authorUrl":"http:\\/\\/compojoom.com","version":"1.5.2","description":"PLG_SYSTEM_ECOM360_MATUKIO_DESCRIPTION","group":""}', '{"store_name":"Matukio store","store_id":"42"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10066, 'System - CMC Ecom360 Payplans', 'plugin', 'ecom360payplans', 'system', 0, 0, 1, 0, '{"name":"System - CMC Ecom360 Payplans","type":"plugin","creationDate":"2014-10-08","author":"compojoom.com","copyright":"Copyright (C) 2012 Yves Hoppe - compojoom.com. All rights reserved.","authorEmail":"","authorUrl":"http:\\/\\/compojoom.com","version":"1.5.2","description":"PLG_SYSTEM_ECOM360_PAYPLANS_DESCRIPTION","group":""}', '{"store_name":"Payplans store","store_id":"42"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10067, 'System - CMC Ecom360 Redshop', 'plugin', 'ecom360redshop', 'system', 0, 0, 1, 0, '{"name":"System - CMC Ecom360 Redshop","type":"plugin","creationDate":"2014-10-08","author":"compojoom.com","copyright":"Copyright (C) 2012 Yves Hoppe - compojoom.com. All rights reserved.","authorEmail":"","authorUrl":"http:\\/\\/compojoom.com","version":"1.5.2","description":"PLG_SYSTEM_ECOM360_REDSHOP_DESCRIPTION","group":""}', '{"store_name":"REDSHOP store","store_id":"42"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10068, 'System - CMC Ecom360 Virtuemart', 'plugin', 'ecom360virtuemart', 'system', 0, 0, 1, 0, '{"name":"System - CMC Ecom360 Virtuemart","type":"plugin","creationDate":"2014-10-08","author":"compojoom.com","copyright":"Copyright (C) 2012 Yves Hoppe - compojoom.com. All rights reserved.","authorEmail":"","authorUrl":"http:\\/\\/compojoom.com","version":"1.5.2","description":"PLG_SYSTEM_ECOMMERCE360_VIRTUEMART_DESCRIPTION","group":""}', '{"store_name":"VIRTUEMART store","store_id":"42"}', '', '', 0, '0000-00-00 00:00:00', 0, 0);
INSERT INTO `zjw8d_extensions` (`extension_id`, `name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES
(10069, 'User - CMC Registration plugin', 'plugin', 'cmc', 'user', 0, 0, 1, 0, '{"name":"User - CMC Registration plugin","type":"plugin","creationDate":"2014-10-08","author":"compojoom.com","copyright":"Copyright (C) 2013 Yves Hoppe - compojoom.com. All rights reserved.","authorEmail":"","authorUrl":"http:\\/\\/compojoom.com","version":"1.5.2","description":"PLG_CMC_USER_REGISTRATION_DESCRIPTION","group":""}', '{"intro-text":"","outro-text":"","listid":"","fields":"","interests":"","dateFormat":"%Y-%m-%d","phoneFormat":"inter","address2":"0"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10070, 'mod_cmc', 'module', 'mod_cmc', '', 0, 1, 0, 0, '{"name":"mod_cmc","type":"module","creationDate":"2014-10-08","author":"compojoom.com","copyright":"Copyright (C) 2012 Daniel Dimitrov - compojoom.com. All rights reserved.","authorEmail":"daniel@compojoom.com","authorUrl":"compojoom.com","version":"1.5.2","description":"MOD_CMC_XML_DESCRIPTION","group":""}', '{"intro-text":"","outro-text-1":"","outro-text-2":"","thankyou":"Thank you! Please check your email and confirm the newsletter subscription.","listid":"","fields":"","interests":"","dateFormat":"%Y-%m-%d","phoneFormat":"inter","address2":"0","newsletterCheckbox":"0","jquery":"1","bootstrap_form":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10072, 'Library - compojoom', 'library', 'compojoom', '', 0, 1, 1, 0, '{"name":"Library - compojoom","type":"library","creationDate":"2014-10-08","author":"compojoom.com","copyright":"(C) 2008-2014 Daniel Dimitrov and Yves Hoppe","authorEmail":"daniel@compojoom.com","authorUrl":"https:\\/\\/compojoom.com","version":"4.0.12","description":"LIB_COMPOJOOM_DESC","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10073, 'plg_system_kunena', 'plugin', 'kunena', 'system', 0, 1, 1, 0, '{"name":"plg_system_kunena","type":"plugin","creationDate":"2014-07-28","author":"Kunena Team","copyright":"www.kunena.org","authorEmail":"Kunena@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.6","description":"PLG_SYSTEM_KUNENA_DESC","group":""}', '{"jcontentevents":"0","jcontentevent_target":"body"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10074, 'plg_quickicon_kunena', 'plugin', 'kunena', 'quickicon', 0, 1, 1, 0, '{"name":"plg_quickicon_kunena","type":"plugin","creationDate":"2014-07-28","author":"Kunena Team","copyright":"www.kunena.org","authorEmail":"Kunena@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.6","description":"PLG_QUICKICON_KUNENA_DESC","group":""}', '{"context":"mod_quickicon"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10075, 'Kunena Framework', 'library', 'kunena', '', 0, 1, 1, 0, '{"name":"Kunena Framework","type":"library","creationDate":"2014-07-28","author":"Kunena Team","copyright":"(C) 2008 - 2014 Kunena Team. All rights reserved.","authorEmail":"kunena@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.6","description":"Kunena Framework.","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10076, 'Kunena Media Files', 'file', 'kunena_media', '', 0, 1, 0, 0, '{"name":"Kunena Media Files","type":"file","creationDate":"2014-07-28","author":"Kunena Team","copyright":"(C) 2008 - 2014 Kunena Team. All rights reserved.","authorEmail":"kunena@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.6","description":"Kunena media files.","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10077, 'com_kunena', 'component', 'com_kunena', '', 1, 1, 0, 0, '{"name":"com_kunena","type":"component","creationDate":"2014-07-28","author":"Kunena Team","copyright":"(C) 2008 - 2014 Kunena Team. All rights reserved.","authorEmail":"kunena@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.6","description":"COM_KUNENA_XML_DESCRIPTION","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10078, 'kunena', 'package', 'pkg_kunena', '', 0, 1, 1, 0, '{"name":"Kunena Forum Package","type":"package","creationDate":"2014-07-28","author":"Kunena Team","copyright":"(C) 2008 - 2014 Kunena Team. All rights reserved.","authorEmail":"kunena@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.6","description":"Kunena Forum Package.","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10079, 'plg_kunena_alphauserpoints', 'plugin', 'alphauserpoints', 'kunena', 0, 0, 1, 0, '{"name":"plg_kunena_alphauserpoints","type":"plugin","creationDate":"2014-07-28","author":"Kunena Team","copyright":"www.kunena.org","authorEmail":"Kunena@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.6","description":"PLG_KUNENA_ALPHAUSERPOINTS_DESCRIPTION","group":""}', '{"activity":"1","avatar":"1","profile":"1","activity_points_limit":"0"}', '', '', 0, '0000-00-00 00:00:00', 1, 0),
(10080, 'plg_kunena_community', 'plugin', 'community', 'kunena', 0, 0, 1, 0, '{"name":"plg_kunena_community","type":"plugin","creationDate":"2014-07-28","author":"Kunena Team","copyright":"www.kunena.org","authorEmail":"Kunena@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.6","description":"PLG_KUNENA_COMMUNITY_DESCRIPTION","group":""}', '{"access":"1","login":"1","activity":"1","avatar":"1","profile":"1","private":"1","activity_points_limit":"0","activity_stream_limit":"0"}', '', '', 0, '0000-00-00 00:00:00', 2, 0),
(10081, 'plg_kunena_comprofiler', 'plugin', 'comprofiler', 'kunena', 0, 0, 1, 0, '{"name":"plg_kunena_comprofiler","type":"plugin","creationDate":"2014-07-28","author":"Kunena Team","copyright":"www.kunena.org","authorEmail":"Kunena@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.6","description":"PLG_KUNENA_COMPROFILER_DESCRIPTION","group":""}', '{"access":"1","login":"1","activity":"1","avatar":"1","profile":"1","private":"1"}', '', '', 0, '0000-00-00 00:00:00', 3, 0),
(10082, 'plg_kunena_gravatar', 'plugin', 'gravatar', 'kunena', 0, 0, 1, 0, '{"name":"plg_kunena_gravatar","type":"plugin","creationDate":"2014-07-28","author":"Kunena Team","copyright":"www.kunena.org","authorEmail":"Kunena@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.6","description":"PLG_KUNENA_GRAVATAR_DESCRIPTION","group":""}', '{"avatar":"1"}', '', '', 0, '0000-00-00 00:00:00', 4, 0),
(10083, 'plg_kunena_uddeim', 'plugin', 'uddeim', 'kunena', 0, 0, 1, 0, '{"name":"plg_kunena_uddeim","type":"plugin","creationDate":"2014-07-28","author":"Kunena Team","copyright":"www.kunena.org","authorEmail":"Kunena@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.6","description":"PLG_KUNENA_UDDEIM_DESCRIPTION","group":""}', '{"private":"1"}', '', '', 0, '0000-00-00 00:00:00', 5, 0),
(10084, 'plg_kunena_kunena', 'plugin', 'kunena', 'kunena', 0, 1, 1, 0, '{"name":"plg_kunena_kunena","type":"plugin","creationDate":"2014-07-28","author":"Kunena Team","copyright":"www.kunena.org","authorEmail":"Kunena@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.6","description":"PLG_KUNENA_KUNENA_DESCRIPTION","group":""}', '{"avatar":"1","profile":"1"}', '', '', 0, '0000-00-00 00:00:00', 6, 0),
(10085, 'plg_kunena_joomla', 'plugin', 'joomla', 'kunena', 0, 1, 1, 0, '{"name":"plg_kunena_joomla","type":"plugin","creationDate":"2014-07-28","author":"Kunena Team","copyright":"www.kunena.org","authorEmail":"Kunena@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.6","description":"PLG_KUNENA_JOOMLA_25_30_DESCRIPTION","group":""}', '{"access":"1","login":"1"}', '', '', 0, '0000-00-00 00:00:00', 7, 0),
(10086, 'Kunena Language - Vietnamese', 'file', 'com_kunena_vi-VN', '', 0, 1, 0, 0, '{"name":"Kunena Language - Vietnamese","type":"file","creationDate":"2014-07-28","author":"Kunena Team","copyright":"(C) 2008 - 2014 Kunena Team. All rights reserved.","authorEmail":"translations@kunena.org","authorUrl":"https:\\/\\/www.transifex.net\\/projects\\/p\\/Kunena\\/teams\\/","version":"3.0.6","description":"Vietnamese language file for Kunena Forum Component","group":""}', '', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10087, 'kunena_languages', 'package', 'pkg_kunena_languages', '', 0, 1, 1, 0, '{"name":"Kunena Language Pack","type":"package","creationDate":"2014-07-28","author":"Kunena Team","copyright":"(C) 2008 - 2014 Kunena Team. All rights reserved.","authorEmail":"kunena@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.6","description":"Language pack for Kunena forum component.","group":""}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10088, 'plg_search_kunena', 'plugin', 'kunena', 'search', 0, 0, 1, 0, '{"name":"plg_search_kunena","type":"plugin","creationDate":"2013-06-29","author":"Kunena Team","copyright":"(C) 2008 - 2013 Kunena Team. All rights reserved.","authorEmail":"admin@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.1","description":"PLG_SEARCH_KUNENA_DESCRIPTION","group":""}', '{"search_limit":"50","content_limit":"40","show_bbcode":"1","open_new_page":"1"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10089, 'plg_content_kunenadiscuss', 'plugin', 'kunenadiscuss', 'content', 0, 0, 1, 0, '{"name":"plg_content_kunenadiscuss","type":"plugin","creationDate":"2013-06-29","author":"Kunena Team","copyright":"(C) 2008 - 2013 Kunena Team. All rights reserved.","authorEmail":"admin@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.1","description":"PLG_KUNENADISCUSS_DESCRIPTION","group":""}', '{"limit":"25","ordering":"1","show_front_page":"2","show_blog_page":"2","show_other_pages":"2","form":"1","form_location":"0","custom_topics":"1","create":"0","create_time":"1","close_time":"0","close_reason":"0","bbcode":"default","topic_owner":"","category_mapping":"","default_category":"","allow_categories":"","deny_categories":"","show_debug":"0","show_debug_userids":""}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10090, 'mod_kunenastats', 'module', 'mod_kunenastats', '', 0, 1, 0, 0, '{"name":"mod_kunenastats","type":"module","creationDate":"2013-06-29","author":"Kunena Team","copyright":"(C) 2008 - 2013 Kunena Team. All rights reserved.","authorEmail":"admin@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.1","description":"MOD_KUNENASTATS_DESCRIPTION","group":""}', '{"type":"general","items":"5","titlelength":"50","sh_statslink":"0","owncache":"1","cache_time":"180"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10091, 'mod_kunenalogin', 'module', 'mod_kunenalogin', '', 0, 1, 0, 0, '{"name":"mod_kunenalogin","type":"module","creationDate":"2013-06-29","author":"Kunena Team","copyright":"(C) 2008 - 2013 Kunena Team. All rights reserved.","authorEmail":"admin@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.1","description":"MOD_KUNENALOGIN_DESCRIPTION","group":""}', '{"template":"vertical","pretext":"","login":"","logout":"","greeting":"1","lastlog":"1","showav":"1","avatar_w":"128px","avatar_h":"128px","showprofile":"1","showmyposts":"1","showrecent":"1","showmessage":"0","owncache":"1","cache_time":"180"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10092, 'mod_kunenalatest', 'module', 'mod_kunenalatest', '', 0, 1, 0, 0, '{"name":"mod_kunenalatest","type":"module","creationDate":"2013-06-29","author":"Kunena Team","copyright":"(C) 2008 - 2013 Kunena Team. All rights reserved.","authorEmail":"admin@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.1","description":"MOD_KUNENALATEST_DESCRIPTION","group":""}', '{"category_id":"0","sh_category_id_in":"1","choosemodel":"latest","show_list_time":"168","nbpost":"5","titlelength":"50","messagelength":"150","lengthcontentcharacters":"0","unreadindicator":"!","sh_topiciconoravatar":"0","avatarwidth":"36px","avatarheight":"36px","sh_category":"1","sh_author":"1","sh_time":"1","sh_firstcontentcharacter":"0","sh_favorite":"0","sh_locked":"0","sh_sticky":"0","sh_postcount":"0","kunena_load_css":"1","sh_morelink":"0","subjecttitle":"none","owncache":"1","cache_time":"180"}', '', '', 0, '0000-00-00 00:00:00', 0, 0),
(10093, 'mod_kunenasearch', 'module', 'mod_kunenasearch', '', 0, 1, 0, 0, '{"name":"mod_kunenasearch","type":"module","creationDate":"2013-06-29","author":"Kunena Team","copyright":"(C) 2008 - 2013 Kunena Team. All rights reserved.","authorEmail":"admin@kunena.org","authorUrl":"http:\\/\\/www.kunena.org","version":"3.0.1","description":"MOD_KUNENASEARCH_DESCRIPTION","group":""}', '{"ksearch_width":"20","ksearch_txt":"","ksearch_button":"","ksearch_button_pos":"right","ksearch_button_txt":"Search","owncache":"1","cache_time":"180"}', '', '', 0, '0000-00-00 00:00:00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_filters`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_filters` (
`filter_id` int(10) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL,
  `created_by_alias` varchar(255) NOT NULL,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `map_count` int(10) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `params` mediumtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_links`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_links` (
`link_id` int(10) unsigned NOT NULL,
  `url` varchar(255) NOT NULL,
  `route` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `indexdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `md5sum` varchar(32) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `state` int(5) DEFAULT '1',
  `access` int(5) DEFAULT '0',
  `language` varchar(8) NOT NULL,
  `publish_start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `list_price` double unsigned NOT NULL DEFAULT '0',
  `sale_price` double unsigned NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL,
  `object` mediumblob NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=59 ;

--
-- Dumping data for table `zjw8d_finder_links`
--

INSERT INTO `zjw8d_finder_links` (`link_id`, `url`, `route`, `title`, `description`, `indexdate`, `md5sum`, `published`, `state`, `access`, `language`, `publish_start_date`, `publish_end_date`, `start_date`, `end_date`, `list_price`, `sale_price`, `type_id`, `object`) VALUES
(7, 'index.php?option=com_zoo&view=item&id=1', 'index.php?option=com_zoo&task=item&item_id=1', 'Giới thiệu', '', '2014-09-18 11:35:18', '8d13815d9e501616733d566072970cd8', 1, 1, 1, '*', '2014-09-18 04:30:52', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31393a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a313a2231223b733a353a22616c696173223b733a31303a2267696f692d7468696575223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d30392d31382030343a33353a3137223b733a31313a226d6f6469666965645f6279223b733a333a22353834223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a34343a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d31223b733a31323a22656c656d656e745f64617461223b613a303a7b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a313a7b733a343a2254797065223b613a313a7b733a343a2250616765223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a343a2250616765223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a33393a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d31223b733a353a22726f757465223b733a34343a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d31223b733a353a227469746c65223b733a31343a224769e1bb9b6920746869e1bb8775223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d30392d31382030343a33303a3532223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b733a31353a2264656661756c744c616e6775616765223b733a353a22656e2d4742223b7d),
(8, 'index.php?option=com_zoo&view=item&id=2', 'index.php?option=com_zoo&task=item&item_id=2', 'Ủng hộ', '', '2014-09-18 11:42:28', 'c32fff5da7733395b0eb33f53ebdaef7', 1, 1, 1, '*', '2014-09-18 04:35:21', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31393a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a313a2232223b733a353a22616c696173223b733a363a22756e672d686f223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d30392d31382030343a34323a3237223b733a31313a226d6f6469666965645f6279223b733a333a22353834223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a34343a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d32223b733a31323a22656c656d656e745f64617461223b613a303a7b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a313a7b733a343a2254797065223b613a313a7b733a343a2250616765223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a343a2250616765223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a33393a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d32223b733a353a22726f757465223b733a34343a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d32223b733a353a227469746c65223b733a31303a22e1bba66e672068e1bb99223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d30392d31382030343a33353a3231223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b733a31353a2264656661756c744c616e6775616765223b733a353a22656e2d4742223b7d),
(9, 'index.php?option=com_zoo&view=item&id=3', 'index.php?option=com_zoo&task=item&item_id=3', 'Hướng dẫn gửi sách', '', '2014-09-18 11:43:19', '3a2f5938cdf789d8845c1d326c8e8f38', 1, 1, 1, '*', '2014-09-18 04:42:32', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31393a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a313a2233223b733a353a22616c696173223b733a31383a2268756f6e672d64616e2d6775692d73616368223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d30392d31382030343a34333a3139223b733a31313a226d6f6469666965645f6279223b733a333a22353834223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a34343a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d33223b733a31323a22656c656d656e745f64617461223b613a303a7b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a313a7b733a343a2254797065223b613a313a7b733a343a2250616765223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a343a2250616765223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a33393a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d33223b733a353a22726f757465223b733a34343a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d33223b733a353a227469746c65223b733a32363a2248c6b0e1bb9b6e672064e1baab6e2067e1bbad692073c3a16368223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d30392d31382030343a34323a3332223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b733a31353a2264656661756c744c616e6775616765223b733a353a22656e2d4742223b7d),
(12, 'index.php?option=com_zoo&view=item&id=4', 'index.php?option=com_zoo&task=item&item_id=4', 'ePub Việt', '', '2014-09-18 11:52:23', 'a707796b8b6bea47299d4397cca4654a', 1, 1, 1, '*', '2014-09-18 04:50:13', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31393a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a313a2234223b733a353a22616c696173223b733a393a22657075622d76692d74223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d30392d31382030343a35323a3233223b733a31313a226d6f6469666965645f6279223b733a333a22353834223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a34343a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d34223b733a31323a22656c656d656e745f64617461223b613a303a7b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a313a7b733a343a2254797065223b613a313a7b733a383a22456d706c6f796565223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a383a22456d706c6f796565223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a33393a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d34223b733a353a22726f757465223b733a34343a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d34223b733a353a227469746c65223b733a31313a2265507562205669e1bb8774223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d30392d31382030343a35303a3133223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b733a31353a2264656661756c744c616e6775616765223b733a353a22656e2d4742223b7d),
(13, 'index.php?option=com_zoo&view=item&id=5', 'index.php?option=com_zoo&task=item&item_id=5', 'ePub Việt', '', '2014-09-18 11:52:47', 'f2569ee9032f0bd638ed64ea053bcaf8', 1, 1, 1, '*', '2014-09-18 04:52:29', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31393a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a313a2235223b733a353a22616c696173223b733a31373a2274686f6e672d74696e2d6c69656e2d6865223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d30392d31382030343a35323a3436223b733a31313a226d6f6469666965645f6279223b733a333a22353834223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a34343a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d35223b733a31323a22656c656d656e745f64617461223b613a313a7b693a303b733a333a22302e30223b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a313a7b733a343a2254797065223b613a313a7b733a373a22436f6d70616e79223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a373a22436f6d70616e79223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a33393a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d35223b733a353a22726f757465223b733a34343a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d35223b733a353a227469746c65223b733a31313a2265507562205669e1bb8774223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d30392d31382030343a35323a3239223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b733a31353a2264656661756c744c616e6775616765223b733a353a22656e2d4742223b7d),
(41, 'index.php?option=com_zoo&view=item&id=6', 'index.php?option=com_zoo&task=item&item_id=6&Itemid=226', 'Harry Potter và Hòn đá phù thủy', '', '2014-09-30 18:48:29', '3109e37deaccf3b432a46353eb148656', 1, 1, 1, '*', '2014-09-30 09:12:17', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31393a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a313a2236223b733a353a22616c696173223b733a33313a2268617272792d706f747465722d76612d686f6e2d64612d7068752d74687579223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d30392d33302030393a33383a3439223b733a31313a226d6f6469666965645f6279223b733a333a22353835223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a38343a22696e6465782e7068702f736163682d7669656e2d74756f6e672d7468616e2d74686f61692f7669656e2d74756f6e672f6974656d2f68617272792d706f747465722d76612d686f6e2d64612d7068752d74687579223b733a31323a22656c656d656e745f64617461223b613a323a7b693a303b733a333a22302e30223b693a313b733a31363a225469c3aacc816e67205669c3aacca374223b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a323a7b733a343a2254797065223b613a313a7b733a31313a2254c3a163207068e1baa96d223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31313a2254c3a163207068e1baa96d223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d733a383a2243617465676f7279223b613a333a7b733a31353a225669e1bb856e2074c6b0e1bb9f6e67223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31353a225669e1bb856e2074c6b0e1bb9f6e67223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a32343a2248e1bb8d63207472c3b2202d20546869e1babf75206e6869223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a32343a2248e1bb8d63207472c3b2202d20546869e1babf75206e6869223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a33323a225669e1bb856e2074c6b0e1bb9f6e67202d205468e1baa76e2074686fe1baa169223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a33323a225669e1bb856e2074c6b0e1bb9f6e67202d205468e1baa76e2074686fe1baa169223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a33393a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d36223b733a353a22726f757465223b733a35353a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d36264974656d69643d323236223b733a353a227469746c65223b733a33383a22486172727920506f747465722076c3a02048c3b26e20c491c3a1207068c3b9207468e1bba779223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d30392d33302030393a31323a3137223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b733a31353a2264656661756c744c616e6775616765223b733a353a2276692d564e223b7d),
(45, 'index.php?option=com_zoo&view=item&id=12', 'index.php?option=com_zoo&task=item&item_id=12&Itemid=225', 'Harry Potter và Tên tù nhân ngục Azkaban', '', '2014-10-08 14:16:53', '69a4c2807080f439b70d6c241f6c2121', 1, 1, 1, '*', '2014-09-30 11:11:34', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31393a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a323a223132223b733a353a22616c696173223b733a34303a2268617272792d706f747465722d76612d74656e2d74752d6e68616e2d6e6775632d617a6b6162616e223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d30392d33302031313a31323a3235223b733a31313a226d6f6469666965645f6279223b733a333a22353835223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a38323a22696e6465782e7068702f736163682d7669656e2d74756f6e672d7468616e2d74686f61692f6974656d2f68617272792d706f747465722d76612d74656e2d74752d6e68616e2d6e6775632d617a6b6162616e223b733a31323a22656c656d656e745f64617461223b613a323a7b693a303b733a333a22302e30223b693a313b733a32393a225469c3aacc816e67205669c3aacca3740a5469c3aacc816e6720416e68223b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a323a7b733a343a2254797065223b613a313a7b733a31313a2254c3a163207068e1baa96d223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31313a2254c3a163207068e1baa96d223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d733a383a2243617465676f7279223b613a333a7b733a31353a225669e1bb856e2074c6b0e1bb9f6e67223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31353a225669e1bb856e2074c6b0e1bb9f6e67223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a31373a225475e1bb95692068e1bb8d63207472c3b2223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31373a225475e1bb95692068e1bb8d63207472c3b2223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a33323a225669e1bb856e2074c6b0e1bb9f6e67202d205468e1baa76e2074686fe1baa169223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a33323a225669e1bb856e2074c6b0e1bb9f6e67202d205468e1baa76e2074686fe1baa169223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a34303a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d3132223b733a353a22726f757465223b733a35363a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d3132264974656d69643d323235223b733a353a227469746c65223b733a34363a22486172727920506f747465722076c3a02054c3aa6e2074c3b9206e68c3a26e206e67e1bba56320417a6b6162616e223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d30392d33302031313a31313a3334223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b733a31353a2264656661756c744c616e6775616765223b733a353a2276692d564e223b7d),
(46, 'index.php?option=com_zoo&view=item&id=11', 'index.php?option=com_zoo&task=item&item_id=11&Itemid=226', 'Harry Potter và Phòng chứa bí mật', '', '2014-10-08 14:16:54', '56c3822f0bb8275d7236c673f1fdb31a', 1, 1, 1, '*', '2014-09-30 09:12:17', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31393a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a323a223131223b733a353a22616c696173223b733a33333a2268617272792d706f747465722d76612d70686f6e672d636875612d62692d6d6174223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d30392d33302031303a30363a3136223b733a31313a226d6f6469666965645f6279223b733a333a22353835223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a38363a22696e6465782e7068702f736163682d7669656e2d74756f6e672d7468616e2d74686f61692f7669656e2d74756f6e672f6974656d2f68617272792d706f747465722d76612d70686f6e672d636875612d62692d6d6174223b733a31323a22656c656d656e745f64617461223b613a323a7b693a303b733a333a22302e30223b693a313b733a31363a225469c3aacc816e67205669c3aacca374223b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a323a7b733a343a2254797065223b613a313a7b733a31313a2254c3a163207068e1baa96d223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31313a2254c3a163207068e1baa96d223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d733a383a2243617465676f7279223b613a333a7b733a31353a225669e1bb856e2074c6b0e1bb9f6e67223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31353a225669e1bb856e2074c6b0e1bb9f6e67223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a32343a2248e1bb8d63207472c3b2202d20546869e1babf75206e6869223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a32343a2248e1bb8d63207472c3b2202d20546869e1babf75206e6869223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a33323a225669e1bb856e2074c6b0e1bb9f6e67202d205468e1baa76e2074686fe1baa169223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a33323a225669e1bb856e2074c6b0e1bb9f6e67202d205468e1baa76e2074686fe1baa169223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a34303a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d3131223b733a353a22726f757465223b733a35363a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d3131264974656d69643d323236223b733a353a227469746c65223b733a34343a22486172727920506f747465722076c3a02050686fcc806e67206368c6b0cc8161206269cc81206dc3a2cca374223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d30392d33302030393a31323a3137223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b733a31353a2264656661756c744c616e6775616765223b733a353a2276692d564e223b7d),
(47, 'index.php?option=com_zoo&view=item&id=10', 'index.php?option=com_zoo&task=item&item_id=10&Itemid=226', 'Harry Potter và Bảo bối Tử thần', '', '2014-10-08 14:16:55', '92dd1f11bb6d855dc0ce41f66d833823', 1, 1, 1, '*', '2014-09-30 09:12:17', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31393a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a323a223130223b733a353a22616c696173223b733a33313a2268617272792d706f747465722d76612d62616f2d626f692d74752d7468616e223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d30392d33302031303a30363a3531223b733a31313a226d6f6469666965645f6279223b733a333a22353835223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a38343a22696e6465782e7068702f736163682d7669656e2d74756f6e672d7468616e2d74686f61692f7669656e2d74756f6e672f6974656d2f68617272792d706f747465722d76612d62616f2d626f692d74752d7468616e223b733a31323a22656c656d656e745f64617461223b613a323a7b693a303b733a333a22302e30223b693a313b733a31363a225469c3aacc816e67205669c3aacca374223b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a323a7b733a343a2254797065223b613a313a7b733a31313a2254c3a163207068e1baa96d223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31313a2254c3a163207068e1baa96d223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d733a383a2243617465676f7279223b613a333a7b733a31353a225669e1bb856e2074c6b0e1bb9f6e67223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31353a225669e1bb856e2074c6b0e1bb9f6e67223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a32343a2248e1bb8d63207472c3b2202d20546869e1babf75206e6869223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a32343a2248e1bb8d63207472c3b2202d20546869e1babf75206e6869223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a33323a225669e1bb856e2074c6b0e1bb9f6e67202d205468e1baa76e2074686fe1baa169223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a33323a225669e1bb856e2074c6b0e1bb9f6e67202d205468e1baa76e2074686fe1baa169223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a34303a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d3130223b733a353a22726f757465223b733a35363a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d3130264974656d69643d323236223b733a353a227469746c65223b733a34333a22486172727920506f747465722076c3a0204261cc896f2062c3b4cc81692054c6b0cc89207468c3a2cc806e223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d30392d33302030393a31323a3137223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b733a31353a2264656661756c744c616e6775616765223b733a353a2276692d564e223b7d),
(51, 'index.php?option=com_zoo&view=item&id=7', 'index.php?option=com_zoo&task=item&item_id=7&Itemid=226', 'Harry Potter và Chiếc cốc lửa', '', '2014-10-09 08:43:15', 'a403f15426fc5a452e1b6423e4d7a07e', 1, 1, 1, '*', '2014-09-30 09:12:17', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31393a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a313a2237223b733a353a22616c696173223b733a32393a2268617272792d706f747465722d76612d63686965632d636f632d6c7561223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d31302d30392030313a34333a3135223b733a31313a226d6f6469666965645f6279223b733a333a22353835223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a38323a22696e6465782e7068702f736163682d7669656e2d74756f6e672d7468616e2d74686f61692f7669656e2d74756f6e672f6974656d2f68617272792d706f747465722d76612d63686965632d636f632d6c7561223b733a31323a22656c656d656e745f64617461223b613a323a7b693a303b733a333a22302e30223b693a313b733a31363a225469c3aacc816e67205669c3aacca374223b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a333a7b733a343a2254797065223b613a313a7b733a31313a2254c3a163207068e1baa96d223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31313a2254c3a163207068e1baa96d223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d733a383a2243617465676f7279223b613a333a7b733a31353a225669e1bb856e2074c6b0e1bb9f6e67223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31353a225669e1bb856e2074c6b0e1bb9f6e67223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a32343a2248e1bb8d63207472c3b2202d20546869e1babf75206e6869223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a32343a2248e1bb8d63207472c3b2202d20546869e1babf75206e6869223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a33323a225669e1bb856e2074c6b0e1bb9f6e67202d205468e1baa76e2074686fe1baa169223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a33323a225669e1bb856e2074c6b0e1bb9f6e67202d205468e1baa76e2074686fe1baa169223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d733a333a22546167223b613a323a7b733a31323a22486172727920506f74746572223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31323a22486172727920506f74746572223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a31303a224a4b20526f776c696e67223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31303a224a4b20526f776c696e67223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a33393a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d37223b733a353a22726f757465223b733a35353a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d37264974656d69643d323236223b733a353a227469746c65223b733a33393a22486172727920506f747465722076c3a020436869c3aacc81632063c3b4cc8163206cc6b0cc8961223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d30392d33302030393a31323a3137223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b733a31353a2264656661756c744c616e6775616765223b733a353a2276692d564e223b7d),
(52, 'index.php?option=com_zoo&view=item&id=9', 'index.php?option=com_zoo&task=item&item_id=9&Itemid=226', 'Harry Potter và Hoàng tử lai', '', '2014-10-09 08:43:20', 'e9ee6f4d277a820ad4f6943a83b5c7f5', 1, 1, 1, '*', '2014-09-30 09:12:17', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31393a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a313a2239223b733a353a22616c696173223b733a32383a2268617272792d706f747465722d76612d686f616e672d74752d6c6169223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d31302d30392030313a34333a3139223b733a31313a226d6f6469666965645f6279223b733a333a22353835223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a38313a22696e6465782e7068702f736163682d7669656e2d74756f6e672d7468616e2d74686f61692f7669656e2d74756f6e672f6974656d2f68617272792d706f747465722d76612d686f616e672d74752d6c6169223b733a31323a22656c656d656e745f64617461223b613a323a7b693a303b733a333a22302e30223b693a313b733a31363a225469c3aacc816e67205669c3aacca374223b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a323a7b733a343a2254797065223b613a313a7b733a31313a2254c3a163207068e1baa96d223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31313a2254c3a163207068e1baa96d223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d733a383a2243617465676f7279223b613a333a7b733a31353a225669e1bb856e2074c6b0e1bb9f6e67223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31353a225669e1bb856e2074c6b0e1bb9f6e67223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a32343a2248e1bb8d63207472c3b2202d20546869e1babf75206e6869223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a32343a2248e1bb8d63207472c3b2202d20546869e1babf75206e6869223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a33323a225669e1bb856e2074c6b0e1bb9f6e67202d205468e1baa76e2074686fe1baa169223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a33323a225669e1bb856e2074c6b0e1bb9f6e67202d205468e1baa76e2074686fe1baa169223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a33393a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d39223b733a353a22726f757465223b733a35353a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d39264974656d69643d323236223b733a353a227469746c65223b733a33343a22486172727920506f747465722076c3a020486f61cc806e672074c6b0cc89206c6169223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d30392d33302030393a31323a3137223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b733a31353a2264656661756c744c616e6775616765223b733a353a2276692d564e223b7d);
INSERT INTO `zjw8d_finder_links` (`link_id`, `url`, `route`, `title`, `description`, `indexdate`, `md5sum`, `published`, `state`, `access`, `language`, `publish_start_date`, `publish_end_date`, `start_date`, `end_date`, `list_price`, `sale_price`, `type_id`, `object`) VALUES
(56, 'index.php?option=com_zoo&view=item&id=13', 'index.php?option=com_zoo&task=item&item_id=13&Itemid=112', 'J.K. Rowling', '', '2014-10-15 04:55:34', '051c5b0eb3b2909394c0b0476bac3246', 1, 1, 1, '*', '2014-10-09 11:43:20', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31393a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a323a223133223b733a353a22616c696173223b733a31313a226a2d6b2d726f776c696e67223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d31302d31342032313a35353a3332223b733a31313a226d6f6469666965645f6279223b733a333a22353835223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a35373a22696e6465782e7068702f686f632d74726f2d74686965752d6e68692f74756f692d686f632d74726f2f6974656d2f6a2d6b2d726f776c696e67223b733a31323a22656c656d656e745f64617461223b613a313a7b693a303b733a31393a22313936352d30372d33302031373a30303a3030223b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a323a7b733a343a2254797065223b613a313a7b733a31303a2254c3a163206769e1baa3223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31303a2254c3a163206769e1baa3223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d733a383a2243617465676f7279223b613a353a7b733a31353a225669e1bb856e2074c6b0e1bb9f6e67223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31353a225669e1bb856e2074c6b0e1bb9f6e67223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a31313a22546869e1babf75206e6869223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31313a22546869e1babf75206e6869223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a31373a225475e1bb95692068e1bb8d63207472c3b2223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31373a225475e1bb95692068e1bb8d63207472c3b2223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a32343a2248e1bb8d63207472c3b2202d20546869e1babf75206e6869223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a32343a2248e1bb8d63207472c3b2202d20546869e1babf75206e6869223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a33323a225669e1bb856e2074c6b0e1bb9f6e67202d205468e1baa76e2074686fe1baa169223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a33323a225669e1bb856e2074c6b0e1bb9f6e67202d205468e1baa76e2074686fe1baa169223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a34303a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d3133223b733a353a22726f757465223b733a35363a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d3133264974656d69643d313132223b733a353a227469746c65223b733a31323a224a2e4b2e20526f776c696e67223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d31302d30392031313a34333a3230223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b733a31353a2264656661756c744c616e6775616765223b733a353a2276692d564e223b7d),
(58, 'index.php?option=com_zoo&view=item&id=8', 'index.php?option=com_zoo&task=item&item_id=8&Itemid=226', 'Harry Potter và Hội Phượng hoàng', '', '2014-10-15 05:25:56', 'dd6a801aaa9169cf4578baf274cd2646', 1, 1, 1, '*', '2014-09-30 09:12:17', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0, 1, 0x4f3a31393a2246696e646572496e6465786572526573756c74223a31393a7b733a31313a22002a00656c656d656e7473223b613a31323a7b733a323a226964223b733a313a2238223b733a353a22616c696173223b733a33323a2268617272792d706f747465722d76612d686f692d7068756f6e672d686f616e67223b733a31363a22637265617465645f62795f616c696173223b733a303a22223b733a383a226d6f646966696564223b733a31393a22323031342d31302d30392031353a31393a3034223b733a31313a226d6f6469666965645f6279223b733a333a22353835223b733a31303a2273656172636861626c65223b733a313a2231223b733a363a226c61796f7574223b733a343a226974656d223b733a383a226d65746164617461223b4f3a393a224a5265676973747279223a313a7b733a373a22002a0064617461223b4f3a383a22737464436c617373223a353a7b733a353a227469746c65223b733a303a22223b733a31313a226465736372697074696f6e223b733a303a22223b733a383a226b6579776f726473223b733a303a22223b733a363a22726f626f7473223b733a303a22223b733a363a22617574686f72223b733a303a22223b7d7d733a31303a226d657461617574686f72223b733a303a22223b733a373a2273756d6d617279223b733a303a22223b733a343a2270617468223b733a38353a22696e6465782e7068702f736163682d7669656e2d74756f6e672d7468616e2d74686f61692f7669656e2d74756f6e672f6974656d2f68617272792d706f747465722d76612d686f692d7068756f6e672d686f616e67223b733a31323a22656c656d656e745f64617461223b613a323a7b693a303b733a333a22352e30223b693a313b733a31363a225469c3aacc816e67205669c3aacca374223b7d7d733a31353a22002a00696e737472756374696f6e73223b613a353a7b693a313b613a333a7b693a303b733a353a227469746c65223b693a313b733a383a227375627469746c65223b693a323b733a323a226964223b7d693a323b613a323a7b693a303b733a373a2273756d6d617279223b693a313b733a343a22626f6479223b7d693a333b613a31303a7b693a303b733a343a226d657461223b693a313b733a31303a226c6973745f7072696365223b693a323b733a31303a2273616c655f7072696365223b693a333b733a343a226c696e6b223b693a343b733a373a226d6574616b6579223b693a353b733a383a226d65746164657363223b693a363b733a31303a226d657461617574686f72223b693a373b733a363a22617574686f72223b693a383b733a31363a22637265617465645f62795f616c696173223b693a393b733a31323a22656c656d656e745f64617461223b7d693a343b613a323a7b693a303b733a343a2270617468223b693a313b733a353a22616c696173223b7d693a353b613a313a7b693a303b733a383a22636f6d6d656e7473223b7d7d733a31313a22002a007461786f6e6f6d79223b613a323a7b733a343a2254797065223b613a313a7b733a31313a2254c3a163207068e1baa96d223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31313a2254c3a163207068e1baa96d223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d733a383a2243617465676f7279223b613a333a7b733a31353a225669e1bb856e2074c6b0e1bb9f6e67223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a31353a225669e1bb856e2074c6b0e1bb9f6e67223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a32343a2248e1bb8d63207472c3b2202d20546869e1babf75206e6869223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a32343a2248e1bb8d63207472c3b2202d20546869e1babf75206e6869223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d733a33323a225669e1bb856e2074c6b0e1bb9f6e67202d205468e1baa76e2074686fe1baa169223b4f3a373a224a4f626a656374223a343a7b733a31303a22002a005f6572726f7273223b613a303a7b7d733a353a227469746c65223b733a33323a225669e1bb856e2074c6b0e1bb9f6e67202d205468e1baa76e2074686fe1baa169223b733a353a227374617465223b693a313b733a363a22616363657373223b693a313b7d7d7d733a333a2275726c223b733a33393a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f26766965773d6974656d2669643d38223b733a353a22726f757465223b733a35353a22696e6465782e7068703f6f7074696f6e3d636f6d5f7a6f6f267461736b3d6974656d266974656d5f69643d38264974656d69643d323236223b733a353a227469746c65223b733a34323a22486172727920506f747465722076c3a02048c3b4cca369205068c6b0c6a1cca36e6720686f61cc806e67223b733a31313a226465736372697074696f6e223b733a303a22223b733a393a227075626c6973686564223b4e3b733a353a227374617465223b623a313b733a363a22616363657373223b733a313a2231223b733a383a226c616e6775616765223b733a313a222a223b733a31383a227075626c6973685f73746172745f64617465223b733a31393a22323031342d30392d33302030393a31323a3137223b733a31363a227075626c6973685f656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a2273746172745f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a383a22656e645f64617465223b733a31393a22303030302d30302d30302030303a30303a3030223b733a31303a226c6973745f7072696365223b4e3b733a31303a2273616c655f7072696365223b4e3b733a373a22747970655f6964223b693a313b733a31353a2264656661756c744c616e6775616765223b733a353a2276692d564e223b7d);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_links_terms0`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_links_terms0` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_finder_links_terms0`
--

INSERT INTO `zjw8d_finder_links_terms0` (`link_id`, `term_id`, `weight`) VALUES
(9, 901, 0.98679),
(45, 4544, 0.24),
(45, 4545, 1.72679);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_links_terms1`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_links_terms1` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_finder_links_terms1`
--

INSERT INTO `zjw8d_finder_links_terms1` (`link_id`, `term_id`, `weight`) VALUES
(41, 4447, 0.17);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_links_terms2`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_links_terms2` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_finder_links_terms2`
--

INSERT INTO `zjw8d_finder_links_terms2` (`link_id`, `term_id`, `weight`) VALUES
(9, 3142, 1.23321),
(8, 3861, 0.49321),
(9, 3873, 4.81),
(9, 3874, 5.30321),
(13, 3922, 0.2666),
(13, 3923, 0.5334),
(13, 3924, 2.4666),
(41, 3998, 1.23321),
(45, 3998, 1.23321),
(46, 3998, 1.23321),
(47, 3998, 1.23321),
(52, 3998, 1.23321),
(58, 3998, 1.23321),
(51, 3998, 1.63317),
(41, 3999, 5.18),
(45, 3999, 5.18),
(46, 3999, 5.18),
(47, 3999, 5.18),
(52, 3999, 5.18),
(58, 3999, 5.18),
(51, 3999, 6.86),
(41, 4000, 5.55),
(45, 4000, 5.55),
(46, 4000, 5.55),
(47, 4000, 5.55),
(51, 4000, 5.55),
(52, 4000, 5.55),
(58, 4000, 5.55),
(41, 4065, 0.24),
(45, 4065, 0.24),
(46, 4065, 0.24),
(47, 4065, 0.24),
(51, 4065, 0.24),
(52, 4065, 0.24),
(58, 4065, 0.24),
(56, 4065, 0.48),
(41, 4066, 1.47996),
(45, 4066, 1.47996),
(46, 4066, 1.47996),
(47, 4066, 1.47996),
(51, 4066, 1.47996),
(52, 4066, 1.47996),
(58, 4066, 1.47996),
(56, 4066, 2.95992),
(41, 4067, 1.71996),
(46, 4067, 1.71996),
(47, 4067, 1.71996),
(51, 4067, 1.71996),
(52, 4067, 1.71996),
(56, 4067, 1.71996),
(58, 4067, 1.71996),
(52, 4262, 0.6666),
(58, 4262, 0.6666),
(52, 4265, 0.68),
(58, 4265, 0.68),
(41, 4451, 0.74),
(41, 4452, 2.4),
(41, 4453, 2.6666),
(41, 4454, 2.04),
(41, 4455, 2.26661),
(51, 4742, 0.4),
(51, 4743, 0.45339),
(52, 4761, 2.5334),
(52, 4762, 2.8),
(52, 4763, 2.26661),
(52, 4764, 2.49339),
(52, 4765, 0.74),
(58, 4918, 0.4),
(58, 4919, 2.6666),
(58, 4920, 3.0666),
(58, 4921, 0.45339),
(58, 4922, 2.38),
(58, 4923, 2.77661);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_links_terms3`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_links_terms3` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_finder_links_terms3`
--

INSERT INTO `zjw8d_finder_links_terms3` (`link_id`, `term_id`, `weight`) VALUES
(51, 4740, 0.15996),
(51, 4741, 1.59996),
(56, 4864, 0.24679),
(56, 4865, 4.07),
(56, 4866, 5.05679);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_links_terms4`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_links_terms4` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_finder_links_terms4`
--

INSERT INTO `zjw8d_finder_links_terms4` (`link_id`, `term_id`, `weight`) VALUES
(13, 3921, 0.56004),
(46, 4579, 0.5334),
(46, 4580, 2.4666),
(46, 4581, 2.7334),
(46, 4582, 0.56661),
(46, 4583, 2.21),
(46, 4584, 2.49339),
(51, 4730, 0.6666),
(51, 4731, 2.6),
(51, 4732, 2.8666),
(51, 4733, 0.68),
(51, 4734, 2.32339),
(51, 4735, 2.60661),
(51, 4736, 0.4),
(51, 4737, 2.4666),
(51, 4738, 0.45339),
(51, 4739, 2.21),
(51, 4746, 0.56004),
(56, 4746, 1.72679),
(52, 4760, 0.17);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_links_terms5`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_links_terms5` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_links_terms6`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_links_terms6` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_finder_links_terms6`
--

INSERT INTO `zjw8d_finder_links_terms6` (`link_id`, `term_id`, `weight`) VALUES
(46, 4585, 0.4),
(46, 4586, 0.45339);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_links_terms7`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_links_terms7` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_finder_links_terms7`
--

INSERT INTO `zjw8d_finder_links_terms7` (`link_id`, `term_id`, `weight`) VALUES
(8, 3862, 0.4),
(8, 3863, 2.4),
(41, 4068, 0.24),
(46, 4068, 0.24),
(47, 4068, 0.24),
(51, 4068, 0.24),
(52, 4068, 0.24),
(58, 4068, 0.24),
(56, 4068, 0.48),
(45, 4546, 0.98679),
(45, 4547, 5.18),
(45, 4548, 0.98679),
(45, 4549, 4.81),
(45, 4550, 5.79679);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_links_terms8`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_links_terms8` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_finder_links_terms8`
--

INSERT INTO `zjw8d_finder_links_terms8` (`link_id`, `term_id`, `weight`) VALUES
(7, 499, 0.6666),
(8, 499, 0.6666),
(9, 499, 0.6666),
(12, 499, 0.6666),
(13, 499, 0.6666),
(41, 499, 0.6666),
(45, 499, 0.6666),
(46, 499, 0.6666),
(47, 499, 0.6666),
(51, 499, 0.6666),
(52, 499, 0.6666),
(56, 499, 0.6666),
(58, 499, 0.6666),
(7, 823, 0.32004),
(8, 823, 0.32004),
(9, 823, 0.32004),
(9, 3868, 0.74),
(9, 3869, 4.56321),
(9, 3870, 5.18),
(41, 4015, 0.32004),
(45, 4015, 0.32004),
(46, 4015, 0.32004),
(47, 4015, 0.32004),
(51, 4015, 0.32004),
(52, 4015, 0.32004),
(58, 4015, 0.32004),
(41, 4019, 1.48),
(45, 4019, 1.48),
(46, 4019, 1.48),
(47, 4019, 1.48),
(52, 4019, 1.48),
(58, 4019, 1.48),
(51, 4019, 1.96),
(41, 4020, 4.81),
(45, 4020, 4.81),
(46, 4020, 4.81),
(47, 4020, 4.81),
(51, 4020, 4.81),
(52, 4020, 4.81),
(58, 4020, 4.81),
(41, 4448, 0.2666),
(41, 4449, 2.4),
(41, 4450, 2.7334),
(41, 4456, 0.74),
(41, 4457, 4.68679),
(41, 4458, 5.30321),
(45, 4551, 5.30321),
(46, 4587, 0.6666),
(46, 4588, 2.6666),
(46, 4589, 2.8666),
(46, 4590, 0.68),
(46, 4591, 2.38),
(46, 4592, 2.60661),
(46, 4593, 3),
(46, 4594, 2.60661),
(47, 4618, 2.8666),
(47, 4619, 2.49339),
(51, 4729, 0.17),
(51, 4744, 3),
(51, 4745, 2.60661),
(52, 4766, 3),
(52, 4767, 2.60661),
(56, 4867, 0.24679),
(56, 4868, 4.81),
(58, 4924, 0.8),
(58, 4925, 2.8),
(58, 4926, 0.79339),
(58, 4927, 2.49339),
(58, 4928, 2.8666),
(58, 4929, 2.49339);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_links_terms9`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_links_terms9` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_finder_links_terms9`
--

INSERT INTO `zjw8d_finder_links_terms9` (`link_id`, `term_id`, `weight`) VALUES
(12, 3911, 0.2666),
(12, 3912, 2.2666),
(12, 3913, 0.45339),
(13, 3913, 0.45339),
(41, 4040, 0.49321),
(45, 4040, 0.49321),
(46, 4040, 0.49321),
(47, 4040, 0.49321),
(51, 4040, 0.49321),
(52, 4040, 0.49321),
(58, 4040, 0.49321),
(41, 4047, 0.39996),
(45, 4047, 0.39996),
(46, 4047, 0.39996),
(47, 4047, 0.39996),
(51, 4047, 0.39996),
(52, 4047, 0.39996),
(58, 4047, 0.39996),
(41, 4079, 0.64008),
(45, 4079, 0.64008),
(46, 4079, 0.64008),
(47, 4079, 0.64008),
(51, 4079, 0.64008),
(52, 4079, 0.64008),
(56, 4079, 0.64008),
(58, 4079, 0.64008),
(41, 4080, 3.19992),
(45, 4080, 3.19992),
(46, 4080, 3.19992),
(47, 4080, 3.19992),
(51, 4080, 3.19992),
(52, 4080, 3.19992),
(56, 4080, 3.19992),
(58, 4080, 3.19992),
(41, 4081, 1.8),
(45, 4081, 1.8),
(46, 4081, 1.8),
(47, 4081, 1.8),
(51, 4081, 1.8),
(52, 4081, 1.8),
(56, 4081, 1.8),
(58, 4081, 1.8),
(41, 4460, 4.44),
(41, 4461, 2.6),
(41, 4462, 2.21),
(45, 4562, 4.44),
(45, 4563, 4.81),
(45, 4564, 1.68),
(45, 4565, 1.83996),
(46, 4575, 0.2666),
(46, 4576, 2.4),
(46, 4577, 0.34),
(46, 4578, 2.15339),
(46, 4595, 2.5334),
(46, 4596, 2.8666),
(46, 4597, 2.21),
(46, 4598, 2.55),
(47, 4606, 0.4),
(47, 4607, 2.4666),
(47, 4608, 2.6666),
(47, 4609, 0.45339),
(47, 4610, 2.21),
(47, 4611, 2.43661),
(47, 4612, 0.4),
(47, 4613, 2.4),
(47, 4614, 2.7334),
(47, 4615, 0.45339),
(47, 4616, 2.15339),
(47, 4617, 2.49339),
(47, 4623, 2.4),
(47, 4624, 2.6666),
(47, 4625, 2.09661),
(47, 4626, 2.38),
(51, 4747, 2.5334),
(51, 4748, 2.8),
(51, 4749, 2.21),
(51, 4750, 2.49339),
(52, 4770, 2.5334),
(52, 4771, 2.7334),
(52, 4772, 2.21),
(52, 4773, 2.43661),
(58, 4930, 2.4),
(58, 4931, 2.8666),
(58, 4932, 2.09661),
(58, 4933, 2.55);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_links_termsa`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_links_termsa` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_finder_links_termsa`
--

INSERT INTO `zjw8d_finder_links_termsa` (`link_id`, `term_id`, `weight`) VALUES
(8, 3862, 0.34),
(8, 3863, 2.04),
(12, 3904, 0.17);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_links_termsb`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_links_termsb` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_finder_links_termsb`
--

INSERT INTO `zjw8d_finder_links_termsb` (`link_id`, `term_id`, `weight`) VALUES
(7, 402, 0.98679),
(7, 403, 4.93321),
(9, 3871, 0.74),
(9, 3872, 4.68679),
(41, 4463, 0.22661),
(41, 4464, 2.04),
(41, 4465, 2.32339),
(56, 4863, 0.24);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_links_termsc`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_links_termsc` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_finder_links_termsc`
--

INSERT INTO `zjw8d_finder_links_termsc` (`link_id`, `term_id`, `weight`) VALUES
(7, 3859, 0.17),
(8, 3860, 0.17),
(13, 3919, 0.36),
(41, 3919, 0.36),
(45, 3919, 0.36),
(46, 3919, 0.36),
(47, 3919, 0.36),
(51, 3919, 0.36),
(52, 3919, 0.36),
(45, 4543, 0.34),
(46, 4574, 0.34),
(47, 4605, 0.34),
(56, 4854, 0.48),
(56, 4855, 1.40004),
(56, 4856, 0.34),
(56, 4857, 0.24),
(56, 4858, 1.40004),
(56, 4859, 1.52004),
(56, 4860, 1.2),
(56, 4861, 1.71996),
(56, 4862, 1.83996),
(58, 4917, 0.17);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_links_termsd`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_links_termsd` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_links_termse`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_links_termse` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_finder_links_termse`
--

INSERT INTO `zjw8d_finder_links_termse` (`link_id`, `term_id`, `weight`) VALUES
(41, 1078, 0.39996),
(46, 1078, 0.39996),
(47, 1078, 0.39996),
(51, 1078, 0.39996),
(52, 1078, 0.39996),
(58, 1078, 0.39996),
(56, 1078, 0.79992),
(7, 1078, 1.23321),
(9, 3867, 0.17),
(12, 3905, 0.63996),
(13, 3906, 0.45339),
(12, 3906, 0.98679),
(12, 3907, 2.4666),
(12, 3908, 2.6),
(12, 3909, 2.21),
(13, 3909, 2.21),
(12, 3910, 0.1334),
(13, 3920, 0.17),
(13, 3925, 0.6666),
(13, 3926, 2.6),
(13, 3927, 2.9334),
(13, 3928, 0.4),
(13, 3929, 2.5334),
(13, 3930, 2.7334),
(41, 4023, 0.24),
(45, 4023, 0.24),
(46, 4023, 0.24),
(47, 4023, 0.24),
(51, 4023, 0.24),
(52, 4023, 0.24),
(56, 4023, 0.24),
(58, 4023, 0.24),
(41, 4024, 1.52004),
(45, 4024, 1.52004),
(46, 4024, 1.52004),
(47, 4024, 1.52004),
(51, 4024, 1.52004),
(52, 4024, 1.52004),
(58, 4024, 1.52004),
(41, 4032, 0.48),
(46, 4032, 0.48),
(47, 4032, 0.48),
(51, 4032, 0.48),
(52, 4032, 0.48),
(58, 4032, 0.48),
(45, 4032, 0.96),
(41, 4033, 1.68),
(45, 4033, 1.68),
(46, 4033, 1.68),
(47, 4033, 1.68),
(51, 4033, 1.68),
(52, 4033, 1.68),
(58, 4033, 1.68),
(41, 4069, 0.32004),
(45, 4069, 0.32004),
(46, 4069, 0.32004),
(51, 4069, 0.32004),
(52, 4069, 0.32004),
(56, 4069, 0.32004),
(58, 4069, 0.32004),
(47, 4069, 0.85344),
(41, 4070, 1.59996),
(45, 4070, 1.59996),
(46, 4070, 1.59996),
(47, 4070, 1.59996),
(51, 4070, 1.59996),
(52, 4070, 1.59996),
(56, 4070, 1.59996),
(58, 4070, 1.59996),
(41, 4071, 1.56),
(46, 4071, 1.56),
(47, 4071, 1.56),
(51, 4071, 1.56),
(52, 4071, 1.56),
(58, 4071, 1.56),
(56, 4071, 3.12),
(41, 4072, 0.39996),
(45, 4072, 0.39996),
(46, 4072, 0.39996),
(47, 4072, 0.39996),
(51, 4072, 0.39996),
(52, 4072, 0.39996),
(56, 4072, 0.39996),
(58, 4072, 0.39996),
(41, 4073, 0.24),
(45, 4073, 0.24),
(46, 4073, 0.24),
(47, 4073, 0.24),
(51, 4073, 0.24),
(52, 4073, 0.24),
(58, 4073, 0.24),
(56, 4073, 0.48),
(41, 4074, 1.56),
(46, 4074, 1.56),
(47, 4074, 1.56),
(51, 4074, 1.56),
(52, 4074, 1.56),
(56, 4074, 1.56),
(58, 4074, 1.56),
(41, 4075, 1.71996),
(46, 4075, 1.71996),
(47, 4075, 1.71996),
(51, 4075, 1.71996),
(52, 4075, 1.71996),
(56, 4075, 1.71996),
(58, 4075, 1.71996),
(41, 4076, 0.79992),
(45, 4076, 0.79992),
(46, 4076, 0.79992),
(47, 4076, 0.79992),
(51, 4076, 0.79992),
(52, 4076, 0.79992),
(56, 4076, 0.79992),
(58, 4076, 0.79992),
(41, 4077, 1.59996),
(45, 4077, 1.59996),
(46, 4077, 1.59996),
(47, 4077, 1.59996),
(51, 4077, 1.59996),
(52, 4077, 1.59996),
(56, 4077, 1.59996),
(58, 4077, 1.59996),
(41, 4078, 1.83996),
(45, 4078, 1.83996),
(46, 4078, 1.83996),
(47, 4078, 1.83996),
(51, 4078, 1.83996),
(52, 4078, 1.83996),
(56, 4078, 1.83996),
(58, 4078, 1.83996),
(47, 4158, 0.2666),
(52, 4158, 0.2666),
(45, 4158, 0.49321),
(47, 4247, 0.34),
(52, 4247, 0.34),
(41, 4459, 0.98679),
(45, 4552, 0.74),
(45, 4553, 4.44),
(45, 4554, 5.05679),
(45, 4555, 1.59996),
(45, 4556, 1.95996),
(45, 4557, 4.56321),
(45, 4558, 5.18),
(45, 4559, 0.32004),
(56, 4559, 0.32004),
(45, 4560, 1.52004),
(56, 4560, 1.52004),
(45, 4561, 1.68),
(56, 4561, 1.68),
(47, 4620, 0.56661),
(47, 4621, 2.4666),
(47, 4622, 2.21),
(52, 4768, 2.4),
(52, 4769, 2.09661),
(56, 4869, 1.47996),
(58, 4916, 0.36);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_links_termsf`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_links_termsf` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_taxonomy`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_taxonomy` (
`id` int(10) unsigned NOT NULL,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `access` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(1) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `zjw8d_finder_taxonomy`
--

INSERT INTO `zjw8d_finder_taxonomy` (`id`, `parent_id`, `title`, `state`, `access`, `ordering`) VALUES
(1, 0, 'ROOT', 0, 0, 0),
(2, 1, 'Type', 1, 1, 0),
(3, 2, 'Page', 1, 1, 0),
(8, 2, 'Employee', 1, 1, 0),
(9, 2, 'Company', 1, 1, 0),
(11, 2, 'Tác phẩm', 1, 1, 0),
(12, 1, 'Category', 1, 1, 0),
(16, 12, 'Viễn tưởng', 1, 1, 0),
(17, 12, 'Học trò - Thiếu nhi', 1, 1, 0),
(18, 12, 'Viễn tưởng - Thần thoại', 1, 1, 0),
(22, 12, 'Tuổi học trò', 1, 1, 0),
(23, 1, 'Tag', 1, 1, 0),
(30, 23, 'Harry Potter', 1, 1, 0),
(31, 23, 'JK Rowling', 1, 1, 0),
(35, 2, 'Tác giả', 1, 1, 0),
(36, 12, 'Thiếu nhi', 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_taxonomy_map`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_taxonomy_map` (
  `link_id` int(10) unsigned NOT NULL,
  `node_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_finder_taxonomy_map`
--

INSERT INTO `zjw8d_finder_taxonomy_map` (`link_id`, `node_id`) VALUES
(7, 3),
(8, 3),
(9, 3),
(12, 8),
(13, 9),
(41, 11),
(41, 16),
(41, 17),
(41, 18),
(45, 11),
(45, 16),
(45, 18),
(45, 22),
(46, 11),
(46, 16),
(46, 17),
(46, 18),
(47, 11),
(47, 16),
(47, 17),
(47, 18),
(51, 11),
(51, 16),
(51, 17),
(51, 18),
(51, 30),
(51, 31),
(52, 11),
(52, 16),
(52, 17),
(52, 18),
(56, 16),
(56, 17),
(56, 18),
(56, 22),
(56, 35),
(56, 36),
(58, 11),
(58, 16),
(58, 17),
(58, 18);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_terms`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_terms` (
`term_id` int(10) unsigned NOT NULL,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '0',
  `soundex` varchar(75) NOT NULL,
  `links` int(10) NOT NULL DEFAULT '0',
  `language` char(3) NOT NULL DEFAULT ''
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4934 ;

--
-- Dumping data for table `zjw8d_finder_terms`
--

INSERT INTO `zjw8d_finder_terms` (`term_id`, `term`, `stem`, `common`, `phrase`, `weight`, `soundex`, `links`, `language`) VALUES
(402, 'gioi', 'gioi', 0, 0, 0.2667, 'G000', 1, '*'),
(403, 'gioi thieu', 'gioi thieu', 0, 1, 1.3333, 'G300', 1, '*'),
(499, 'index', 'index', 0, 0, 0.3333, 'I532', 13, '*'),
(823, 'page', 'page', 0, 0, 0.2667, 'P200', 3, '*'),
(901, 'sách', 'sách', 0, 0, 0.2667, 'S000', 1, '*'),
(1078, 'thieu', 'thieu', 0, 0, 0.3333, 'T000', 8, '*'),
(3142, 'huong', 'huong', 0, 0, 0.3333, 'H520', 1, '*'),
(3859, '1', '1', 0, 0, 0.1, '', 1, '*'),
(3860, '2', '2', 0, 0, 0.1, '', 1, '*'),
(3861, 'ho', 'ho', 0, 0, 0.1333, 'H000', 1, '*'),
(3862, 'ung', 'ung', 0, 0, 0.2, 'U520', 1, '*'),
(3863, 'ung ho', 'ung ho', 0, 1, 1.2, 'U520', 1, '*'),
(3867, '3', '3', 0, 0, 0.1, '', 1, '*'),
(3868, 'dan', 'dan', 0, 0, 0.2, 'D500', 1, '*'),
(3869, 'dan gui', 'dan gui', 0, 1, 1.2333, 'D520', 1, '*'),
(3870, 'dan gui sach', 'dan gui sach', 0, 1, 1.4, 'D520', 1, '*'),
(3871, 'gui', 'gui', 0, 0, 0.2, 'G000', 1, '*'),
(3872, 'gui sach', 'gui sach', 0, 1, 1.2667, 'G000', 1, '*'),
(3873, 'huong dan', 'huong dan', 0, 1, 1.3, 'H5235', 1, '*'),
(3874, 'huong dan gui', 'huong dan gui', 0, 1, 1.4333, 'H52352', 1, '*'),
(3904, '4', '4', 0, 0, 0.1, '', 1, '*'),
(3905, 'employee', 'employe', 0, 0, 0.5333, 'E514', 1, '*'),
(3906, 'epub', 'epub', 0, 0, 0.2667, 'E100', 2, '*'),
(3907, 'epub vi', 'epub vi', 0, 1, 1.2333, 'E100', 1, '*'),
(3908, 'epub vi t', 'epub vi t', 0, 1, 1.3, 'E130', 1, '*'),
(3909, 'epub việt', 'epub việt', 0, 1, 1.3, 'E130', 2, '*'),
(3910, 't', 't', 0, 0, 0.0667, 'T000', 1, '*'),
(3911, 'vi', 'vi', 0, 0, 0.1333, 'V000', 1, '*'),
(3912, 'vi t', 'vi t', 0, 1, 1.1333, 'V300', 1, '*'),
(3913, 'việt', 'việt', 0, 0, 0.2667, 'V300', 2, '*'),
(3919, '0.0', '0.0', 0, 0, 0.3, '', 7, '*'),
(3920, '5', '5', 0, 0, 0.1, '', 1, '*'),
(3921, 'company', 'compani', 0, 0, 0.4667, 'C515', 1, '*'),
(3922, 'he', 'he', 0, 0, 0.1333, 'H000', 1, '*'),
(3923, 'lien', 'lien', 0, 0, 0.2667, 'L500', 1, '*'),
(3924, 'lien he', 'lien he', 0, 1, 1.2333, 'L500', 1, '*'),
(3925, 'thong', 'thong', 0, 0, 0.3333, 'T520', 1, '*'),
(3926, 'thong tin', 'thong tin', 0, 1, 1.3, 'T5235', 1, '*'),
(3927, 'thong tin lien', 'thong tin lien', 0, 1, 1.4667, 'T523545', 1, '*'),
(3928, 'tin', 'tin', 0, 0, 0.2, 'T500', 1, '*'),
(3929, 'tin lien', 'tin lien', 0, 1, 1.2667, 'T545', 1, '*'),
(3930, 'tin lien he', 'tin lien he', 0, 1, 1.3667, 'T545', 1, '*'),
(3998, 'harry', 'harri', 0, 0, 0.3333, 'H600', 7, '*'),
(3999, 'harry potter', 'harri potter', 0, 1, 1.4, 'H6136', 7, '*'),
(4000, 'harry potter va', 'harri potter va', 0, 1, 1.5, 'H61361', 7, '*'),
(4015, 'phẩm', 'phẩm', 0, 0, 0.2667, 'P500', 7, '*'),
(4019, 'potter', 'potter', 0, 0, 0.4, 'P360', 7, '*'),
(4020, 'potter va', 'potter va', 0, 1, 1.3, 'P361', 7, '*'),
(4023, 'tác', 'tác', 0, 0, 0.2, 'T200', 8, '*'),
(4024, 'tác phẩm', 'tác phẩm', 0, 1, 1.2667, 'T215', 7, '*'),
(4032, 'tiếng', 'tiếng', 0, 0, 0.4, 'T520', 7, '*'),
(4033, 'tiếng việt', 'tiếng việt', 0, 1, 1.4, 'T5213', 7, '*'),
(4040, 'va', 'va', 0, 0, 0.1333, 'V000', 7, '*'),
(4047, 'việt', 'việt', 0, 0, 0.3333, 'V300', 7, '*'),
(4065, 'học', 'học', 0, 0, 0.2, 'H200', 8, '*'),
(4066, 'học trò', 'học trò', 0, 1, 1.2333, 'H236', 8, '*'),
(4067, 'học trò thiếu', 'học trò thiếu', 0, 1, 1.4333, 'H2363', 7, '*'),
(4068, 'nhi', 'nhi', 0, 0, 0.2, 'N000', 7, '*'),
(4069, 'thần', 'thần', 0, 0, 0.2667, 'T500', 8, '*'),
(4070, 'thần thoại', 'thần thoại', 0, 1, 1.3333, 'T530', 8, '*'),
(4071, 'thiếu nhi', 'thiếu nhi', 0, 1, 1.3, 'T500', 7, '*'),
(4072, 'thoại', 'thoại', 0, 0, 0.3333, 'T000', 8, '*'),
(4073, 'trò', 'trò', 0, 0, 0.2, 'T600', 8, '*'),
(4074, 'trò thiếu', 'trò thiếu', 0, 1, 1.3, 'T630', 7, '*'),
(4075, 'trò thiếu nhi', 'trò thiếu nhi', 0, 1, 1.4333, 'T635', 7, '*'),
(4076, 'tưởng', 'tưởng', 0, 0, 0.3333, 'T520', 8, '*'),
(4077, 'tưởng thần', 'tưởng thần', 0, 1, 1.3333, 'T5235', 8, '*'),
(4078, 'tưởng thần thoại', 'tưởng thần thoại', 0, 1, 1.5333, 'T52353', 8, '*'),
(4079, 'viễn', 'viễn', 0, 0, 0.2667, 'V500', 8, '*'),
(4080, 'viễn tưởng', 'viễn tưởng', 0, 1, 1.3333, 'V5352', 8, '*'),
(4081, 'viễn tưởng thần', 'viễn tưởng thần', 0, 1, 1.5, 'V535235', 8, '*'),
(4158, 'tu', 'tu', 0, 0, 0.1333, 'T000', 3, '*'),
(4247, 'tử', 'tử', 0, 0, 0.2, 'T000', 2, '*'),
(4262, 'hoang', 'hoang', 0, 0, 0.3333, 'H520', 2, '*'),
(4265, 'hoàng', 'hoàng', 0, 0, 0.4, 'H520', 2, '*'),
(4447, '6', '6', 0, 0, 0.1, '', 1, '*'),
(4448, 'da', 'da', 0, 0, 0.1333, 'D000', 1, '*'),
(4449, 'da phu', 'da phu', 0, 1, 1.2, 'D100', 1, '*'),
(4450, 'da phu thuy', 'da phu thuy', 0, 1, 1.3667, 'D130', 1, '*'),
(4451, 'hon', 'hon', 0, 0, 0.2, 'H500', 1, '*'),
(4452, 'hon da', 'hon da', 0, 1, 1.2, 'H530', 1, '*'),
(4453, 'hon da phu', 'hon da phu', 0, 1, 1.3333, 'H531', 1, '*'),
(4454, 'hòn đá', 'hòn đá', 0, 1, 1.2, 'H500', 1, '*'),
(4455, 'hòn đá phù', 'hòn đá phù', 0, 1, 1.3333, 'H510', 1, '*'),
(4456, 'phu', 'phu', 0, 0, 0.2, 'P000', 1, '*'),
(4457, 'phu thuy', 'phu thuy', 0, 1, 1.2667, 'P300', 1, '*'),
(4458, 'potter va hon', 'potter va hon', 0, 1, 1.4333, 'P3615', 1, '*'),
(4459, 'thuy', 'thui', 0, 0, 0.2667, 'T000', 1, '*'),
(4460, 'va hon', 'va hon', 0, 1, 1.2, 'V500', 1, '*'),
(4461, 'va hon da', 'va hon da', 0, 1, 1.3, 'V530', 1, '*'),
(4462, 'và hòn đá', 'và hòn đá', 0, 1, 1.3, 'V500', 1, '*'),
(4463, 'đá', 'đá', 0, 0, 0.1333, 'đ000', 1, '*'),
(4464, 'đá phù', 'đá phù', 0, 1, 1.2, 'đ100', 1, '*'),
(4465, 'đá phù thủy', 'đá phù thủy', 0, 1, 1.3667, 'đ130', 1, '*'),
(4543, '12', '12', 0, 0, 0.2, '', 1, '*'),
(4544, 'anh', 'anh', 0, 0, 0.2, 'A500', 1, '*'),
(4545, 'azkaban', 'azkaban', 0, 0, 0.4667, 'A215', 1, '*'),
(4546, 'nguc', 'nguc', 0, 0, 0.2667, 'N200', 1, '*'),
(4547, 'nguc azkaban', 'nguc azkaban', 0, 1, 1.4, 'N215', 1, '*'),
(4548, 'nhan', 'nhan', 0, 0, 0.2667, 'N000', 1, '*'),
(4549, 'nhan nguc', 'nhan nguc', 0, 1, 1.3, 'N200', 1, '*'),
(4550, 'nhan nguc azkaban', 'nhan nguc azkaban', 0, 1, 1.5667, 'N215', 1, '*'),
(4551, 'potter va ten', 'potter va ten', 0, 1, 1.4333, 'P36135', 1, '*'),
(4552, 'ten', 'ten', 0, 0, 0.2, 'T500', 1, '*'),
(4553, 'ten tu', 'ten tu', 0, 1, 1.2, 'T530', 1, '*'),
(4554, 'ten tu nhan', 'ten tu nhan', 0, 1, 1.3667, 'T535', 1, '*'),
(4555, 'tiếng anh', 'tiếng anh', 0, 1, 1.3333, 'T525', 1, '*'),
(4556, 'tiếng việt tiếng', 'tiếng việt tiếng', 0, 1, 1.6333, 'T521352', 1, '*'),
(4557, 'tu nhan', 'tu nhan', 0, 1, 1.2333, 'T500', 1, '*'),
(4558, 'tu nhan nguc', 'tu nhan nguc', 0, 1, 1.4, 'T520', 1, '*'),
(4559, 'tuổi', 'tuổi', 0, 0, 0.2667, 'T000', 2, '*'),
(4560, 'tuổi học', 'tuổi học', 0, 1, 1.2667, 'T200', 2, '*'),
(4561, 'tuổi học trò', 'tuổi học trò', 0, 1, 1.4, 'T236', 2, '*'),
(4562, 'va ten', 'va ten', 0, 1, 1.2, 'V350', 1, '*'),
(4563, 'va ten tu', 'va ten tu', 0, 1, 1.3, 'V353', 1, '*'),
(4564, 'việt tiếng', 'việt tiếng', 0, 1, 1.4, 'V352', 1, '*'),
(4565, 'việt tiếng anh', 'việt tiếng anh', 0, 1, 1.5333, 'V3525', 1, '*'),
(4574, '11', '11', 0, 0, 0.2, '', 1, '*'),
(4575, 'bi', 'bi', 0, 0, 0.1333, 'B000', 1, '*'),
(4576, 'bi mat', 'bi mat', 0, 1, 1.2, 'B530', 1, '*'),
(4577, 'bí', 'bí', 0, 0, 0.2, 'B000', 1, '*'),
(4578, 'bí mật', 'bí mật', 0, 1, 1.2667, 'B530', 1, '*'),
(4579, 'chua', 'chua', 0, 0, 0.2667, 'C000', 1, '*'),
(4580, 'chua bi', 'chua bi', 0, 1, 1.2333, 'C100', 1, '*'),
(4581, 'chua bi mat', 'chua bi mat', 0, 1, 1.3667, 'C153', 1, '*'),
(4582, 'chứa', 'chứa', 0, 0, 0.3333, 'C000', 1, '*'),
(4583, 'chứa bí', 'chứa bí', 0, 1, 1.3, 'C100', 1, '*'),
(4584, 'chứa bí mật', 'chứa bí mật', 0, 1, 1.4667, 'C153', 1, '*'),
(4585, 'mat', 'mat', 0, 0, 0.2, 'M300', 1, '*'),
(4586, 'mật', 'mật', 0, 0, 0.2667, 'M300', 1, '*'),
(4587, 'phong', 'phong', 0, 0, 0.3333, 'P520', 1, '*'),
(4588, 'phong chua', 'phong chua', 0, 1, 1.3333, 'P520', 1, '*'),
(4589, 'phong chua bi', 'phong chua bi', 0, 1, 1.4333, 'P521', 1, '*'),
(4590, 'phòng', 'phòng', 0, 0, 0.4, 'P520', 1, '*'),
(4591, 'phòng chứa', 'phòng chứa', 0, 1, 1.4, 'P520', 1, '*'),
(4592, 'phòng chứa bí', 'phòng chứa bí', 0, 1, 1.5333, 'P521', 1, '*'),
(4593, 'potter va phong', 'potter va phong', 0, 1, 1.5, 'P36152', 1, '*'),
(4594, 'potter và phòng', 'potter và phòng', 0, 1, 1.5333, 'P36152', 1, '*'),
(4595, 'va phong', 'va phong', 0, 1, 1.2667, 'V520', 1, '*'),
(4596, 'va phong chua', 'va phong chua', 0, 1, 1.4333, 'V520', 1, '*'),
(4597, 'và phòng', 'và phòng', 0, 1, 1.3, 'V520', 1, '*'),
(4598, 'và phòng chứa', 'và phòng chứa', 0, 1, 1.5, 'V520', 1, '*'),
(4605, '10', '10', 0, 0, 0.2, '', 1, '*'),
(4606, 'bao', 'bao', 0, 0, 0.2, 'B000', 1, '*'),
(4607, 'bao boi', 'bao boi', 0, 1, 1.2333, 'B000', 1, '*'),
(4608, 'bao boi tu', 'bao boi tu', 0, 1, 1.3333, 'B300', 1, '*'),
(4609, 'bảo', 'bảo', 0, 0, 0.2667, 'B000', 1, '*'),
(4610, 'bảo bối', 'bảo bối', 0, 1, 1.3, 'B000', 1, '*'),
(4611, 'bảo bối tử', 'bảo bối tử', 0, 1, 1.4333, 'B300', 1, '*'),
(4612, 'boi', 'boi', 0, 0, 0.2, 'B000', 1, '*'),
(4613, 'boi tu', 'boi tu', 0, 1, 1.2, 'B300', 1, '*'),
(4614, 'boi tu than', 'boi tu than', 0, 1, 1.3667, 'B350', 1, '*'),
(4615, 'bối', 'bối', 0, 0, 0.2667, 'B000', 1, '*'),
(4616, 'bối tử', 'bối tử', 0, 1, 1.2667, 'B300', 1, '*'),
(4617, 'bối tử thần', 'bối tử thần', 0, 1, 1.4667, 'B350', 1, '*'),
(4618, 'potter va bao', 'potter va bao', 0, 1, 1.4333, 'P361', 1, '*'),
(4619, 'potter và bảo', 'potter và bảo', 0, 1, 1.4667, 'P361', 1, '*'),
(4620, 'thần', 'thần', 0, 0, 0.3333, 'T500', 1, '*'),
(4621, 'tu than', 'tu than', 0, 1, 1.2333, 'T500', 1, '*'),
(4622, 'tử thần', 'tử thần', 0, 1, 1.3, 'T500', 1, '*'),
(4623, 'va bao', 'va bao', 0, 1, 1.2, 'V000', 1, '*'),
(4624, 'va bao boi', 'va bao boi', 0, 1, 1.3333, 'V000', 1, '*'),
(4625, 'và bảo', 'và bảo', 0, 1, 1.2333, 'V000', 1, '*'),
(4626, 'và bảo bối', 'và bảo bối', 0, 1, 1.4, 'V000', 1, '*'),
(4729, '7', '7', 0, 0, 0.1, '', 1, '*'),
(4730, 'chiec', 'chiec', 0, 0, 0.3333, 'C000', 1, '*'),
(4731, 'chiec coc', 'chiec coc', 0, 1, 1.3, 'C000', 1, '*'),
(4732, 'chiec coc lua', 'chiec coc lua', 0, 1, 1.4333, 'C400', 1, '*'),
(4733, 'chiếc', 'chiếc', 0, 0, 0.4, 'C000', 1, '*'),
(4734, 'chiếc cốc', 'chiếc cốc', 0, 1, 1.3667, 'C000', 1, '*'),
(4735, 'chiếc cốc lửa', 'chiếc cốc lửa', 0, 1, 1.5333, 'C400', 1, '*'),
(4736, 'coc', 'coc', 0, 0, 0.2, 'C000', 1, '*'),
(4737, 'coc lua', 'coc lua', 0, 1, 1.2333, 'C400', 1, '*'),
(4738, 'cốc', 'cốc', 0, 0, 0.2667, 'C000', 1, '*'),
(4739, 'cốc lửa', 'cốc lửa', 0, 1, 1.3, 'C400', 1, '*'),
(4740, 'jk', 'jk', 0, 0, 0.1333, 'J000', 1, '*'),
(4741, 'jk rowling', 'jk rowling', 0, 1, 1.3333, 'J6452', 1, '*'),
(4742, 'lua', 'lua', 0, 0, 0.2, 'L000', 1, '*'),
(4743, 'lửa', 'lửa', 0, 0, 0.2667, 'L000', 1, '*'),
(4744, 'potter va chiec', 'potter va chiec', 0, 1, 1.5, 'P3612', 1, '*'),
(4745, 'potter và chiếc', 'potter và chiếc', 0, 1, 1.5333, 'P3612', 1, '*'),
(4746, 'rowling', 'rowl', 0, 0, 0.4667, 'R452', 2, '*'),
(4747, 'va chiec', 'va chiec', 0, 1, 1.2667, 'V200', 1, '*'),
(4748, 'va chiec coc', 'va chiec coc', 0, 1, 1.4, 'V200', 1, '*'),
(4749, 'và chiếc', 'và chiếc', 0, 1, 1.3, 'V200', 1, '*'),
(4750, 'và chiếc cốc', 'và chiếc cốc', 0, 1, 1.4667, 'V200', 1, '*'),
(4760, '9', '9', 0, 0, 0.1, '', 1, '*'),
(4761, 'hoang tu', 'hoang tu', 0, 1, 1.2667, 'H523', 1, '*'),
(4762, 'hoang tu lai', 'hoang tu lai', 0, 1, 1.4, 'H5234', 1, '*'),
(4763, 'hoàng tử', 'hoàng tử', 0, 1, 1.3333, 'H523', 1, '*'),
(4764, 'hoàng tử lai', 'hoàng tử lai', 0, 1, 1.4667, 'H5234', 1, '*'),
(4765, 'lai', 'lai', 0, 0, 0.2, 'L000', 1, '*'),
(4766, 'potter va hoang', 'potter va hoang', 0, 1, 1.5, 'P36152', 1, '*'),
(4767, 'potter và hoàng', 'potter và hoàng', 0, 1, 1.5333, 'P36152', 1, '*'),
(4768, 'tu lai', 'tu lai', 0, 1, 1.2, 'T400', 1, '*'),
(4769, 'tử lai', 'tử lai', 0, 1, 1.2333, 'T400', 1, '*'),
(4770, 'va hoang', 'va hoang', 0, 1, 1.2667, 'V520', 1, '*'),
(4771, 'va hoang tu', 'va hoang tu', 0, 1, 1.3667, 'V523', 1, '*'),
(4772, 'và hoàng', 'và hoàng', 0, 1, 1.3, 'V520', 1, '*'),
(4773, 'và hoàng tử', 'và hoàng tử', 0, 1, 1.4333, 'V523', 1, '*'),
(4854, '00', '00', 0, 0, 0.2, '', 1, '*'),
(4855, '00 00', '00 00', 0, 1, 1.1667, '', 1, '*'),
(4856, '13', '13', 0, 0, 0.2, '', 1, '*'),
(4857, '17', '17', 0, 0, 0.2, '', 1, '*'),
(4858, '17 00', '17 00', 0, 1, 1.1667, '', 1, '*'),
(4859, '17 00 00', '17 00 00', 0, 1, 1.2667, '', 1, '*'),
(4860, '1965-07-30', '1965-07-30', 0, 0, 1, '', 1, '*'),
(4861, '1965-07-30 17', '1965-07-30 17', 0, 1, 1.4333, '', 1, '*'),
(4862, '1965-07-30 17 00', '1965-07-30 17 00', 0, 1, 1.5333, '', 1, '*'),
(4863, 'giả', 'giả', 0, 0, 0.2, 'G000', 1, '*'),
(4864, 'j', 'j', 0, 0, 0.0667, 'J000', 1, '*'),
(4865, 'j k', 'j k', 0, 1, 1.1, 'J000', 1, '*'),
(4866, 'j k rowling', 'j k rowling', 0, 1, 1.3667, 'J6452', 1, '*'),
(4867, 'k', 'k', 0, 0, 0.0667, 'K000', 1, '*'),
(4868, 'k rowling', 'k rowling', 0, 1, 1.3, 'K6452', 1, '*'),
(4869, 'tác giả', 'tác giả', 0, 1, 1.2333, 'T200', 1, '*'),
(4916, '5.0', '5.0', 0, 0, 0.3, '', 1, '*'),
(4917, '8', '8', 0, 0, 0.1, '', 1, '*'),
(4918, 'hoi', 'hoi', 0, 0, 0.2, 'H000', 1, '*'),
(4919, 'hoi phuong', 'hoi phuong', 0, 1, 1.3333, 'H152', 1, '*'),
(4920, 'hoi phuong hoang', 'hoi phuong hoang', 0, 1, 1.5333, 'H15252', 1, '*'),
(4921, 'hội', 'hội', 0, 0, 0.2667, 'H000', 1, '*'),
(4922, 'hội phượng', 'hội phượng', 0, 1, 1.4, 'H152', 1, '*'),
(4923, 'hội phượng hoàng', 'hội phượng hoàng', 0, 1, 1.6333, 'H15252', 1, '*'),
(4924, 'phuong', 'phuong', 0, 0, 0.4, 'P520', 1, '*'),
(4925, 'phuong hoang', 'phuong hoang', 0, 1, 1.4, 'P5252', 1, '*'),
(4926, 'phượng', 'phượng', 0, 0, 0.4667, 'P520', 1, '*'),
(4927, 'phượng hoàng', 'phượng hoàng', 0, 1, 1.4667, 'P5252', 1, '*'),
(4928, 'potter va hoi', 'potter va hoi', 0, 1, 1.4333, 'P361', 1, '*'),
(4929, 'potter và hội', 'potter và hội', 0, 1, 1.4667, 'P361', 1, '*'),
(4930, 'va hoi', 'va hoi', 0, 1, 1.2, 'V000', 1, '*'),
(4931, 'va hoi phuong', 'va hoi phuong', 0, 1, 1.4333, 'V520', 1, '*'),
(4932, 'và hội', 'và hội', 0, 1, 1.2333, 'V000', 1, '*'),
(4933, 'và hội phượng', 'và hội phượng', 0, 1, 1.5, 'V520', 1, '*');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_terms_common`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_terms_common` (
  `term` varchar(75) NOT NULL,
  `language` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_finder_terms_common`
--

INSERT INTO `zjw8d_finder_terms_common` (`term`, `language`) VALUES
('a', 'en'),
('about', 'en'),
('after', 'en'),
('ago', 'en'),
('all', 'en'),
('am', 'en'),
('an', 'en'),
('and', 'en'),
('ani', 'en'),
('any', 'en'),
('are', 'en'),
('aren''t', 'en'),
('as', 'en'),
('at', 'en'),
('be', 'en'),
('but', 'en'),
('by', 'en'),
('for', 'en'),
('from', 'en'),
('get', 'en'),
('go', 'en'),
('how', 'en'),
('if', 'en'),
('in', 'en'),
('into', 'en'),
('is', 'en'),
('isn''t', 'en'),
('it', 'en'),
('its', 'en'),
('me', 'en'),
('more', 'en'),
('most', 'en'),
('must', 'en'),
('my', 'en'),
('new', 'en'),
('no', 'en'),
('none', 'en'),
('not', 'en'),
('noth', 'en'),
('nothing', 'en'),
('of', 'en'),
('off', 'en'),
('often', 'en'),
('old', 'en'),
('on', 'en'),
('onc', 'en'),
('once', 'en'),
('onli', 'en'),
('only', 'en'),
('or', 'en'),
('other', 'en'),
('our', 'en'),
('ours', 'en'),
('out', 'en'),
('over', 'en'),
('page', 'en'),
('she', 'en'),
('should', 'en'),
('small', 'en'),
('so', 'en'),
('some', 'en'),
('than', 'en'),
('thank', 'en'),
('that', 'en'),
('the', 'en'),
('their', 'en'),
('theirs', 'en'),
('them', 'en'),
('then', 'en'),
('there', 'en'),
('these', 'en'),
('they', 'en'),
('this', 'en'),
('those', 'en'),
('thus', 'en'),
('time', 'en'),
('times', 'en'),
('to', 'en'),
('too', 'en'),
('true', 'en'),
('under', 'en'),
('until', 'en'),
('up', 'en'),
('upon', 'en'),
('use', 'en'),
('user', 'en'),
('users', 'en'),
('veri', 'en'),
('version', 'en'),
('very', 'en'),
('via', 'en'),
('want', 'en'),
('was', 'en'),
('way', 'en'),
('were', 'en'),
('what', 'en'),
('when', 'en'),
('where', 'en'),
('whi', 'en'),
('which', 'en'),
('who', 'en'),
('whom', 'en'),
('whose', 'en'),
('why', 'en'),
('wide', 'en'),
('will', 'en'),
('with', 'en'),
('within', 'en'),
('without', 'en'),
('would', 'en'),
('yes', 'en'),
('yet', 'en'),
('you', 'en'),
('your', 'en'),
('yours', 'en');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_tokens`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_tokens` (
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '1',
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `language` char(3) NOT NULL DEFAULT ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_tokens_aggregate`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_tokens_aggregate` (
  `term_id` int(10) unsigned NOT NULL,
  `map_suffix` char(1) NOT NULL,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `term_weight` float unsigned NOT NULL,
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `context_weight` float unsigned NOT NULL,
  `total_weight` float unsigned NOT NULL,
  `language` char(3) NOT NULL DEFAULT ''
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_finder_types`
--

CREATE TABLE IF NOT EXISTS `zjw8d_finder_types` (
`id` int(10) unsigned NOT NULL,
  `title` varchar(100) NOT NULL,
  `mime` varchar(100) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `zjw8d_finder_types`
--

INSERT INTO `zjw8d_finder_types` (`id`, `title`, `mime`) VALUES
(1, 'ZOO Item', ''),
(2, 'Tag', ''),
(3, 'Category', ''),
(4, 'Contact', ''),
(5, 'Article', ''),
(6, 'News Feed', ''),
(7, 'Web Link', '');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_aliases`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_aliases` (
  `alias` varchar(255) NOT NULL,
  `type` varchar(10) NOT NULL,
  `item` varchar(32) NOT NULL,
  `state` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_kunena_aliases`
--

INSERT INTO `zjw8d_kunena_aliases` (`alias`, `type`, `item`, `state`) VALUES
('announcement', 'view', 'announcement', 1),
('bai-hoc-thanh-cong', 'catid', '51', 0),
('category', 'view', 'category', 1),
('category/create', 'layout', 'category.create', 1),
('category/default', 'layout', 'category.default', 1),
('category/edit', 'layout', 'category.edit', 1),
('category/manage', 'layout', 'category.manage', 1),
('category/moderate', 'layout', 'category.moderate', 1),
('category/user', 'layout', 'category.user', 1),
('chung-khoan-dau-tu', 'catid', '53', 0),
('common', 'view', 'common', 1),
('create', 'layout', 'category.create', 0),
('credits', 'view', 'credits', 1),
('da-su', 'catid', '42', 0),
('default', 'layout', 'category.default', 0),
('dia-ly', 'catid', '46', 0),
('du-an-tao-sach-cho-thu-vien', 'catid', '79', 0),
('edit', 'layout', 'category.edit', 0),
('gioi-thieu-sach-hay', 'catid', '67', 0),
('gioi-tinh', 'catid', '40', 0),
('hinh-su', 'catid', '31', 0),
('hoi-ky', 'catid', '21', 0),
('home', 'view', 'home', 1),
('huong-dan-chung', 'catid', '5', 0),
('kho-du-lieu-scan', 'catid', '80', 0),
('kho-sach-hoc-tro-thieu-nhi', 'catid', '8', 0),
('kho-sach-hoi-ky-nhat-ky', 'catid', '20', 0),
('kho-sach-khoa-hoc-ki-thuat', 'catid', '47', 0),
('kho-sach-kinh-te-phap-luat', 'catid', '50', 0),
('kho-sach-lich-su-dia-ly', 'catid', '41', 0),
('kho-sach-phieu-luu-mao-hiem', 'catid', '23', 0),
('kho-sach-sach-chuyen-nganh', 'catid', '55', 0),
('kho-sach-sach-giao-trinh', 'catid', '56', 0),
('kho-sach-tam-ly-gioi-tinh', 'catid', '38', 0),
('kho-sach-the-loai-khac', 'catid', '58', 0),
('kho-sach-thi-ca-truyen-ngu-ngon', 'catid', '10', 0),
('kho-sach-thu-vien-epub-viet', 'catid', '7', 0),
('kho-sach-tieu-thuyet-tinh-cam', 'catid', '11', 0),
('kho-sach-trinh-tham-hinh-su', 'catid', '29', 0),
('kho-sach-truyen-chuong', 'catid', '13', 0),
('kho-sach-truyen-cuoi-dan-gian', 'catid', '17', 0),
('kho-sach-truyen-ma-kinh-di', 'catid', '32', 0),
('kho-sach-tu-sang-tac', 'catid', '57', 0),
('kho-sach-van-hoc', 'catid', '9', 0),
('kho-sach-van-hoc-xa-hoi', 'catid', '35', 0),
('kho-sach-vien-tuong-than-thoai', 'catid', '26', 0),
('khoa-hoc', 'catid', '48', 0),
('khoa-hoc-thuong-thuc', 'catid', '36', 0),
('khu-vuc-xu-ly-rac', 'catid', '81', 0),
('ki-thuat', 'catid', '49', 0),
('kiem-hiep', 'catid', '14', 0),
('kien-thuc-phap-luat', 'catid', '54', 0),
('kinh-di', 'catid', '34', 0),
('lich-su-the-gioi', 'catid', '44', 0),
('lich-su-viet-nam', 'catid', '45', 0),
('main-forum', 'catid', '1', 1),
('manage', 'layout', 'category.manage', 0),
('mao-hiem', 'catid', '25', 0),
('misc', 'view', 'misc', 1),
('moderate', 'layout', 'category.moderate', 0),
('nghe-thuat-song', 'catid', '37', 0),
('ngon-tinh-trung-quoc', 'catid', '12', 0),
('nhat-ky', 'catid', '22', 0),
('noi-quy', 'catid', '2', 0),
('phat-trien-thu-vien-epub-viet', 'catid', '66', 0),
('phieu-luu', 'catid', '24', 0),
('phong-cong-tac', 'catid', '78', 0),
('phong-dich-thuat', 'catid', '70', 0),
('quan-tri-kinh-doanh', 'catid', '52', 0),
('sac-hiep', 'catid', '16', 0),
('sach-ngon-ngu-khac', 'catid', '77', 0),
('sach-tieng-anh', 'catid', '71', 0),
('sach-tieng-duc', 'catid', '72', 0),
('sach-tieng-nga', 'catid', '75', 0),
('sach-tieng-nhat', 'catid', '76', 0),
('sach-tieng-phap', 'catid', '74', 0),
('sach-tieng-trung-quoc', 'catid', '73', 0),
('search', 'view', 'search', 1),
('statistics', 'view', 'statistics', 1),
('su-thi', 'catid', '43', 0),
('suggestion-box', 'catid', '3', 1),
('tac-pham-va-cam-nhan', 'catid', '68', 0),
('tam-ly', 'catid', '39', 0),
('than-thoai', 'catid', '28', 0),
('thi-ca', 'catid', '64', 0),
('thieu-nhi', 'catid', '59', 0),
('thong-bao-tu-ban-quan-ly', 'catid', '3', 0),
('thung-rac', 'catid', '82', 0),
('tien-hiep', 'catid', '15', 0),
('tin-tuc-su-kien', 'catid', '6', 0),
('tin-tuc-thong-bao-chung', 'catid', '1', 0),
('topic', 'view', 'topic', 1),
('topics', 'view', 'topics', 1),
('trao-doi-mua-ban-chuyen-nhuong-sach', 'catid', '69', 0),
('trinh-tham', 'catid', '30', 0),
('truyen-cuoi-tieu-lam', 'catid', '18', 0),
('truyen-dan-gian', 'catid', '19', 0),
('truyen-ma', 'catid', '33', 0),
('truyen-ngu-ngon', 'catid', '65', 0),
('tuoi-hoc-tro', 'catid', '60', 0),
('user', 'view', 'user', 1),
('van-hoc-co-dien', 'catid', '61', 0),
('van-hoc-nuoc-ngoai', 'catid', '62', 0),
('van-hoc-viet-nam', 'catid', '63', 0),
('vien-tuong', 'catid', '27', 0),
('welcome-mat', 'catid', '2', 1),
('y-kien-dong-gop-xay-dung-hoi-dap', 'catid', '4', 0);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_announcement`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_announcement` (
`id` int(3) NOT NULL,
  `title` tinytext NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT '0',
  `sdescription` text NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `ordering` tinyint(4) NOT NULL DEFAULT '0',
  `showdate` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_attachments`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_attachments` (
`id` int(11) NOT NULL,
  `mesid` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `hash` char(32) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `folder` varchar(255) NOT NULL,
  `filetype` varchar(20) NOT NULL,
  `filename` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_categories`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_categories` (
`id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT '0',
  `name` tinytext,
  `alias` varchar(255) NOT NULL,
  `icon_id` tinyint(4) NOT NULL DEFAULT '0',
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `accesstype` varchar(20) NOT NULL DEFAULT 'joomla.level',
  `access` int(11) NOT NULL DEFAULT '0',
  `pub_access` int(11) NOT NULL DEFAULT '1',
  `pub_recurse` tinyint(4) DEFAULT '1',
  `admin_access` int(11) NOT NULL DEFAULT '0',
  `admin_recurse` tinyint(4) DEFAULT '1',
  `ordering` smallint(6) NOT NULL DEFAULT '0',
  `published` tinyint(4) NOT NULL DEFAULT '0',
  `channels` text,
  `checked_out` tinyint(4) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review` tinyint(4) NOT NULL DEFAULT '0',
  `allow_anonymous` tinyint(4) NOT NULL DEFAULT '0',
  `post_anonymous` tinyint(4) NOT NULL DEFAULT '0',
  `hits` int(11) NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `headerdesc` text NOT NULL,
  `class_sfx` varchar(20) NOT NULL,
  `allow_polls` tinyint(4) NOT NULL DEFAULT '0',
  `topic_ordering` varchar(16) NOT NULL DEFAULT 'lastpost',
  `numTopics` mediumint(8) NOT NULL DEFAULT '0',
  `numPosts` mediumint(8) NOT NULL DEFAULT '0',
  `last_topic_id` int(11) NOT NULL DEFAULT '0',
  `last_post_id` int(11) NOT NULL DEFAULT '0',
  `last_post_time` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=83 ;

--
-- Dumping data for table `zjw8d_kunena_categories`
--

INSERT INTO `zjw8d_kunena_categories` (`id`, `parent_id`, `name`, `alias`, `icon_id`, `locked`, `accesstype`, `access`, `pub_access`, `pub_recurse`, `admin_access`, `admin_recurse`, `ordering`, `published`, `channels`, `checked_out`, `checked_out_time`, `review`, `allow_anonymous`, `post_anonymous`, `hits`, `description`, `headerdesc`, `class_sfx`, `allow_polls`, `topic_ordering`, `numTopics`, `numPosts`, `last_topic_id`, `last_post_id`, `last_post_time`, `params`) VALUES
(1, 0, 'Tin tức Thông báo chung', 'tin-tuc-thong-bao-chung', 0, 0, 'joomla.group', 1, 1, 1, 0, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(2, 1, 'Nội quy', 'noi-quy', 0, 0, 'joomla.group', 1, 1, 1, 0, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Nội Quy Thư viện ePub Việt', '', '', 0, 'lastpost', 1, 1, 1, 1, 1413343175, '{"access_post":["6","2","8"],"access_reply":["6","2","8"]}'),
(3, 1, 'Thông báo từ BQL', 'thong-bao-tu-ban-quan-ly', 0, 0, 'joomla.group', 1, 1, 1, 0, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Thông báo, tin tức, sự kiện từ Ban quản lý Thư viện ePub Việt.', '', '', 1, 'lastpost', 0, 0, 0, 0, 0, '{"access_post":["6","2","8"],"access_reply":["6","2","8"]}'),
(4, 1, 'Ý kiến ~ Đóng góp ~ Xây dựng ~ Hỏi đáp', 'y-kien-dong-gop-xay-dung-hoi-dap', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 4, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Ý kiến góp ý, hỏi đáp, giao lưu với Ban quản lý để xây dựng, phát triển, hoàn thiện Thư viện ePub Việt.', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(5, 1, 'Hướng dẫn chung', 'huong-dan-chung', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 5, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Hướng dẫn sử dụng Thư viện - Hướng dẫn sử dụng sách điện tử (eBook) và các thiết bị đọc sách (eReader).', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(6, 1, 'Tin tức ~ Sự kiện', 'tin-tuc-su-kien', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 3, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Những tin tức, sự kiện văn hóa, văn học, nghệ thuật,…liên quan đến văn hóa đọc: tác giả, tác phẩm, giới thiệu,…', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(7, 0, 'Kho sách Thư viện ePub Việt', 'kho-sach-thu-vien-epub-viet', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Kho dữ liệu sách truyện, tài liệu trên Thư viện ePub Việt.', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(8, 7, 'Kho sách Học trò - Thiếu nhi', 'kho-sach-hoc-tro-thieu-nhi', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Kho sách dành cho các loại sách dành cho lứa tuổi dưới 16 và những ai cảm thấy mình mãi mãi tuổi ... mười sáu.', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(9, 7, 'Kho sách Văn học', 'kho-sach-van-hoc', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Những tác phẩm, tác giả văn học cổ điển, văn học Việt Nam, nước ngoài, những tác phẩm văn học dịch chưa được phân loại.', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(10, 7, 'Kho sách Thi ca - Truyện ngụ ngôn', 'kho-sach-thi-ca-truyen-ngu-ngon', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 8, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Các tác phẩm thi ca, thơ cổ, thơ hiện đại, truyện ngụ ngôn,...', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(11, 7, 'Kho sách Tiểu thuyết tình cảm', 'kho-sach-tieu-thuyet-tinh-cam', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 7, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(12, 11, 'Ngôn tình Trung Quốc', 'ngon-tinh-trung-quoc', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Ngôn tình Trung Quốc', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(13, 7, 'Kho sách Truyện chưởng', 'kho-sach-truyen-chuong', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 5, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Các tác phẩm truyện Kiếm hiệp - Tiên hiệp - Sắc hiệp.', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(14, 13, 'Kiếm hiệp', 'kiem-hiep', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(15, 13, 'Tiên hiệp', 'tien-hiep', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(16, 13, 'Sắc hiệp', 'sac-hiep', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 3, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(17, 7, 'Kho sách Truyện cười - Dân gian', 'kho-sach-truyen-cuoi-dan-gian', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 6, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(18, 17, 'Truyện cười Tiếu lâm', 'truyen-cuoi-tieu-lam', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Một nụ cười là mười thang thuốc bổ!!!', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{"access_post":["6","2","8"],"access_reply":["6","2","8"]}'),
(19, 17, 'Truyện Dân gian', 'truyen-dan-gian', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{"access_post":["6","2","8"],"access_reply":["6","2","8"]}'),
(20, 7, 'Kho sách Hồi ký - Nhật ký', 'kho-sach-hoi-ky-nhat-ky', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 9, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(21, 20, 'Hồi ký', 'hoi-ky', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(22, 20, 'Nhật ký', 'nhat-ky', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(23, 7, 'Kho sách Phiêu lưu - Mạo hiểm', 'kho-sach-phieu-luu-mao-hiem', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 10, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(24, 23, 'Phiêu lưu', 'phieu-luu', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(25, 23, 'Mạo hiểm', 'mao-hiem', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(26, 7, 'Kho sách Viễn tưởng - Thần thoại', 'kho-sach-vien-tuong-than-thoai', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 11, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(27, 26, 'Viễn tưởng', 'vien-tuong', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(28, 26, 'Thần thoại', 'than-thoai', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(29, 7, 'Kho sách Trinh thám - Hình sự', 'kho-sach-trinh-tham-hinh-su', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 12, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(30, 29, 'Trinh thám Hình sự', 'trinh-tham', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(31, 29, 'Hình sự', 'hinh-su', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(32, 7, 'Kho sách Truyện ma - Kinh dị', 'kho-sach-truyen-ma-kinh-di', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 13, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(33, 32, 'Truyện ma', 'truyen-ma', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(34, 32, 'Kinh dị', 'kinh-di', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(35, 7, 'Kho sách Văn hóa - Xã hội', 'kho-sach-van-hoc-xa-hoi', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 15, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(36, 35, 'Khoa học thường thức', 'khoa-hoc-thuong-thuc', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{"access_post":["6","2","8"],"access_reply":["6","2","8"]}'),
(37, 35, 'Nghệ thuật sống', 'nghe-thuat-song', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{"access_post":["6","2","8"],"access_reply":["6","2","8"]}'),
(38, 7, 'Kho sách Tâm lý - Giới tính', 'kho-sach-tam-ly-gioi-tinh', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 14, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(39, 38, 'Tâm lý', 'tam-ly', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(40, 38, 'Giới tính', 'gioi-tinh', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(41, 7, 'Kho sách Lịch sử - Địa lý', 'kho-sach-lich-su-dia-ly', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 16, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '"Dân ta phải biết sử ta...", hiểu biết lịch sử, địa lý thế giới là một kiến thức rất bổ ích và thú vị.', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(42, 41, 'Dã sử', 'da-su', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(43, 41, 'Sử thi', 'su-thi', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(44, 41, 'Lịch sử Thế giới', 'lich-su-the-gioi', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 3, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(45, 41, 'Lịch sử Việt Nam', 'lich-su-viet-nam', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 4, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(46, 41, 'Địa lý', 'dia-ly', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 5, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(47, 7, 'Kho sách Khoa học Kĩ thuật', 'kho-sach-khoa-hoc-ki-thuat', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 3, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(48, 47, 'Khoa học', 'khoa-hoc', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(49, 47, 'Kĩ thuật', 'ki-thuat', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(50, 7, 'Kho sách Kinh tế - Pháp luật', 'kho-sach-kinh-te-phap-luat', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 4, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(51, 50, 'Bài học Thành công', 'bai-hoc-thanh-cong', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(52, 50, 'Quản trị Kinh doanh', 'quan-tri-kinh-doanh', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(53, 50, 'Chứng khoán Đầu tư', 'chung-khoan-dau-tu', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 3, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(54, 50, 'Kiến thức Pháp luật', 'kien-thuc-phap-luat', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 4, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(55, 7, 'Kho sách Sách Chuyên ngành', 'kho-sach-sach-chuyen-nganh', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 18, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(56, 7, 'Kho sách Sách giáo trình', 'kho-sach-sach-giao-trinh', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 17, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(57, 7, 'Kho sách Tự sáng tác', 'kho-sach-tu-sang-tac', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 19, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(58, 7, 'Kho sách Thể loại khác', 'kho-sach-the-loai-khac', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 20, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Kho sách chưa xác định được thể loại, chưa thể phân loại, sắp xếp chuyên mục cụ thể.', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(59, 8, 'Thiếu nhi', 'thieu-nhi', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(60, 8, 'Tuổi học trò', 'tuoi-hoc-tro', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(61, 9, 'Văn học cổ điển', 'van-hoc-co-dien', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(62, 9, 'Văn học nước ngoài', 'van-hoc-nuoc-ngoai', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(63, 9, 'Văn học Việt Nam', 'van-hoc-viet-nam', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 3, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(64, 10, 'Thi ca', 'thi-ca', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(65, 10, 'Truyện Ngụ ngôn', 'truyen-ngu-ngon', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(66, 0, 'Phát triển Thư viện ePub Việt', 'phat-trien-thu-vien-epub-viet', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 3, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Đóng góp, xây dựng dữ liệu, nguồn sách cho Thư viện', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(67, 66, 'Giới thiệu Sách hay', 'gioi-thieu-sach-hay', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Giới thiệu những cuốn sách truyện hay chưa có trên Thư viện ePub Việt.', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(68, 66, 'Tác phẩm và Cảm nhận', 'tac-pham-va-cam-nhan', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(69, 66, 'Trao đổi - Mua bán - Chuyển nhượng Sách', 'trao-doi-mua-ban-chuyen-nhuong-sach', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 3, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(70, 66, 'Phòng Dịch thuật', 'phong-dich-thuat', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 4, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Phòng Dịch thuật', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(71, 70, 'Sách tiếng Anh', 'sach-tieng-anh', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(72, 70, 'Sách tiếng Đức', 'sach-tieng-duc', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(73, 70, 'Sách tiếng Trung Quốc', 'sach-tieng-trung-quoc', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 6, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(74, 70, 'Sách tiếng Pháp', 'sach-tieng-phap', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 5, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(75, 70, 'Sách tiếng Nga', 'sach-tieng-nga', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 3, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(76, 70, 'Sách tiếng Nhật', 'sach-tieng-nhat', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 4, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(77, 70, 'Sách ngôn ngữ khác', 'sach-ngon-ngu-khac', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 7, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Sách ngôn ngữ chưa tạo chuyên mục trên (diễn đàn) Thư viện ePub Việt', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(78, 66, 'Phòng Cộng tác', 'phong-cong-tac', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 5, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(79, 78, 'Dự án tạo sách cho Thư viện', 'du-an-tao-sach-cho-thu-vien', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(80, 78, 'Kho dữ liệu scan', 'kho-du-lieu-scan', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 2, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Kho dữ liệu sách truyện, tác phẩm đã được scan nhưng chưa tạo được dự án sách (chuyển đổi sang các định dạng văn bản (ebook hóa)).', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(81, 0, 'Khu vực xử lý rác', 'khu-vuc-xu-ly-rac', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 4, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Chứa các thông tin sai phạm, không phù hợp Nội quy diễn đàn,...', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}'),
(82, 81, 'Thùng rác', 'thung-rac', 0, 0, 'joomla.level', 1, 1, 1, 8, 1, 1, 1, NULL, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'Khu vực chứa bài viết vi phạm Nội quy Thư viện và các bài viết với nội dung quảng cáo, spam trái phép. Bài viết trong thùng rác sẽ được xoá tự động sau 7 ngày.', '', '', 0, 'lastpost', 0, 0, 0, 0, 0, '{}');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_configuration`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_configuration` (
  `id` int(11) NOT NULL DEFAULT '0',
  `params` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_kunena_configuration`
--

INSERT INTO `zjw8d_kunena_configuration` (`id`, `params`) VALUES
(1, '{"board_title":"Di\\u00ea\\u0303n \\u0111a\\u0300n ~ Forum","email":"","board_offline":"0","offline_message":"<h2>\\u00a0\\u00a0Di\\u00ea\\u0303n \\u0111a\\u0300n \\u0111ang \\u0111\\u01b0\\u01a1\\u0323c n\\u00e2ng c\\u00e2\\u0301p ho\\u0103\\u0323c ba\\u0309o tri\\u0300.<\\/h2>\\r\\n<div>\\u00a0\\u00a0\\u00a0Vui lo\\u0300ng quay la\\u0323i sau!<\\/div>\\r\\n<h2>\\u00a0\\u00a0The Forum is currently offline for maintenance.<\\/h2>\\r\\n<div>\\u00a0\\u00a0\\u00a0Check back soon!<\\/div>","enablerss":"1","threads_per_page":"20","messages_per_page":"6","messages_per_page_search":"15","showhistory":"1","historylimit":"6","shownew":"1","disemoticons":"0","template":"blue_eagle","showannouncement":"1","avataroncat":"0","catimagepath":"category_images","showchildcaticon":"1","rtewidth":"450","rteheight":"300","enableforumjump":"1","reportmsg":"1","username":"1","askemail":"0","showemail":"0","showuserstats":"1","showkarma":"1","useredit":"1","useredittime":"0","useredittimegrace":"600","editmarkup":"1","allowsubscriptions":"1","subscriptionschecked":"1","allowfavorites":"1","maxsubject":"50","maxsig":"300","regonly":"0","pubwrite":"0","floodprotection":"0","mailmod":"0","mailadmin":"0","captcha":"1","mailfull":"1","allowavatarupload":"1","allowavatargallery":"1","avatarquality":"75","avatarsize":"2048","imageheight":"800","imagewidth":"800","imagesize":"150","filetypes":"txt,rtf,pdf,zip,tar.gz,tgz,tar.bz2,epub","filesize":"4096","showranking":"1","rankimages":"1","userlist_rows":"30","userlist_online":"1","userlist_avatar":"1","userlist_name":"1","userlist_posts":"1","userlist_karma":"1","userlist_email":"0","userlist_joindate":"1","userlist_lastvisitdate":"1","userlist_userhits":"1","latestcategory":"","showstats":"1","showwhoisonline":"1","showgenstats":"1","showpopuserstats":"1","popusercount":"5","showpopsubjectstats":"1","popsubjectcount":"5","usernamechange":"0","showspoilertag":"1","showvideotag":"1","showebaytag":"1","trimlongurls":"1","trimlongurlsfront":"40","trimlongurlsback":"20","autoembedyoutube":"1","autoembedebay":"1","ebaylanguagecode":"en-us","sessiontimeout":"1800","highlightcode":"0","rss_type":"topic","rss_timelimit":"month","rss_limit":"100","rss_included_categories":"","rss_excluded_categories":"","rss_specification":"rss2.0","rss_allow_html":"1","rss_author_format":"name","rss_author_in_title":"1","rss_word_count":"0","rss_old_titles":"1","rss_cache":"900","defaultpage":"recent","default_sort":"asc","sef":"1","showimgforguest":"1","showfileforguest":"1","pollnboptions":"4","pollallowvoteone":"1","pollenabled":"1","poppollscount":"5","showpoppollstats":"1","polltimebtvotes":"00:15:00","pollnbvotesbyuser":"100","pollresultsuserslist":"1","maxpersotext":"50","ordering_system":"mesid","post_dateformat":"ago","post_dateformat_hover":"datetime","hide_ip":"1","imagetypes":"jpg,jpeg,gif,png","checkmimetypes":"1","imagemimetypes":"image\\/jpeg,image\\/jpg,image\\/gif,image\\/png","imagequality":"50","thumbheight":"32","thumbwidth":"32","hideuserprofileinfo":"put_empty","boxghostmessage":"0","userdeletetmessage":"0","latestcategory_in":"1","topicicons":"1","debug":"0","catsautosubscribed":0,"showbannedreason":"0","version_check":"1","showthankyou":"1","showpopthankyoustats":"1","popthankscount":"5","mod_see_deleted":"0","bbcode_img_secure":"text","listcat_show_moderators":"1","lightbox":"1","show_list_time":"720","show_session_type":"0","show_session_starttime":"0","userlist_allowed":"0","userlist_count_users":"1","enable_threaded_layouts":"0","category_subscriptions":"post","topic_subscriptions":"every","pubprofile":"1","thankyou_max":"10","email_recipient_count":"0","email_recipient_privacy":"bcc","email_visible_address":"","captcha_post_limit":"0","recaptcha_publickey":"6Ld__eMSAAAAAKD1DRBRwpP7YQu1boE0WwmYYPih","recaptcha_privatekey":"6Ld__eMSAAAAAErli3Nbe_kHyrNvI5qMIkvjmsyJ","recaptcha_theme":"white","keywords":0,"userkeywords":0,"image_upload":"registered","file_upload":"registered","topic_layout":"flat","time_to_create_page":"1","show_imgfiles_manage_profile":"1","hold_newusers_posts":"0","hold_guest_posts":"0","attachment_limit":"8","pickup_category":"0","article_display":"intro","send_emails":"1","stopforumspam_key":"n97qw18mcirjxd","fallback_english":"1","cache":"1","cache_time":"60","ebay_affiliate_id":"5337089937","iptracking":"1","rss_feedburner_url":"","autolink":"1","access_component":"1","statslink_allowed":"1","superadmin_userlist":"0","plugins":{"plg_system_kunena":{"jcontentevents":"0","jcontentevent_target":"body"}}}');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_keywords`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_keywords` (
`id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `public_count` int(11) NOT NULL,
  `total_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_keywords_map`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_keywords_map` (
  `keyword_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_messages`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_messages` (
`id` int(11) NOT NULL,
  `parent` int(11) DEFAULT '0',
  `thread` int(11) DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `name` tinytext,
  `userid` int(11) NOT NULL DEFAULT '0',
  `email` tinytext,
  `subject` tinytext,
  `time` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(128) DEFAULT NULL,
  `topic_emoticon` int(11) NOT NULL DEFAULT '0',
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `hold` tinyint(4) NOT NULL DEFAULT '0',
  `ordering` int(11) DEFAULT '0',
  `hits` int(11) DEFAULT '0',
  `moved` tinyint(4) DEFAULT '0',
  `modified_by` int(7) DEFAULT NULL,
  `modified_time` int(11) DEFAULT NULL,
  `modified_reason` tinytext
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `zjw8d_kunena_messages`
--

INSERT INTO `zjw8d_kunena_messages` (`id`, `parent`, `thread`, `catid`, `name`, `userid`, `email`, `subject`, `time`, `ip`, `topic_emoticon`, `locked`, `hold`, `ordering`, `hits`, `moved`, `modified_by`, `modified_time`, `modified_reason`) VALUES
(1, 0, 1, 2, 'Kunena', 585, NULL, 'Welcome to Kunena!', 1413343175, '127.0.0.1', 0, 0, 0, 0, 0, 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_messages_text`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_messages_text` (
  `mesid` int(11) NOT NULL DEFAULT '0',
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_kunena_messages_text`
--

INSERT INTO `zjw8d_kunena_messages_text` (`mesid`, `message`) VALUES
(1, '[size=4][b]Welcome to Kunena![/b][/size] \n\n Thank you for choosing Kunena for your community forum needs in Joomla. \n\n Kunena, translated from Swahili meaning “to speak”, is built by a team of open source professionals with the goal of providing a top quality, tightly unified forum solution for Joomla. \n\n\n [size=4][b]Additional Kunena Resources[/b][/size] \n\n [b]Kunena Documentation:[/b] [url]http://www.kunena.org/docs[/url] \n\n [b]Kunena Support Forum[/b]: [url]http://www.kunena.org/forum[/url] \n\n [b]Kunena Downloads:[/b] [url]http://www.kunena.org/download[/url] \n\n [b]Kunena Blog:[/b] [url]http://www.kunena.org/blog[/url] \n\n [b]Follow Kunena on Twitter:[/b] [url]http://www.kunena.org/twitter[/url]');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_polls`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_polls` (
`id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `threadid` int(11) NOT NULL,
  `polltimetolive` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_polls_options`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_polls_options` (
`id` int(11) NOT NULL,
  `pollid` int(11) DEFAULT NULL,
  `text` varchar(100) DEFAULT NULL,
  `votes` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_polls_users`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_polls_users` (
  `pollid` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `votes` int(11) DEFAULT NULL,
  `lasttime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvote` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_ranks`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_ranks` (
`rank_id` mediumint(8) unsigned NOT NULL,
  `rank_title` varchar(255) NOT NULL DEFAULT '',
  `rank_min` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `rank_special` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `rank_image` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `zjw8d_kunena_ranks`
--

INSERT INTO `zjw8d_kunena_ranks` (`rank_id`, `rank_title`, `rank_min`, `rank_special`, `rank_image`) VALUES
(1, 'New Member', 0, 0, 'rank1.gif'),
(2, 'Junior Member', 20, 0, 'rank2.gif'),
(3, 'Senior Member', 40, 0, 'rank3.gif'),
(4, 'Premium Member', 80, 0, 'rank4.gif'),
(5, 'Elite Member', 160, 0, 'rank5.gif'),
(6, 'Platinum Member', 320, 0, 'rank6.gif'),
(7, 'Administrator', 0, 1, 'rankadmin.gif'),
(8, 'Moderator', 0, 1, 'rankmod.gif'),
(9, 'Spammer', 0, 1, 'rankspammer.gif'),
(10, 'Banned', 0, 1, 'rankbanned.gif');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_sessions`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_sessions` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `allowed` text,
  `lasttime` int(11) NOT NULL DEFAULT '0',
  `readtopics` text,
  `currvisit` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_smileys`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_smileys` (
`id` int(4) NOT NULL,
  `code` varchar(12) NOT NULL DEFAULT '',
  `location` varchar(50) NOT NULL DEFAULT '',
  `greylocation` varchar(60) NOT NULL DEFAULT '',
  `emoticonbar` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `zjw8d_kunena_smileys`
--

INSERT INTO `zjw8d_kunena_smileys` (`id`, `code`, `location`, `greylocation`, `emoticonbar`) VALUES
(1, 'B)', 'cool.png', 'cool-grey.png', 1),
(2, '8)', 'cool.png', 'cool-grey.png', 0),
(3, '8-)', 'cool.png', 'cool-grey.png', 0),
(4, ':-(', 'sad.png', 'sad-grey.png', 0),
(5, ':(', 'sad.png', 'sad-grey.png', 1),
(6, ':sad:', 'sad.png', 'sad-grey.png', 0),
(7, ':cry:', 'sad.png', 'sad-grey.png', 0),
(8, ':)', 'smile.png', 'smile-grey.png', 1),
(9, ':-)', 'smile.png', 'smile-grey.png', 0),
(10, ':cheer:', 'cheerful.png', 'cheerful-grey.png', 1),
(11, ';)', 'wink.png', 'wink-grey.png', 1),
(12, ';-)', 'wink.png', 'wink-grey.png', 0),
(13, ':wink:', 'wink.png', 'wink-grey.png', 0),
(14, ';-)', 'wink.png', 'wink-grey.png', 0),
(15, ':P', 'tongue.png', 'tongue-grey.png', 1),
(16, ':p', 'tongue.png', 'tongue-grey.png', 0),
(17, ':-p', 'tongue.png', 'tongue-grey.png', 0),
(18, ':-P', 'tongue.png', 'tongue-grey.png', 0),
(19, ':razz:', 'tongue.png', 'tongue-grey.png', 0),
(20, ':angry:', 'angry.png', 'angry-grey.png', 1),
(21, ':mad:', 'angry.png', 'angry-grey.png', 0),
(22, ':unsure:', 'unsure.png', 'unsure-grey.png', 1),
(23, ':o', 'shocked.png', 'shocked-grey.png', 0),
(24, ':-o', 'shocked.png', 'shocked-grey.png', 0),
(25, ':O', 'shocked.png', 'shocked-grey.png', 0),
(26, ':-O', 'shocked.png', 'shocked-grey.png', 0),
(27, ':eek:', 'shocked.png', 'shocked-grey.png', 0),
(28, ':ohmy:', 'shocked.png', 'shocked-grey.png', 1),
(29, ':huh:', 'wassat.png', 'wassat-grey.png', 1),
(30, ':?', 'confused.png', 'confused-grey.png', 0),
(31, ':-?', 'confused.png', 'confused-grey.png', 0),
(32, ':???', 'confused.png', 'confused-grey.png', 0),
(33, ':dry:', 'ermm.png', 'ermm-grey.png', 1),
(34, ':ermm:', 'ermm.png', 'ermm-grey.png', 0),
(35, ':lol:', 'grin.png', 'grin-grey.png', 1),
(36, ':X', 'sick.png', 'sick-grey.png', 0),
(37, ':x', 'sick.png', 'sick-grey.png', 0),
(38, ':sick:', 'sick.png', 'sick-grey.png', 1),
(39, ':silly:', 'silly.png', 'silly-grey.png', 1),
(40, ':y32b4:', 'silly.png', 'silly-grey.png', 0),
(41, ':blink:', 'blink.png', 'blink-grey.png', 1),
(42, ':blush:', 'blush.png', 'blush-grey.png', 1),
(43, ':oops:', 'blush.png', 'blush-grey.png', 1),
(44, ':kiss:', 'kissing.png', 'kissing-grey.png', 1),
(45, ':rolleyes:', 'blink.png', 'blink-grey.png', 0),
(46, ':roll:', 'blink.png', 'blink-grey.png', 0),
(47, ':woohoo:', 'w00t.png', 'w00t-grey.png', 1),
(48, ':side:', 'sideways.png', 'sideways-grey.png', 1),
(49, ':S', 'dizzy.png', 'dizzy-grey.png', 1),
(50, ':s', 'dizzy.png', 'dizzy-grey.png', 0),
(51, ':evil:', 'devil.png', 'devil-grey.png', 1),
(52, ':twisted:', 'devil.png', 'devil-grey.png', 0),
(53, ':whistle:', 'whistling.png', 'whistling-grey.png', 1),
(54, ':pinch:', 'pinch.png', 'pinch-grey.png', 1),
(55, ':D', 'laughing.png', 'laughing-grey.png', 0),
(56, ':-D', 'laughing.png', 'laughing-grey.png', 0),
(57, ':grin:', 'laughing.png', 'laughing-grey.png', 0),
(58, ':laugh:', 'laughing.png', 'laughing-grey.png', 0),
(59, ':|', 'neutral.png', 'neutral-grey.png', 0),
(60, ':-|', 'neutral.png', 'neutral-grey.png', 0),
(61, ':neutral:', 'neutral.png', 'neutral-grey.png', 0),
(62, ':mrgreen:', 'mrgreen.png', 'mrgreen-grey.png', 0),
(63, ':?:', 'question.png', 'question-grey.png', 0),
(64, ':!:', 'exclamation.png', 'exclamation-grey.png', 0),
(65, ':arrow:', 'arrow.png', 'arrow-grey.png', 0),
(66, ':idea:', 'idea.png', 'idea-grey.png', 0);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_thankyou`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_thankyou` (
  `postid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `targetuserid` int(11) NOT NULL,
  `time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_topics`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_topics` (
`id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `subject` tinytext,
  `icon_id` int(11) NOT NULL DEFAULT '0',
  `locked` tinyint(4) NOT NULL DEFAULT '0',
  `hold` tinyint(4) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `posts` int(11) NOT NULL DEFAULT '0',
  `hits` int(11) NOT NULL DEFAULT '0',
  `attachments` int(11) NOT NULL DEFAULT '0',
  `poll_id` int(11) NOT NULL DEFAULT '0',
  `moved_id` int(11) NOT NULL DEFAULT '0',
  `first_post_id` int(11) NOT NULL DEFAULT '0',
  `first_post_time` int(11) NOT NULL DEFAULT '0',
  `first_post_userid` int(11) NOT NULL DEFAULT '0',
  `first_post_message` text,
  `first_post_guest_name` tinytext,
  `last_post_id` int(11) NOT NULL DEFAULT '0',
  `last_post_time` int(11) NOT NULL DEFAULT '0',
  `last_post_userid` int(11) NOT NULL DEFAULT '0',
  `last_post_message` text,
  `last_post_guest_name` tinytext,
  `params` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `zjw8d_kunena_topics`
--

INSERT INTO `zjw8d_kunena_topics` (`id`, `category_id`, `subject`, `icon_id`, `locked`, `hold`, `ordering`, `posts`, `hits`, `attachments`, `poll_id`, `moved_id`, `first_post_id`, `first_post_time`, `first_post_userid`, `first_post_message`, `first_post_guest_name`, `last_post_id`, `last_post_time`, `last_post_userid`, `last_post_message`, `last_post_guest_name`, `params`) VALUES
(1, 2, 'Welcome to Kunena!', 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1413343175, 585, '[size=4][b]Welcome to Kunena![/b][/size] \n\n Thank you for choosing Kunena for your community forum needs in Joomla. \n\n Kunena, translated from Swahili meaning “to speak”, is built by a team of open source professionals with the goal of providing a top quality, tightly unified forum solution for Joomla. \n\n\n [size=4][b]Additional Kunena Resources[/b][/size] \n\n [b]Kunena Documentation:[/b] [url]http://www.kunena.org/docs[/url] \n\n [b]Kunena Support Forum[/b]: [url]http://www.kunena.org/forum[/url] \n\n [b]Kunena Downloads:[/b] [url]http://www.kunena.org/download[/url] \n\n [b]Kunena Blog:[/b] [url]http://www.kunena.org/blog[/url] \n\n [b]Follow Kunena on Twitter:[/b] [url]http://www.kunena.org/twitter[/url]', 'Kunena', 1, 1413343175, 585, '[size=4][b]Welcome to Kunena![/b][/size] \n\n Thank you for choosing Kunena for your community forum needs in Joomla. \n\n Kunena, translated from Swahili meaning “to speak”, is built by a team of open source professionals with the goal of providing a top quality, tightly unified forum solution for Joomla. \n\n\n [size=4][b]Additional Kunena Resources[/b][/size] \n\n [b]Kunena Documentation:[/b] [url]http://www.kunena.org/docs[/url] \n\n [b]Kunena Support Forum[/b]: [url]http://www.kunena.org/forum[/url] \n\n [b]Kunena Downloads:[/b] [url]http://www.kunena.org/download[/url] \n\n [b]Kunena Blog:[/b] [url]http://www.kunena.org/blog[/url] \n\n [b]Follow Kunena on Twitter:[/b] [url]http://www.kunena.org/twitter[/url]', 'Kunena', '');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_users`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_users` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `view` varchar(8) NOT NULL DEFAULT '',
  `signature` text,
  `moderator` int(11) DEFAULT '0',
  `banned` datetime DEFAULT NULL,
  `ordering` int(11) DEFAULT '0',
  `posts` int(11) DEFAULT '0',
  `avatar` varchar(255) DEFAULT NULL,
  `karma` int(11) DEFAULT '0',
  `karma_time` int(11) DEFAULT '0',
  `group_id` int(4) DEFAULT '1',
  `uhits` int(11) DEFAULT '0',
  `personalText` tinytext,
  `gender` tinyint(4) NOT NULL DEFAULT '0',
  `birthdate` date NOT NULL DEFAULT '0001-01-01',
  `location` varchar(50) DEFAULT NULL,
  `icq` varchar(50) DEFAULT NULL,
  `aim` varchar(50) DEFAULT NULL,
  `yim` varchar(50) DEFAULT NULL,
  `msn` varchar(50) DEFAULT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `twitter` varchar(50) DEFAULT NULL,
  `facebook` varchar(50) DEFAULT NULL,
  `gtalk` varchar(50) DEFAULT NULL,
  `myspace` varchar(50) DEFAULT NULL,
  `linkedin` varchar(50) DEFAULT NULL,
  `delicious` varchar(50) DEFAULT NULL,
  `friendfeed` varchar(50) DEFAULT NULL,
  `digg` varchar(50) DEFAULT NULL,
  `blogspot` varchar(50) DEFAULT NULL,
  `flickr` varchar(50) DEFAULT NULL,
  `bebo` varchar(50) DEFAULT NULL,
  `websitename` varchar(50) DEFAULT NULL,
  `websiteurl` varchar(50) DEFAULT NULL,
  `rank` tinyint(4) NOT NULL DEFAULT '0',
  `hideEmail` tinyint(1) NOT NULL DEFAULT '1',
  `showOnline` tinyint(1) NOT NULL DEFAULT '1',
  `thankyou` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_kunena_users`
--

INSERT INTO `zjw8d_kunena_users` (`userid`, `view`, `signature`, `moderator`, `banned`, `ordering`, `posts`, `avatar`, `karma`, `karma_time`, `group_id`, `uhits`, `personalText`, `gender`, `birthdate`, `location`, `icq`, `aim`, `yim`, `msn`, `skype`, `twitter`, `facebook`, `gtalk`, `myspace`, `linkedin`, `delicious`, `friendfeed`, `digg`, `blogspot`, `flickr`, `bebo`, `websitename`, `websiteurl`, `rank`, `hideEmail`, `showOnline`, `thankyou`) VALUES
(584, '', NULL, 0, NULL, 0, 0, NULL, 0, 0, 1, 0, NULL, 0, '0001-01-01', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0),
(585, '', NULL, 0, NULL, 0, 1, NULL, 0, 0, 1, 0, NULL, 0, '0001-01-01', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_users_banned`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_users_banned` (
`id` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `ip` varchar(128) DEFAULT NULL,
  `blocked` tinyint(4) NOT NULL DEFAULT '0',
  `expiration` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_time` datetime NOT NULL,
  `reason_private` text,
  `reason_public` text,
  `modified_by` int(11) DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  `comments` text,
  `params` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_user_categories`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_user_categories` (
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `role` tinyint(4) NOT NULL DEFAULT '0',
  `allreadtime` datetime DEFAULT NULL,
  `subscribed` tinyint(4) NOT NULL DEFAULT '0',
  `params` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_user_read`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_user_read` (
  `user_id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `message_id` int(11) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_user_topics`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_user_topics` (
  `user_id` int(11) NOT NULL DEFAULT '0',
  `topic_id` int(11) NOT NULL DEFAULT '0',
  `category_id` int(11) NOT NULL,
  `posts` mediumint(8) NOT NULL DEFAULT '0',
  `last_post_id` int(11) NOT NULL DEFAULT '0',
  `owner` tinyint(4) NOT NULL DEFAULT '0',
  `favorite` tinyint(4) NOT NULL DEFAULT '0',
  `subscribed` tinyint(4) NOT NULL DEFAULT '0',
  `params` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_kunena_user_topics`
--

INSERT INTO `zjw8d_kunena_user_topics` (`user_id`, `topic_id`, `category_id`, `posts`, `last_post_id`, `owner`, `favorite`, `subscribed`, `params`) VALUES
(585, 1, 2, 1, 1, 1, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_kunena_version`
--

CREATE TABLE IF NOT EXISTS `zjw8d_kunena_version` (
`id` int(11) NOT NULL,
  `version` varchar(20) NOT NULL,
  `versiondate` date NOT NULL,
  `installdate` date NOT NULL,
  `build` varchar(20) NOT NULL,
  `versionname` varchar(40) DEFAULT NULL,
  `state` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `zjw8d_kunena_version`
--

INSERT INTO `zjw8d_kunena_version` (`id`, `version`, `versiondate`, `installdate`, `build`, `versionname`, `state`) VALUES
(1, '3.0.6', '2014-07-28', '2014-10-15', '', 'Tala', '');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_languages`
--

CREATE TABLE IF NOT EXISTS `zjw8d_languages` (
`lang_id` int(11) unsigned NOT NULL,
  `lang_code` char(7) NOT NULL,
  `title` varchar(50) NOT NULL,
  `title_native` varchar(50) NOT NULL,
  `sef` varchar(50) NOT NULL,
  `image` varchar(50) NOT NULL,
  `description` varchar(512) NOT NULL,
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `sitename` varchar(1024) NOT NULL DEFAULT '',
  `published` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `zjw8d_languages`
--

INSERT INTO `zjw8d_languages` (`lang_id`, `lang_code`, `title`, `title_native`, `sef`, `image`, `description`, `metakey`, `metadesc`, `sitename`, `published`, `access`, `ordering`) VALUES
(1, 'en-GB', 'English (UK)', 'English (UK)', 'en', 'en', '', '', '', '', 1, 1, 1),
(2, 'vi-VN', 'Vietamese', 'Vietamese', 'vi_VN', 'vi_vn', '', '', '', '', 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_menu`
--

CREATE TABLE IF NOT EXISTS `zjw8d_menu` (
`id` int(11) NOT NULL,
  `menutype` varchar(24) NOT NULL COMMENT 'The type of menu this item belongs to. FK to #__menu_types.menutype',
  `title` varchar(255) NOT NULL COMMENT 'The display title of the menu item.',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL COMMENT 'The SEF alias of the menu item.',
  `note` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(1024) NOT NULL COMMENT 'The computed path of the menu item based on the alias field.',
  `link` varchar(1024) NOT NULL COMMENT 'The actually link the menu item refers to.',
  `type` varchar(16) NOT NULL COMMENT 'The type of link: Component, URL, Alias, Separator',
  `published` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The published state of the menu link.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'The parent menu item in the menu tree.',
  `level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The relative level in the tree.',
  `component_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__extensions.id',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__users.id',
  `checked_out_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'The time the menu item was checked out.',
  `browserNav` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The click behaviour of the link.',
  `access` int(10) unsigned DEFAULT NULL,
  `img` varchar(255) NOT NULL COMMENT 'The image of the menu item.',
  `template_style_id` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL COMMENT 'JSON encoded data for the menu item.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `home` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Indicates if this menu item is the home or default page.',
  `language` char(7) NOT NULL DEFAULT '',
  `client_id` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=269 ;

--
-- Dumping data for table `zjw8d_menu`
--

INSERT INTO `zjw8d_menu` (`id`, `menutype`, `title`, `alias`, `note`, `path`, `link`, `type`, `published`, `parent_id`, `level`, `component_id`, `checked_out`, `checked_out_time`, `browserNav`, `access`, `img`, `template_style_id`, `params`, `lft`, `rgt`, `home`, `language`, `client_id`) VALUES
(1, '', 'Menu_Item_Root', 'root', '', '', '', '', 1, 0, 0, 0, 0, '0000-00-00 00:00:00', 0, 0, '', 0, '', 0, 307, 0, '*', 0),
(2, 'menu', 'com_banners', 'Banners', '', 'Banners', 'index.php?option=com_banners', 'component', 0, 1, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners', 0, '', 139, 148, 0, '*', 1),
(3, 'menu', 'com_banners', 'Banners', '', 'Banners/Banners', 'index.php?option=com_banners', 'component', 0, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners', 0, '', 140, 141, 0, '*', 1),
(4, 'menu', 'com_banners_categories', 'Categories', '', 'Banners/Categories', 'index.php?option=com_categories&extension=com_banners', 'component', 0, 2, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-cat', 0, '', 142, 143, 0, '*', 1),
(5, 'menu', 'com_banners_clients', 'Clients', '', 'Banners/Clients', 'index.php?option=com_banners&view=clients', 'component', 0, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-clients', 0, '', 144, 145, 0, '*', 1),
(6, 'menu', 'com_banners_tracks', 'Tracks', '', 'Banners/Tracks', 'index.php?option=com_banners&view=tracks', 'component', 0, 2, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 'class:banners-tracks', 0, '', 146, 147, 0, '*', 1),
(7, 'menu', 'com_contact', 'Contacts', '', 'Contacts', 'index.php?option=com_contact', 'component', 0, 1, 1, 8, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact', 0, '', 203, 208, 0, '*', 1),
(8, 'menu', 'com_contact', 'Contacts', '', 'Contacts/Contacts', 'index.php?option=com_contact', 'component', 0, 7, 2, 8, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact', 0, '', 204, 205, 0, '*', 1),
(9, 'menu', 'com_contact_categories', 'Categories', '', 'Contacts/Categories', 'index.php?option=com_categories&extension=com_contact', 'component', 0, 7, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:contact-cat', 0, '', 206, 207, 0, '*', 1),
(10, 'menu', 'com_messages', 'Messaging', '', 'Messaging', 'index.php?option=com_messages', 'component', 0, 1, 1, 15, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages', 0, '', 209, 214, 0, '*', 1),
(11, 'menu', 'com_messages_add', 'New Private Message', '', 'Messaging/New Private Message', 'index.php?option=com_messages&task=message.add', 'component', 0, 10, 2, 15, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages-add', 0, '', 210, 211, 0, '*', 1),
(12, 'menu', 'com_messages_read', 'Read Private Message', '', 'Messaging/Read Private Message', 'index.php?option=com_messages', 'component', 0, 10, 2, 15, 0, '0000-00-00 00:00:00', 0, 0, 'class:messages-read', 0, '', 212, 213, 0, '*', 1),
(13, 'menu', 'com_newsfeeds', 'News Feeds', '', 'News Feeds', 'index.php?option=com_newsfeeds', 'component', 0, 1, 1, 17, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds', 0, '', 215, 220, 0, '*', 1),
(14, 'menu', 'com_newsfeeds_feeds', 'Feeds', '', 'News Feeds/Feeds', 'index.php?option=com_newsfeeds', 'component', 0, 13, 2, 17, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds', 0, '', 216, 217, 0, '*', 1),
(15, 'menu', 'com_newsfeeds_categories', 'Categories', '', 'News Feeds/Categories', 'index.php?option=com_categories&extension=com_newsfeeds', 'component', 0, 13, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:newsfeeds-cat', 0, '', 218, 219, 0, '*', 1),
(16, 'menu', 'com_redirect', 'Redirect', '', 'Redirect', 'index.php?option=com_redirect', 'component', 0, 1, 1, 24, 0, '0000-00-00 00:00:00', 0, 0, 'class:redirect', 0, '', 229, 230, 0, '*', 1),
(17, 'menu', 'com_search', 'Search', '', 'Search', 'index.php?option=com_search', 'component', 0, 1, 1, 19, 0, '0000-00-00 00:00:00', 0, 0, 'class:search', 0, '', 221, 222, 0, '*', 1),
(18, 'menu', 'com_weblinks', 'Weblinks', '', 'Weblinks', 'index.php?option=com_weblinks', 'component', 0, 1, 1, 21, 0, '0000-00-00 00:00:00', 0, 0, 'class:weblinks', 0, '', 223, 228, 0, '*', 1),
(19, 'menu', 'com_weblinks_links', 'Links', '', 'Weblinks/Links', 'index.php?option=com_weblinks', 'component', 0, 18, 2, 21, 0, '0000-00-00 00:00:00', 0, 0, 'class:weblinks', 0, '', 224, 225, 0, '*', 1),
(20, 'menu', 'com_weblinks_categories', 'Categories', '', 'Weblinks/Categories', 'index.php?option=com_categories&extension=com_weblinks', 'component', 0, 18, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 'class:weblinks-cat', 0, '', 226, 227, 0, '*', 1),
(21, 'menu', 'com_finder', 'Smart Search', '', 'Smart Search', 'index.php?option=com_finder', 'component', 0, 1, 1, 27, 0, '0000-00-00 00:00:00', 0, 0, 'class:finder', 0, '', 201, 202, 0, '*', 1),
(22, 'menu', 'com_joomlaupdate', 'Joomla! Update', '', 'Joomla! Update', 'index.php?option=com_joomlaupdate', 'component', 0, 1, 1, 28, 0, '0000-00-00 00:00:00', 0, 0, 'class:joomlaupdate', 0, '', 199, 200, 0, '*', 1),
(23, 'main', 'com_tags', 'Tags', '', 'Tags', 'index.php?option=com_tags', 'component', 0, 1, 1, 29, 0, '0000-00-00 00:00:00', 0, 1, 'class:tags', 0, '', 197, 198, 0, '', 1),
(101, 'mainmenu', 'Trang chủ || Home', 'home', '', 'home', 'index.php?option=com_content&view=article&id=7', 'component', 1, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","info_block_position":"","show_category":"0","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_tags":"","show_noauth":"","urls_position":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"Trang ch\\u1ee7","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 1, 14, 1, '*', 0),
(102, 'mainmenu', 'Giới thiệu || Introduction', 'gioi-thieu', '', 'gioi-thieu', 'index.php?option=com_zoo&view=item&layout=item', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"item_id":"1","application":"1","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 25, 32, 0, '*', 0),
(103, 'mainmenu', 'Module Variations', 'module-variations', '', 'gioi-thieu/module-variations', 'index.php?option=com_content&view=article&id=1', 'component', 0, 102, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"0","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 26, 27, 0, '*', 0),
(104, 'mainmenu', 'Typography', 'typography', '', 'gioi-thieu/typography', 'index.php?option=com_content&view=article&id=4', 'component', 0, 102, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"0","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 28, 29, 0, '*', 0),
(105, 'mainmenu', 'Sách truyện || Works', 'sach-truyen-works', '', 'sach-truyen-works', 'index.php?option=com_zoo&view=frontpage&layout=frontpage', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":-1}', 35, 36, 0, '*', 0),
(106, 'mainmenu', 'Tác giả || Authors', 'tac-gia-authors', '', 'tac-gia-authors', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"61","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 33, 34, 0, '*', 0),
(107, 'mainmenu', 'Joomla || Subtitle Possible', 'joomla', '', 'joomla', 'index.php?option=com_content&view=category&layout=blog&id=7', 'component', 0, 1, 1, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"layout_type":"blog","show_category_title":"","show_description":"","show_description_image":"","maxLevel":"","show_empty_categories":"","show_no_articles":"","show_subcat_desc":"","show_cat_num_articles":"","page_subheading":"","num_leading_articles":"1","num_intro_articles":"4","num_columns":"1","num_links":"0","multi_column_order":"","show_subcategory_content":"","orderby_pri":"","orderby_sec":"order","order_date":"","show_pagination":"","show_pagination_results":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_readmore":"","show_readmore_title":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"images\\/yootheme\\/menu\\/icon_joomla.png","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 169, 196, 0, '*', 0),
(108, 'bottommenu', 'Features', '2011-05-02-12-32-40', '', '2011-05-02-12-32-40', 'index.php?option=com_content&view=article&id=6&Itemid=102', 'url', 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1}', 231, 232, 0, '*', 0),
(109, 'bottommenu', 'Typography', '2011-05-02-12-33-12', '', '2011-05-02-12-33-12', 'index.php?option=com_content&view=article&id=4&Itemid=104', 'url', 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1}', 233, 234, 0, '*', 0),
(110, 'bottommenu', 'News', '2011-05-02-12-33-35', '', '2011-05-02-12-33-35', 'index.php?option=com_content&view=category&layout=blog&id=7&Itemid=107', 'url', 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1}', 235, 236, 0, '*', 0),
(111, 'booksmenu', 'Sách Tuổi hoa', 'hoc-tro-thieu-nhi', '', 'hoc-tro-thieu-nhi', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"5","application":"3","menu-anchor_title":"Kho s\\u00e1ch tu\\u1ed5i hoa","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 39, 44, 0, '*', 0),
(112, 'booksmenu', 'Tuổi học trò', 'tuoi-hoc-tro', '', 'hoc-tro-thieu-nhi/tuoi-hoc-tro', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 111, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"6","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 40, 41, 0, '*', 0),
(113, 'booksmenu', 'Thiếu nhi', 'thieu-nhi', '', 'hoc-tro-thieu-nhi/thieu-nhi', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 111, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"7","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 42, 43, 0, '*', 0),
(114, 'booksmenu', 'Sách Thi ca & Ngụ ngôn', 'sach-thi-ca-ngu-ngon', '', 'sach-thi-ca-ngu-ngon', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"4","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 45, 50, 0, '*', 0),
(115, 'booksmenu', 'Sách Kinh tế & Pháp luật', 'sach-kinh-te-phap-luat', '', 'sach-kinh-te-phap-luat', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"25","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 87, 96, 0, '*', 0),
(116, 'booksmenu', 'Sách Văn hóa & Xã hội', 'sach-van-hoa-xa-hoi', '', 'sach-van-hoa-xa-hoi', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"18","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 63, 68, 0, '*', 0),
(117, 'booksmenu', 'Sách Văn học', 'sach-van-hoc', '', 'sach-van-hoc', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"36","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 15, 22, 0, '*', 0),
(118, 'booksmenu', 'Văn học Việt Nam', 'van-hoc-viet-nam', '', 'sach-van-hoc/van-hoc-viet-nam', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 117, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"1","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 20, 21, 0, '*', 0),
(119, 'booksmenu', 'Văn học nước ngoài', 'van-hoc-nuoc-ngoai', '', 'sach-van-hoc/van-hoc-nuoc-ngoai', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 117, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"2","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 18, 19, 0, '*', 0),
(120, 'booksmenu', 'Văn học cổ điển', 'van-hoc-co-dien', '', 'sach-van-hoc/van-hoc-co-dien', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 117, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"3","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 16, 17, 0, '*', 0),
(121, 'booksmenu', 'Sách Lịch sử & Địa lý', 'sach-lich-su-dia-ly', '', 'sach-lich-su-dia-ly', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"19","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 75, 86, 0, '*', 0),
(122, 'booksmenu', 'Lịch sử Việt Nam', 'lich-su-viet-nam', '', 'sach-lich-su-dia-ly/lich-su-viet-nam', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 121, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"43","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 80, 81, 0, '*', 0),
(123, 'booksmenu', 'Địa lý', 'dia-ly', '', 'sach-lich-su-dia-ly/dia-ly', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 121, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"21","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 84, 85, 0, '*', 0),
(124, 'mainmenu', 'Content||All com_content views', 'contentall-comcontent-views', '', 'joomla/contentall-comcontent-views', '', 'separator', 0, 107, 2, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_image":"","menu_text":1}', 170, 177, 0, '*', 0),
(125, 'mainmenu', 'Other Components||Remaining component views', 'other-componentsremaining-component-views', '', 'joomla/other-componentsremaining-component-views', '', 'separator', 0, 107, 2, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_image":"","menu_text":1}', 184, 195, 0, '*', 0),
(126, 'mainmenu', 'Category List', 'category-list', '', 'joomla/contentall-comcontent-views/category-list', 'index.php?option=com_content&view=category&id=7', 'component', 0, 124, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_category_title":"","show_description":"","show_description_image":"","maxLevel":"","show_empty_categories":"","show_no_articles":"","show_subcat_desc":"","show_cat_num_articles":"","page_subheading":"","show_pagination_limit":"","filter_field":"","show_headings":"","list_show_date":"","date_format":"","list_show_hits":"","list_show_author":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"","show_pagination_results":"","display_num":"10","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_readmore":"","show_readmore_title":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":1,"page_heading":"Blog","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 175, 176, 0, '*', 0),
(127, 'mainmenu', 'List All Categories', 'list-all-categories', '', 'joomla/contentall-comcontent-views/list-all-categories', 'index.php?option=com_content&view=categories&id=0', 'component', 0, 124, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_base_description":"","categories_description":"","maxLevelcat":"","show_empty_categories_cat":"","show_subcat_desc_cat":"","show_cat_num_articles_cat":"","show_category_title":"","show_description":"","show_description_image":"","maxLevel":"","show_empty_categories":"","show_no_articles":"","show_subcat_desc":"","show_cat_num_articles":"","num_leading_articles":"1","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"","show_subcategory_content":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"","show_pagination_results":"","show_pagination_limit":"","filter_field":"","show_headings":"","list_show_date":"","date_format":"","list_show_hits":"","list_show_author":"","display_num":"10","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_readmore":"","show_readmore_title":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":1,"page_heading":"Blog","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 173, 174, 0, '*', 0),
(128, 'mainmenu', 'Featured Articles', 'featured-articles', '', 'joomla/contentall-comcontent-views/featured-articles', 'index.php?option=com_content&view=featured', 'component', 0, 124, 3, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"layout_type":"blog","num_leading_articles":"1","num_intro_articles":"4","num_columns":"2","num_links":"4","multi_column_order":"","orderby_pri":"","orderby_sec":"","order_date":"","show_pagination":"","show_pagination_results":"","show_title":"","link_titles":"","show_intro":"","show_category":"","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"","link_author":"","show_create_date":"","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_readmore":"","show_readmore_title":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","show_feed_link":"","feed_summary":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 171, 172, 0, '*', 0),
(129, 'mainmenu', 'Login', 'login', '', 'joomla/other-componentsremaining-component-views/login', 'index.php?option=com_users&view=login', 'component', 0, 125, 3, 25, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"login_redirect_url":"","logindescription_show":"1","login_description":"","login_image":"","logout_redirect_url":"","logoutdescription_show":"1","logout_description":"","logout_image":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":1,"page_heading":"Login","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 187, 188, 0, '*', 0),
(130, 'mainmenu', 'Registration', 'registration', '', 'joomla/other-componentsremaining-component-views/registration', 'index.php?option=com_users&view=registration', 'component', 0, 125, 3, 25, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":1,"page_heading":"Registration","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 189, 190, 0, '*', 0),
(132, 'mainmenu', 'Diễn đàn || Forum', 'forum', '', 'forum', 'index.php?option=com_kunena&view=home&defaultmenu=260', 'component', 0, 1, 1, 10077, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"catids":["0"],"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 149, 168, 0, '*', 0),
(133, 'mainmenu', 'Slideshow', 'slideshow', '', 'forum/slideshow', 'index.php?option=com_content&view=article&id=14', 'component', 0, 132, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"0","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 150, 151, 0, '*', 0),
(134, 'mainmenu', 'Lightbox', 'lightbox', '', 'forum/lightbox', 'index.php?option=com_content&view=article&id=15', 'component', 0, 132, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"0","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 160, 161, 0, '*', 0),
(135, 'mainmenu', 'Spotlight', 'spotlight', '', 'forum/spotlight', 'index.php?option=com_content&view=article&id=16', 'component', 0, 132, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"0","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 162, 163, 0, '*', 0),
(136, 'mainmenu', 'Twitter', 'twitter', '', 'forum/twitter', 'index.php?option=com_content&view=article&id=17', 'component', 0, 132, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"0","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 164, 165, 0, '*', 0),
(140, 'mainmenu', 'Media Player', 'media-player', '', 'forum/media-player', 'index.php?option=com_content&view=article&id=18', 'component', 0, 132, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"0","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 166, 167, 0, '*', 0),
(141, 'mainmenu', 'Gallery', 'gallery', '', 'forum/gallery', 'index.php?option=com_content&view=article&id=19', 'component', 0, 132, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"0","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 154, 155, 0, '*', 0),
(142, 'mainmenu', 'Accordion', 'accordion', '', 'forum/accordion', 'index.php?option=com_content&view=article&id=21', 'component', 0, 132, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"0","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 158, 159, 0, '*', 0),
(143, 'mainmenu', 'Map', 'map', '', 'forum/map', 'index.php?option=com_content&view=article&id=20', 'component', 0, 132, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"0","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 156, 157, 0, '*', 0),
(144, 'mainmenu', 'Slideset', 'slideset', '', 'forum/slideset', 'index.php?option=com_content&view=article&id=22', 'component', 0, 132, 2, 22, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_title":"","link_titles":"","show_intro":"","show_category":"0","link_category":"","show_parent_category":"","link_parent_category":"","show_author":"0","link_author":"","show_create_date":"0","show_modify_date":"","show_publish_date":"","show_item_navigation":"","show_vote":"","show_icons":"","show_print_icon":"","show_email_icon":"","show_hits":"","show_noauth":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 152, 153, 0, '*', 0),
(150, 'mainmenu', 'Contact || All com_contact views', 'contact--all-comcontact-views', '', 'joomla/contact--all-comcontact-views', '', 'separator', 0, 107, 2, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu_image":"","menu_text":1}', 178, 183, 0, '*', 0),
(151, 'mainmenu', 'Contact Category', 'contact-category', '', 'joomla/contact--all-comcontact-views/contact-category', 'index.php?option=com_contact&view=category&id=8', 'component', 0, 150, 3, 8, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_category_title":"","show_description":"","show_description_image":"","maxLevel":"","show_empty_categories":"","show_subcat_desc":"","show_cat_items":"","show_pagination_limit":"","show_headings":"","show_position_headings":"","show_email_headings":"","show_telephone_headings":"","show_mobile_headings":"","show_fax_headings":"","show_suburb_headings":"","show_state_headings":"","show_country_headings":"","show_pagination":"","show_pagination_results":"","initial_sort":"","presentation_style":"","show_contact_category":"","show_contact_list":"","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_links":"","linka_name":"","linkb_name":"","linkc_name":"","linkd_name":"","linke_name":"","show_email_form":"","show_email_copy":"","banned_email":"","banned_subject":"","banned_text":"","validate_session":"","custom_reply":"","redirect":"","show_feed_link":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 179, 180, 0, '*', 0),
(152, 'mainmenu', 'Contact Item', 'contact-item', '', 'joomla/contact--all-comcontact-views/contact-item', 'index.php?option=com_contact&view=contact&id=1', 'component', 0, 150, 3, 8, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"presentation_style":"","show_contact_category":"","show_contact_list":"","show_name":"","show_position":"","show_email":"","show_street_address":"","show_suburb":"","show_state":"","show_postcode":"","show_country":"","show_telephone":"","show_mobile":"","show_fax":"","show_webpage":"","show_misc":"","show_image":"","allow_vcard":"","show_articles":"","show_links":"","linka_name":"","linkb_name":"","linkc_name":"","linkd_name":"","linke_name":"","show_email_form":"","show_email_copy":"","banned_email":"","banned_subject":"","banned_text":"","validate_session":"","custom_reply":"","redirect":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 181, 182, 0, '*', 0),
(153, 'mainmenu', 'Remind', 'remind', '', 'joomla/other-componentsremaining-component-views/remind', 'index.php?option=com_users&view=remind', 'component', 0, 125, 3, 25, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":1,"page_heading":"Forgot your Username?","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 191, 192, 0, '*', 0),
(154, 'mainmenu', 'Reset', 'reset', '', 'joomla/other-componentsremaining-component-views/reset', 'index.php?option=com_users&view=reset', 'component', 0, 125, 3, 25, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":1,"page_heading":"Forgot your Password?","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 193, 194, 0, '*', 0),
(155, 'mainmenu', 'Web Links', 'web-links', '', 'joomla/other-componentsremaining-component-views/web-links', 'index.php?option=com_weblinks&view=categories&id=0', 'component', 0, 125, 3, 21, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"show_base_description":"1","categories_description":"We are regularly out on the Web. When we find a great site we list it.","maxLevelcat":"-1","show_empty_categories_cat":"","show_subcat_desc_cat":"","show_cat_num_links_cat":"","show_category_title":"","show_description":"","show_description_image":"","maxLevel":"","show_empty_categories":"","show_subcat_desc":"","show_cat_num_links":"","show_pagination_limit":"","show_headings":"","show_link_description":"","show_link_hits":"","show_pagination":"","show_pagination_results":"","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":1,"page_heading":"Web Links","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 185, 186, 0, '*', 0),
(171, 'mainmenu', 'Liên hệ || Contact', 'lien-he', '', 'gioi-thieu/lien-he', 'index.php?option=com_zoo&view=item&layout=item', 'component', 1, 102, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"item_id":"5","application":"2","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 30, 31, 0, '*', 0),
(172, 'mainmenu', 'Beige Paper', '2012-06-28-08-20-17', '', 'home/2012-06-28-08-20-17', 'index.php?option=com_content&view=article&id=7&Itemid=101&profile=beigepaper', 'url', 0, 101, 2, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"images\\/yootheme\\/menu\\/icon_profile_beigepaper.png","menu_text":1}', 10, 11, 0, '*', 0),
(173, 'mainmenu', 'Văn hóa đọc || Reading culture', 'van-hoa-doc-reading-culture', '', 'van-hoa-doc-reading-culture', 'index.php?option=com_zoo&view=frontpage&layout=frontpage', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"application":"4","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 37, 38, 0, '*', 0),
(174, 'mainmenu', 'White Gradient', '2012-06-28-08-40-37', '', 'home/2012-06-28-08-40-37', 'index.php?option=com_content&view=article&id=7&Itemid=101&profile=whitegradient', 'url', 0, 101, 2, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"images\\/yootheme\\/menu\\/icon_profile_gradient.png","menu_text":1}', 4, 5, 0, '*', 0),
(175, 'mainmenu', 'Red Fabric', '2012-06-28-08-41-18', '', 'home/2012-06-28-08-41-18', 'index.php?option=com_content&view=article&id=7&Itemid=101&profile=redfabric', 'url', 0, 101, 2, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"images\\/yootheme\\/menu\\/icon_profile_redfabric.png","menu_text":1}', 8, 9, 0, '*', 0),
(176, 'mainmenu', 'Colorwave', '2012-06-28-08-42-18', '', 'home/2012-06-28-08-42-18', 'index.php?option=com_content&view=article&id=7&Itemid=101&profile=colorwave', 'url', 0, 101, 2, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"images\\/yootheme\\/menu\\/icon_profile_colorwave.png","menu_text":1}', 6, 7, 0, '*', 0),
(177, 'mainmenu', 'Blue', '2012-06-28-08-42-57', '', 'home/2012-06-28-08-42-57', 'index.php?option=com_content&view=article&id=7&Itemid=101&profile=blue', 'url', 0, 101, 2, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"images\\/yootheme\\/menu\\/icon_profile_blue.png","menu_text":1}', 12, 13, 0, '*', 0),
(178, 'mainmenu', 'Black Paper', '2012-06-28-08-44-00', '', 'home/2012-06-28-08-44-00', 'index.php?option=com_content&view=article&id=7&Itemid=101&profile=blackpaper', 'url', 0, 101, 2, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"images\\/yootheme\\/menu\\/icocn_profile_blackpaper.png","menu_text":1}', 2, 3, 0, '*', 0),
(185, 'main', 'COM_SH404SEF', 'com-sh404sef', '', 'com-sh404sef', 'index.php?option=com_sh404sef', 'component', 0, 1, 1, 10031, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_sh404sef/assets/images/menu-icon-sh404sef.png', 0, '', 237, 254, 0, '', 1),
(186, 'main', 'COM_SH404SEF_CONTROL_PANEL', 'com-sh404sef-control-panel', '', 'com-sh404sef/com-sh404sef-control-panel', 'index.php?option=com_sh404sef&c=default', 'component', 0, 185, 2, 10031, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 238, 239, 0, '', 1),
(187, 'main', 'COM_SH404SEF_URL_MANAGER', 'com-sh404sef-url-manager', '', 'com-sh404sef/com-sh404sef-url-manager', 'index.php?option=com_sh404sef&c=urls&layout=default&view=urls', 'component', 0, 185, 2, 10031, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 240, 241, 0, '', 1),
(188, 'main', 'COM_SH404SEF_ALIASES_MANAGER', 'com-sh404sef-aliases-manager', '', 'com-sh404sef/com-sh404sef-aliases-manager', 'index.php?option=com_sh404sef&c=aliases&layout=default&view=aliases', 'component', 0, 185, 2, 10031, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 242, 243, 0, '', 1),
(189, 'main', 'COM_SH404SEF_PAGEID_MANAGER', 'com-sh404sef-pageid-manager', '', 'com-sh404sef/com-sh404sef-pageid-manager', 'index.php?option=com_sh404sef&c=pageids&layout=default&view=pageids', 'component', 0, 185, 2, 10031, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 244, 245, 0, '', 1),
(190, 'main', 'COM_SH404SEF_404_REQ_MANAGER', 'com-sh404sef-404-req-manager', '', 'com-sh404sef/com-sh404sef-404-req-manager', 'index.php?option=com_sh404sef&c=urls&layout=view404&view=urls', 'component', 0, 185, 2, 10031, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 246, 247, 0, '', 1),
(191, 'main', 'COM_SH404SEF_TITLE_METAS_MANAGER', 'com-sh404sef-title-metas-manager', '', 'com-sh404sef/com-sh404sef-title-metas-manager', 'index.php?option=com_sh404sef&c=metas&layout=default&view=metas', 'component', 0, 185, 2, 10031, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 248, 249, 0, '', 1),
(192, 'main', 'COM_SH404SEF_ANALYTICS_MANAGER', 'com-sh404sef-analytics-manager', '', 'com-sh404sef/com-sh404sef-analytics-manager', 'index.php?option=com_sh404sef&c=analytics&layout=default&view=analytics', 'component', 0, 185, 2, 10031, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 250, 251, 0, '', 1),
(193, 'main', 'COM_SH404SEF_DOCUMENTATION', 'com-sh404sef-documentation', '', 'com-sh404sef/com-sh404sef-documentation', 'index.php?option=com_sh404sef&layout=info&view=default&task=info', 'component', 0, 185, 2, 10031, 0, '0000-00-00 00:00:00', 0, 1, 'class:component', 0, '', 252, 253, 0, '', 1),
(197, 'main', 'com_zoo', 'com-zoo', '', 'com-zoo', 'index.php?option=com_zoo', 'component', 0, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_zoo/assets/images/zoo_16.png', 0, '', 255, 256, 0, '', 1),
(198, 'booksmenu', 'Bài học Thành công', 'bai-hoc-thanh-cong', '', 'sach-kinh-te-phap-luat/bai-hoc-thanh-cong', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 115, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"45","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 88, 89, 0, '*', 0),
(199, 'booksmenu', 'Kiến thức Pháp luật', 'kien-thuc-phap-luat', '', 'sach-kinh-te-phap-luat/kien-thuc-phap-luat', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 115, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"27","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 94, 95, 0, '*', 0),
(200, 'booksmenu', 'Chưa phân loại', 'chua-phan-loai', '', 'chua-phan-loai', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"35","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 137, 138, 0, '*', 0),
(201, 'booksmenu', 'Dã sử', 'da-su', '', 'sach-lich-su-dia-ly/da-su', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 121, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"17","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 76, 77, 0, '*', 0),
(202, 'booksmenu', 'Sử thi', 'su-thi', '', 'sach-lich-su-dia-ly/su-thi', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 121, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"42","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 78, 79, 0, '*', 0),
(203, 'booksmenu', 'Lịch sử Thế giới', 'lich-su-the-gioi', '', 'sach-lich-su-dia-ly/lich-su-the-gioi', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 121, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"44","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 82, 83, 0, '*', 0),
(204, 'booksmenu', 'Chứng khoán Đầu tư', 'chung-khoan-dau-tu', '', 'sach-kinh-te-phap-luat/chung-khoan-dau-tu', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 115, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"20","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 90, 91, 0, '*', 0),
(205, 'booksmenu', 'Quản trị Kinh doanh', 'quan-tri-kinh-doanh', '', 'sach-kinh-te-phap-luat/quan-tri-kinh-doanh', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 115, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"26","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 92, 93, 0, '*', 0),
(206, 'booksmenu', 'Khoa học Thường thức', 'khoa-hoc-thuong-thuc', '', 'sach-van-hoa-xa-hoi/khoa-hoc-thuong-thuc', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 116, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"39","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 64, 65, 0, '*', 0),
(207, 'booksmenu', 'Nghệ thuật sống', 'nghe-thuat-song', '', 'sach-van-hoa-xa-hoi/nghe-thuat-song', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 116, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"31","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 66, 67, 0, '*', 0),
(208, 'booksmenu', 'Thi ca', 'thi-ca', '', 'sach-thi-ca-ngu-ngon/thi-ca', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 114, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"37","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 46, 47, 0, '*', 0),
(209, 'booksmenu', 'Ngụ ngôn', 'ngu-ngon', '', 'sach-thi-ca-ngu-ngon/ngu-ngon', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 114, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"38","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 48, 49, 0, '*', 0),
(210, 'booksmenu', 'Sách Khoa học & Kĩ thuật', 'sach-khoa-hoc-ki-thuat', '', 'sach-khoa-hoc-ki-thuat', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"22","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 97, 102, 0, '*', 0),
(211, 'booksmenu', 'Khoa học', 'khoa-hoc', '', 'sach-khoa-hoc-ki-thuat/khoa-hoc', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 210, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"23","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 98, 99, 0, '*', 0);
INSERT INTO `zjw8d_menu` (`id`, `menutype`, `title`, `alias`, `note`, `path`, `link`, `type`, `published`, `parent_id`, `level`, `component_id`, `checked_out`, `checked_out_time`, `browserNav`, `access`, `img`, `template_style_id`, `params`, `lft`, `rgt`, `home`, `language`, `client_id`) VALUES
(212, 'booksmenu', 'Kĩ thuật', 'ki-thuat', '', 'sach-khoa-hoc-ki-thuat/ki-thuat', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 210, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"24","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 100, 101, 0, '*', 0),
(213, 'booksmenu', 'Sách Tâm lý & Giới tính', 'sach-tam-ly-gioi-tinh', '', 'sach-tam-ly-gioi-tinh', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"28","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 69, 74, 0, '*', 0),
(214, 'booksmenu', 'Tâm lý', 'tam-ly', '', 'sach-tam-ly-gioi-tinh/tam-ly', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 213, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"29","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 70, 71, 0, '*', 0),
(215, 'booksmenu', 'Giới tính', 'gioi-tinh', '', 'sach-tam-ly-gioi-tinh/gioi-tinh', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 213, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"30","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 72, 73, 0, '*', 0),
(216, 'booksmenu', 'Sách Tiểu thuyết Tình cảm', 'sach-tieu-thuyet-tinh-cam', '', 'sach-tieu-thuyet-tinh-cam', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"9","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 51, 54, 0, '*', 0),
(217, 'booksmenu', 'Ngôn tình Trung Quốc', 'ngon-tinh-trung-quoc', '', 'sach-tieu-thuyet-tinh-cam/ngon-tinh-trung-quoc', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 216, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"8","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 52, 53, 0, '*', 0),
(218, 'booksmenu', 'Sách Truyện chưởng', 'sach-truyen-chuong', '', 'sach-truyen-chuong', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"13","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 55, 62, 0, '*', 0),
(219, 'booksmenu', 'Kiếm hiệp', 'kiem-hiep', '', 'sach-truyen-chuong/kiem-hiep', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 218, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"14","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 56, 57, 0, '*', 0),
(220, 'booksmenu', 'Tiên hiệp', 'tien-hiep', '', 'sach-truyen-chuong/tien-hiep', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 218, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"16","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 58, 59, 0, '*', 0),
(221, 'booksmenu', 'Sắc hiệp', 'sac-hiep', '', 'sach-truyen-chuong/sac-hiep', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 218, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"15","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 60, 61, 0, '*', 0),
(222, 'booksmenu', 'Sách Truyện ma & Kinh dị', 'sach-truyen-ma-kinh-di', '', 'sach-truyen-ma-kinh-di', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"11","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 127, 132, 0, '*', 0),
(223, 'booksmenu', 'Truyện ma', 'truyen-ma', '', 'sach-truyen-ma-kinh-di/truyen-ma', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 222, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"48","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 128, 129, 0, '*', 0),
(224, 'booksmenu', 'Kinh dị', 'kinh-di', '', 'sach-truyen-ma-kinh-di/kinh-di', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 222, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"49","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 130, 131, 0, '*', 0),
(225, 'booksmenu', 'Sách Viễn tưởng & Thần thoại', 'sach-vien-tuong-than-thoai', '', 'sach-vien-tuong-than-thoai', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"10","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 115, 120, 0, '*', 0),
(226, 'booksmenu', 'Viễn tưởng', 'vien-tuong', '', 'sach-vien-tuong-than-thoai/vien-tuong', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 225, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"46","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 116, 117, 0, '*', 0),
(227, 'booksmenu', 'Thần thoại', 'than-thoai', '', 'sach-vien-tuong-than-thoai/than-thoai', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 225, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"47","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 118, 119, 0, '*', 0),
(228, 'booksmenu', 'Sách Chuyên ngành', 'sach-chuyen-nganh', '', 'sach-chuyen-nganh', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"33","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 135, 136, 0, '*', 0),
(229, 'booksmenu', 'Sách Giáo trình', 'sach-giao-trinh', '', 'sach-giao-trinh', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"32","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 133, 134, 0, '*', 0),
(230, 'booksmenu', 'Sách Phiêu lưu & Mạo hiểm', 'sach-phieu-luu-mao-hiem', '', 'sach-phieu-luu-mao-hiem', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"50","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 109, 114, 0, '*', 0),
(231, 'booksmenu', 'Phiêu lưu', 'phieu-luu', '', 'sach-phieu-luu-mao-hiem/phieu-luu', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 230, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"51","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 110, 111, 0, '*', 0),
(232, 'booksmenu', 'Mạo hiểm', 'mao-hiem', '', 'sach-phieu-luu-mao-hiem/mao-hiem', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 230, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"52","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 112, 113, 0, '*', 0),
(233, 'booksmenu', 'Sách Hồi ký & Nhật ký', 'sach-hoi-ky-nhat-ky', '', 'sach-hoi-ky-nhat-ky', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"53","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 121, 126, 0, '*', 0),
(234, 'booksmenu', 'Hồi ký', 'hoi-ky', '', 'sach-hoi-ky-nhat-ky/hoi-ky', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 233, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"54","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 122, 123, 0, '*', 0),
(235, 'booksmenu', 'Nhật ký', 'nhat-ky', '', 'sach-hoi-ky-nhat-ky/nhat-ky', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 233, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"55","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 124, 125, 0, '*', 0),
(236, 'booksmenu', 'Sách Truyện cười & Dân gian', 'sach-truyen-cuoi-dan-gian', '', 'sach-truyen-cuoi-dan-gian', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 1, 1, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"56","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 103, 108, 0, '*', 0),
(237, 'booksmenu', 'Truyện cười Tiếu lâm', 'truyen-cuoi-tieu-lam', '', 'sach-truyen-cuoi-dan-gian/truyen-cuoi-tieu-lam', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 236, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"57","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 104, 105, 0, '*', 0),
(238, 'booksmenu', 'Dân gian', 'dan-gian', '', 'sach-truyen-cuoi-dan-gian/dan-gian', 'index.php?option=com_zoo&view=category&layout=category', 'component', 1, 236, 2, 10043, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"category":"58","application":"3","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 106, 107, 0, '*', 0),
(243, 'main', 'COM_CMC', 'com-cmc', '', 'com-cmc', 'index.php?option=com_cmc', 'component', 0, 1, 1, 10060, 0, '0000-00-00 00:00:00', 0, 1, '../media/com_cmc/backend/images/cmc-16px.png', 0, '', 257, 262, 0, '', 1),
(244, 'main', 'COM_CMC_LISTS', 'com-cmc-lists', '', 'com-cmc/com-cmc-lists', 'index.php?option=com_cmc&view=lists', 'component', 0, 243, 2, 10060, 0, '0000-00-00 00:00:00', 0, 1, '../media/com_cmc/backend/images/lists-16px.png', 0, '', 258, 259, 0, '', 1),
(245, 'main', 'COM_CMC_USERS', 'com-cmc-users', '', 'com-cmc/com-cmc-users', 'index.php?option=com_cmc&view=users', 'component', 0, 243, 2, 10060, 0, '0000-00-00 00:00:00', 0, 1, '../media/com_cmc/backend/images/users-16px.png', 0, '', 260, 261, 0, '', 1),
(246, 'main', 'COM_WIDGETKIT', 'com-widgetkit', '', 'com-widgetkit', 'index.php?option=com_widgetkit', 'component', 0, 1, 1, 10005, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_widgetkit/images/widgetkit_16.png', 0, '', 263, 264, 0, '', 1),
(247, 'main', 'COM_KUNENA', 'com-kunena', '', 'com-kunena', 'index.php?option=com_kunena', 'component', 0, 1, 1, 10077, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_kunena/media/icons/favicons/kunena-logo-white.png', 0, '', 265, 288, 0, '', 1),
(248, 'main', 'COM_KUNENA_DASHBOARD', 'com-kunena-dashboard', '', 'com-kunena/com-kunena-dashboard', 'index.php?option=com_kunena&view=cpanel', 'component', 0, 247, 2, 10077, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_kunena/media/icons/favicons/kunena-logo-white.png', 0, '', 266, 267, 0, '', 1),
(249, 'main', 'COM_KUNENA_CATEGORY_MANAGER', 'com-kunena-category-manager', '', 'com-kunena/com-kunena-category-manager', 'index.php?option=com_kunena&view=categories', 'component', 0, 247, 2, 10077, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_kunena/media/icons/favicons/kunena-categories.png', 0, '', 268, 269, 0, '', 1),
(250, 'main', 'COM_KUNENA_USER_MANAGER', 'com-kunena-user-manager', '', 'com-kunena/com-kunena-user-manager', 'index.php?option=com_kunena&view=users', 'component', 0, 247, 2, 10077, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_kunena/media/icons/favicons/kunena-users.png', 0, '', 270, 271, 0, '', 1),
(251, 'main', 'COM_KUNENA_FILE_MANAGER', 'com-kunena-file-manager', '', 'com-kunena/com-kunena-file-manager', 'index.php?option=com_kunena&view=attachments', 'component', 0, 247, 2, 10077, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_kunena/media/icons/favicons/kunena-files.png', 0, '', 272, 273, 0, '', 1),
(252, 'main', 'COM_KUNENA_EMOTICON_MANAGER', 'com-kunena-emoticon-manager', '', 'com-kunena/com-kunena-emoticon-manager', 'index.php?option=com_kunena&view=smilies', 'component', 0, 247, 2, 10077, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_kunena/media/icons/favicons/kunena-smileys.png', 0, '', 274, 275, 0, '', 1),
(253, 'main', 'COM_KUNENA_RANK_MANAGER', 'com-kunena-rank-manager', '', 'com-kunena/com-kunena-rank-manager', 'index.php?option=com_kunena&view=ranks', 'component', 0, 247, 2, 10077, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_kunena/media/icons/favicons/kunena-ranks.png', 0, '', 276, 277, 0, '', 1),
(254, 'main', 'COM_KUNENA_TEMPLATE_MANAGER', 'com-kunena-template-manager', '', 'com-kunena/com-kunena-template-manager', 'index.php?option=com_kunena&view=templates', 'component', 0, 247, 2, 10077, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_kunena/media/icons/favicons/kunena-templates.png', 0, '', 278, 279, 0, '', 1),
(255, 'main', 'COM_KUNENA_CONFIGURATION', 'com-kunena-configuration', '', 'com-kunena/com-kunena-configuration', 'index.php?option=com_kunena&view=config', 'component', 0, 247, 2, 10077, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_kunena/media/icons/favicons/kunena-prune.png', 0, '', 280, 281, 0, '', 1),
(256, 'main', 'COM_KUNENA_PLUGIN_MANAGER', 'com-kunena-plugin-manager', '', 'com-kunena/com-kunena-plugin-manager', 'index.php?option=com_kunena&view=plugins', 'component', 0, 247, 2, 10077, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_kunena/media/icons/favicons/kunena-plugins.png', 0, '', 282, 283, 0, '', 1),
(257, 'main', 'COM_KUNENA_FORUM_TOOLS', 'com-kunena-forum-tools', '', 'com-kunena/com-kunena-forum-tools', 'index.php?option=com_kunena&view=tools', 'component', 0, 247, 2, 10077, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_kunena/media/icons/favicons/kunena-config.png', 0, '', 284, 285, 0, '', 1),
(258, 'main', 'COM_KUNENA_TRASH_MANAGER', 'com-kunena-trash-manager', '', 'com-kunena/com-kunena-trash-manager', 'index.php?option=com_kunena&view=trash', 'component', 0, 247, 2, 10077, 0, '0000-00-00 00:00:00', 0, 1, 'components/com_kunena/media/icons/favicons/kunena-trash.png', 0, '', 286, 287, 0, '', 1),
(259, 'kunenamenu', 'Diễn đàn', 'forums', '', 'forums', 'index.php?option=com_kunena&view=home&defaultmenu=259', 'component', 1, 1, 1, 10077, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"catids":["0"],"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 289, 306, 0, '*', 0),
(260, 'kunenamenu', 'Trang nhất', 'index', '', 'forums/index', 'index.php?option=com_kunena&view=category&layout=list&catid=0', 'component', 1, 259, 2, 10077, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"Trang nh\\u1ea5t Di\\u1ec5n \\u0111\\u00e0n","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"Trang nh\\u1ea5t","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 290, 291, 0, '*', 0),
(261, 'kunenamenu', 'Chủ đề gần đây', 'recent', '', 'forums/recent', 'index.php?option=com_kunena&view=topics&mode=replies', 'component', 1, 259, 2, 10077, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"topics_catselection":"","topics_categories":[""],"topics_time":"720","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 292, 293, 0, '*', 0),
(262, 'kunenamenu', 'Tạo chủ đề mới', 'newtopic', '', 'forums/newtopic', 'index.php?option=com_kunena&view=topic&layout=create', 'component', 1, 259, 2, 10077, 0, '0000-00-00 00:00:00', 0, 2, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 294, 295, 0, '*', 0),
(263, 'kunenamenu', 'Chưa trả lời', 'noreplies', '', 'forums/noreplies', 'index.php?option=com_kunena&view=topics&mode=noreplies', 'component', 1, 259, 2, 10077, 0, '0000-00-00 00:00:00', 0, 2, '', 0, '{"topics_catselection":"","topics_categories":[""],"topics_time":"-1","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 296, 297, 0, '*', 0),
(264, 'kunenamenu', 'Chủ đề của tôi', 'mylatest', '', 'forums/mylatest', 'index.php?option=com_kunena&view=topics&layout=user&mode=default', 'component', 1, 259, 2, 10077, 0, '0000-00-00 00:00:00', 0, 2, '', 0, '{"header":"","topics_categories":["0"],"topics_time":"-1","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 298, 299, 0, '*', 0),
(265, 'kunenamenu', 'Thông tin cá nhân', 'profile', '', 'forums/profile', 'index.php?option=com_kunena&view=user', 'component', 1, 259, 2, 10077, 0, '0000-00-00 00:00:00', 0, 2, '', 0, '{"integration":"1","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 300, 301, 0, '*', 0),
(266, 'kunenamenu', 'Hỗ trợ', 'help', '', 'forums/help', 'index.php?option=com_kunena&view=misc', 'component', 1, 259, 2, 10077, 585, '2014-10-16 22:49:15', 0, 3, '', 0, '{"body":"This help page is a menu item inside [b]Kunena Menu[\\/b], which allows easy navigation in your forum. \\r\\n\\r\\n You can use Joomla Menu Manager to edit items in this menu. Please go to [b]Administration[\\/b] >> [b]Menus[\\/b] >> [b]Kunena Menu[\\/b] >> [b]Help[\\/b] to edit or remove this menu item. \\r\\n\\r\\n In this menu item you can use Plain Text, BBCode or HTML. If you want to bind article into this page, you may use article BBCode (with article id): [code][article=full]123[\\/article][\\/code] \\r\\n\\r\\n If you want to create your own menu for Kunena, please start by creating [b]Home Page[\\/b] first. In that page you can select default menu item, which is shown when you enter to Kunena.","body_format":"bbcode","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 302, 303, 0, '*', 0),
(267, 'kunenamenu', 'Tìm kiếm', 'search', '', 'forums/search', 'index.php?option=com_kunena&view=search', 'component', 1, 259, 2, 10077, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1,"page_title":"","show_page_heading":0,"page_heading":"","pageclass_sfx":"","menu-meta_description":"","menu-meta_keywords":"","robots":"","secure":0}', 304, 305, 0, '*', 0),
(268, 'mainmenu', 'Diễn đàn || Forum', 'kunena-2014-10-15', '', 'kunena-2014-10-15', 'index.php?Itemid=259', 'alias', 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 0, 1, '', 0, '{"aliasoptions":"259","menu-anchor_title":"","menu-anchor_css":"","menu_image":"","menu_text":1}', 23, 24, 0, '*', 0);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_menu_types`
--

CREATE TABLE IF NOT EXISTS `zjw8d_menu_types` (
`id` int(10) unsigned NOT NULL,
  `menutype` varchar(24) NOT NULL,
  `title` varchar(48) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `zjw8d_menu_types`
--

INSERT INTO `zjw8d_menu_types` (`id`, `menutype`, `title`, `description`) VALUES
(1, 'mainmenu', 'Main Menu', 'The main menu for the site'),
(2, 'bottommenu', 'Bottom Menu', ''),
(3, 'booksmenu', 'Books Menu', 'Books Categegories Menu'),
(4, 'primarymenu', 'Primary Menu', 'Menu chính'),
(5, 'kunenamenu', 'Kunena Menu', 'This is the default Kunena menu. It is used as the top navigation for Kunena. It can be publish in any module position. Simply unpublish items that are not required.');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_messages`
--

CREATE TABLE IF NOT EXISTS `zjw8d_messages` (
`message_id` int(10) unsigned NOT NULL,
  `user_id_from` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_to` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `priority` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_messages_cfg`
--

CREATE TABLE IF NOT EXISTS `zjw8d_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) NOT NULL DEFAULT '',
  `cfg_value` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_modules`
--

CREATE TABLE IF NOT EXISTS `zjw8d_modules` (
`id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) NOT NULL DEFAULT '',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) DEFAULT NULL,
  `access` int(10) unsigned DEFAULT NULL,
  `showtitle` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=132 ;

--
-- Dumping data for table `zjw8d_modules`
--

INSERT INTO `zjw8d_modules` (`id`, `title`, `note`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `published`, `module`, `access`, `showtitle`, `params`, `client_id`, `language`) VALUES
(1, 'Main Menu', '', '', 1, 'menu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"mainmenu","base":"","startLevel":"1","endLevel":"0","showAllChildren":"1","tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"_menu","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(2, 'Login', '', '', 1, 'login', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '', 1, '*'),
(3, 'Popular Articles', '', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_popular', 3, 1, '{"count":"5","catid":"","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(4, 'Recently Added Articles', '', '', 4, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_latest', 3, 1, '{"count":"5","ordering":"c_dsc","catid":"","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(6, 'Unread Messages', '', '', 1, 'header', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_unread', 3, 1, '', 1, '*'),
(7, 'Online Users', '', '', 2, 'header', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_online', 3, 1, '', 1, '*'),
(8, 'Toolbar', '', '', 1, 'toolbar', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_toolbar', 3, 1, '', 1, '*'),
(9, 'Quick Icons', '', '', 1, 'icon', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_quickicon', 3, 1, '', 1, '*'),
(10, 'Logged-in Users', '', '', 2, 'cpanel', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_logged', 3, 1, '{"count":"5","name":"1","layout":"_:default","moduleclass_sfx":"","cache":"0","automatic_title":"1"}', 1, '*'),
(12, 'Admin Menu', '', '', 1, 'menu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 3, 1, '{"layout":"","moduleclass_sfx":"","shownew":"1","showhelp":"1","cache":"0"}', 1, '*'),
(13, 'Admin Submenu', '', '', 1, 'submenu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_submenu', 3, 1, '', 1, '*'),
(14, 'User Status', '', '', 2, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_status', 3, 1, '', 1, '*'),
(15, 'Title', '', '', 1, 'title', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_title', 3, 1, '', 1, '*'),
(17, 'Breadcrumbs', '', '', 1, 'breadcrumbs', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_breadcrumbs', 1, 1, '{"showHere":"1","showHome":"1","homeText":"Trang ch\\u1ee7","showLast":"1","separator":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(19, 'Bottom A', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-line badge-hot</code>\r\n', 2, 'bottom-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-line badge-hot","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(20, 'Bottom A', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-line badge-new</code>', 3, 'bottom-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-line badge-new","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(21, 'Bottom A', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-line badge-free</code>', 4, 'bottom-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-line badge-free","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(22, 'Bottom A', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-line badge-top</code>', 5, 'bottom-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-line badge-top","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(23, 'Ủng hộ Thư viện', '', '<ul class="line">\r\n  <li><a href="ung-ho-sach">Ủng hộ sách</a></li>\r\n  <li><a href="ung-ho-qua-paypal">Ủng hộ qua PayPal</a></li>\r\n  <li><a href="ung-ho-qua-bank">Ủng hộ qua Bank</a></li>\r\n  <li><a href="ung-ho-qua-mobile">Ủng hộ qua Mobile</a></li>\r\n</ul>', 5, 'bottom-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"icon-plus","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(24, 'Liên kết', '', '<ul class="line">\r\n  <li><a href="founders">Nhà sáng lập</a></li>\r\n  <li><a href="donor">Nhà tài trợ</a></li>\r\n  <li><a href="partners">Đối tác</a></li>\r\n</ul>\r\n\r\n', 7, 'bottom-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-line icon-arrow","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(25, 'Yêu cầu Hỗ trợ', '', '<ul class="line">\r\n  <li><a href="sach-dien-tu">Sách điện tử là gì?</a></li>\r\n  <li><a href="phan-mem-doc-sach">Phần mềm đọc sách</a></li>\r\n  <li><a href="yeu-cau-sach">Yêu cầu sách</a></li>\r\n</ul>', 6, 'bottom-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-line icon-box","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(26, 'Bản tin', '', '<!-- Begin MailChimp Signup Form -->\r\n\r\n<style type="text/css">\r\n	#mc_embed_signup{background:#fff; clear:left; font:14px Helvetica,Arial,sans-serif; }\r\n	/* Add your own MailChimp form style overrides in your site stylesheet or in this style block.\r\n	   We recommend moving this block and the preceding CSS link to the HEAD of your HTML file. */\r\n</style>\r\n<div id="mc_embed_signup">\r\n<form action="//epubviet.us7.list-manage.com/subscribe/post?u=0fd6ef8a424ca406baf625c14&amp;id=94b3dcb1ef" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>\r\n    <div id="mc_embed_signup_scroll">\r\n	\r\n	<input type="email" value="" name="EMAIL" class="email" id="mce-EMAIL" placeholder="email address" required>\r\n    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->\r\n    <div style="position: absolute; left: -5000px;"><input type="text" name="b_0fd6ef8a424ca406baf625c14_94b3dcb1ef" tabindex="-1" value=""></div>\r\n    <div class="clear"><input type="submit" value="Đăng ký" name="subscribe" id="mc-embedded-subscribe" class="button"></div>\r\n    </div>\r\n</form>\r\n</div>\r\n\r\n<!--End mc_embed_signup-->', 9, 'bottom-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-line icon-rss","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(27, 'Bottom B', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-corner icon-download</code>', 1, 'bottom-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-corner icon-download","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(28, 'Bottom B', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-corner icon-twitter</code>', 2, 'bottom-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-corner icon-twitter","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(29, 'Bottom B', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-inset icon-mail</code>', 3, 'bottom-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-inset icon-mail","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(30, 'Bottom B', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-inset icon-bubble</code>', 4, 'bottom-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-inset icon-bubble","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(31, 'Footer Menu', '', '', 1, 'footer', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"bottommenu","startLevel":"1","endLevel":"0","showAllChildren":"0","tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid"}', 0, '*'),
(32, 'Footer', '', '<p style="color:#3d3d3d">Built with HTML5 and CSS3. Copyright &copy; 2012 <a title="Thư viện ePub Việt" href="http://www.epubviet.com">Thư viện ePub Việt</a>. Bản quyền đã được bảo hộ (All Rights Reserved).</p>', 2, 'footer', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-box color-gradient","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(33, 'Headerbar', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 0, 'headerbar', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(34, 'Inner Bottom A', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-corner</code>', 1, 'innerbottom-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-corner","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(35, 'Inner Bottom B', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-box color-dark</code>', 2, 'innerbottom-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-box color-dark","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(36, 'Inner Top A', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-line icon-plus</code>', 1, 'innertop-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-line icon-plus","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(37, 'Inner Top B', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-box icon-box</code>', 1, 'innertop-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-box icon-box","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(38, 'Logo', '', '<div class="custom-logo size-auto"></div>', 1, 'logo', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(39, 'Thành viên || Member', '', '', 2, 'menu', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_login', 1, 1, '{"pretext":"","posttext":"","login":"","logout":"","greeting":"1","name":"0","usesecure":"1","usetext":"0","layout":"_:default","moduleclass_sfx":"","cache":"0","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(40, 'Search', '', '', 1, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_search', 1, 0, '{"label":"","width":"20","text":"","button":"0","button_pos":"right","imagebutton":"0","button_text":"","opensearch":"1","opensearch_title":"","set_itemid":"0","layout":"_:default","moduleclass_sfx":"style-blank","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(41, 'Sub Menu', '', '', 19, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_menu', 1, 1, '{"menutype":"mainmenu","base":"","startLevel":"2","endLevel":"0","showAllChildren":"1","tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(42, 'Phân loại Sách', '', '', 2, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_menu', 1, 1, '{"menutype":"booksmenu","base":"","startLevel":"1","endLevel":"0","showAllChildren":"1","tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"icon-plus","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(43, 'Sidebar A', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-box</code>', 14, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-box","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(44, 'Sidebar A', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-box color-dark</code>', 15, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-box color-dark","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(45, 'List Line', '', '<p>Use the CSS class <code>line</code> to create this list style.</p>\r\n\r\n<ul class="line line-icon">\r\n  <li>Item 1</li>\r\n  <li>Item 2</li>\r\n  <li>Item 3</li>\r\n  <li>Item 4</li>\r\n  <li>Item 5</li>\r\n</ul>', 29, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(46, 'List Zebra', '', '<p>Use the CSS class <code>zebra</code> to create this list style.</p>\r\n\r\n<ul class="zebra">\r\n	<li class="odd">Item 1</li>\r\n	<li>Item 2</li>\r\n	<li class="odd">Item 3</li>\r\n	<li>Item 4</li>\r\n	<li class="odd">Item 5</li>\r\n</ul>', 30, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(47, 'List Check', '', '<p>Use the CSS class <code>check</code> to create this list style.</p>\r\n\r\n<ul class="check">\r\n	<li>Item 1</li>\r\n	<li>Item 2</li>\r\n	<li>Item 3</li>\r\n	<li>Item 4</li>\r\n	<li>Item 5</li>\r\n</ul>', 32, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(48, 'Latest News', '', '', 31, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_articles_latest', 1, 1, '{"catid":["7"],"count":"5","show_featured":"","ordering":"p_dsc","user_id":"0","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(49, 'Login', '', '', 33, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_login', 1, 1, '{"pretext":"","posttext":"","login":"","logout":"","greeting":"1","name":"0","usesecure":"0","layout":"_:default","moduleclass_sfx":"","cache":"0"}', 0, '*'),
(50, 'Download ZOO', '', '<a class="display-block text-center" href="http://www.yootheme.com/zoo" target="_blank"><img class="size-auto" src="images/yootheme/zoo_icon.png" alt="A flexible and powerful content application builder to manage your content" title="A flexible and powerful content application builder to manage your content" width="150" height="140" /></a>\r\n\r\n<p>A flexible and powerful content application builder to manage your content.</p>\r\n\r\n<p><a class="button-default" href="http://www.yootheme.com/zoo" target="_blank">Download ZOO</a></p>', 35, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"badge-free","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(53, 'Warp Framework', '', '<a class="display-block text-center" href="http://www.yootheme.com/themes/warp-framework" target="_blank"><img class="size-auto" src="images/yootheme/warp_icon.png" alt="Warp is a fast and slick theme framework which provides a rich tool set to develop cross-platform themes" title="Warp is a fast and slick theme framework which provides a rich tool set to develop cross-platform themes" width="150" height="150" /></a>\r\n\r\n<p>A fast and slick theme framework built on the latest web techniques like HTML5, CSS3 and PHP 5.2+</p>\r\n\r\n<p><a class="button-default" href="http://www.yootheme.com/themes/warp-framework" target="_blank">Visit Website</a></p>', 36, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(54, 'Warp Features', '', '<p>All Warp features are available in this theme:</p>\r\n\r\n<ul class="check">\r\n	<li>Fast and Lightweight</li>\r\n	<li>Responsive Design</li>\r\n	<li>Update Notifications</li>\r\n	<li>HTML5 markup</li>\r\n	<li>RTL Support</li>\r\n	<li>CSS Framework</li>\r\n	<li>Nice Admin UI</li>\r\n	<li>File Minification</li>\r\n</ul>', 37, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(55, 'Responsive Design', '', 'This theme provides a fully responsive layout that adapts perfectly for all device resolutions.', 34, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(57, 'Sidebar A', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-inset</code>', 17, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-inset","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(58, 'Sidebar A', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-line</code>', 16, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-line","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(61, 'Top Menu', '', '', 1, 'toolbar-l', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_menu', 1, 1, '{"menutype":"bottommenu","base":"","startLevel":"1","endLevel":"0","showAllChildren":"0","tag_id":"","class_sfx":"","window_open":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(62, 'Top A', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-box</code>', 1, 'top-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-box","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(63, 'Top A', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-box</code>', 2, 'top-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-box","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(64, 'Top A', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-box</code>', 3, 'top-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-box","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(65, 'Top A', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-box</code>', 4, 'top-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-box","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(66, 'Icons Shipping', '', '<a href="http://www.yootheme.com/icons" target="_blank" class="display-block text-center">\r\n  <figure class="remove-margin">\r\n    <img class="size-auto" height="120" width="180" src="images/yootheme/icons_shipping.png" alt="Shipping Icons" />\r\n    <figcaption>Shipping Icons</figcaption>\r\n  </figure>\r\n</a>', 22, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(67, 'Icons E-Commerce', '', '<a href="http://www.yootheme.com/icons" target="_blank" class="display-block text-center">\r\n  <figure class="remove-margin">\r\n    <img class="size-auto" height="120" width="180" src="images/yootheme/icons_ecommerce.png" alt="E-Commerce Icons" />\r\n    <figcaption>E-Commerce Icons</figcaption>\r\n  </figure>\r\n</a>', 28, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(68, 'Icons FAQs', '', '<a href="http://www.yootheme.com/icons" target="_blank" class="display-block text-center">\r\n	<figure class="remove-margin">\r\n		<img class="size-auto" height="120" width="180" src="images/website/faqs.png" alt="FAQs" />\r\n		<figcaption>FAQs</figcaption>\r\n	</figure>\r\n</a>', 11, 'bottom-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(69, 'Icons Forum', '', '<a href="http://www.epubviet.com/forum" target="_blank" class="display-block text-center">\r\n	<figure class="remove-margin">\r\n		<img class="size-auto" height="120" width="180" src="images/website/forum.png" alt="Forum" />\r\n		<figcaption>Forum</figcaption>\r\n	</figure>\r\n</a>', 13, 'bottom-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(71, 'Top B', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-box color-gradient</code>', 1, 'top-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-box color-gradient","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(72, 'Top B', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-box color-gradient</code>', 2, 'top-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-box color-gradient","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(73, 'Top B', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-box color-color</code>', 3, 'top-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-box color-color","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(74, 'Top B', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-box color-dark</code>', 4, 'top-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-box color-dark","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(76, 'Twitter List', '', '', 23, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_widgetkit_twitter', 1, 0, '{"style":"list","from_user":"yootheme","to_user":"","ref_user":"","hashtag":"","word":"","nots":"","limit":"4","image_size":"48","show_image":"1","show_author":"1","show_date":"1","moduleclass_sfx":""}', 0, '*'),
(77, 'Get Widgetkit', '', '<a class="display-block text-center" href="http://www.yootheme.com/widgetkit" target="_blank"><img class="size-auto" src="images/yootheme/widgetkit_icon.png" alt="The next generation tool set for Joomla and WordPress" title="The next generation tool set for Joomla and WordPress" width="150" height="150" /></a>\r\n\r\n<p>The next generation tool set for Joomla and WordPress</p>\r\n\r\n<p><a class="button-default" href="http://www.yootheme.com/widgetkit" target="_blank">Download Widgetkit</a></p>', 18, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"badge-free","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(78, 'Tweet mới đăng', '', '', 10, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_widgetkit_twitter', 1, 1, '{"style_":"single","from_user":"epubviet","to_user":"","ref_user":"","hashtag":"","word":"","nots":"","limit":"4","image_size":"48","show_image":"0","show_author":"1","show_date":"1","consumer_key":"Q5hbwivftmWGun4lCIrTw","consumer_secret":"9XrofyGnFPazgmQqnXET8PH5kVrC0mxKA76Skx6YSA8","access_token":"753487272-Bqe5kcbBRXrDNnBZ4vsbOMjLxNPNTWs56h6BDGTS","access_token_secret":"EaJgJBmWHavVNmFu6Y7exVkUpAno2E5Hw9XcVoK5lgc","moduleclass_sfx":"icon-twitter","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(79, 'Twitter Single', '', '', 1, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_widgetkit_twitter', 1, 0, '{"style_":"list","from_user":"yootheme","to_user":"","ref_user":"","hashtag":"","word":"","nots":"","limit":"4","image_size":"48","show_image":"1","show_author":"1","show_date":"1","consumer_key":"","consumer_secret":"","access_token":"","access_token_secret":"","moduleclass_sfx":"","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(80, 'Multilanguage status', '', '', 1, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_multilangstatus', 3, 1, '{"layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(81, 'Joomla Version', '', '', 1, 'footer', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_version', 3, 1, '{"format":"short","product":"1","layout":"_:default","moduleclass_sfx":"","cache":"0"}', 1, '*'),
(89, 'Icons Blog', '', '<a href="http://www.yootheme.com/icons" target="_blank" class="display-block text-center">\r\n  <figure class="remove-margin">\r\n    <img class="size-auto" height="120" width="180" src="images/yootheme/icons_blog.png" alt="Blog Icons" />\r\n    <figcaption>Blog Icons</figcaption>\r\n  </figure>\r\n</a>', 27, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(90, 'Icons Space', '', '<a href="http://www.yootheme.com/icons" target="_blank" class="display-block text-center">\r\n  <figure class="remove-margin">\r\n    <img class="size-auto" height="120" width="180" src="images/yootheme/icons_space.png" alt="Space Icons" />\r\n    <figcaption>Space Icons</figcaption>\r\n  </figure>\r\n</a>', 11, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', -2, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(91, 'Icons Wave', '', '<a href="http://www.yootheme.com/icons" target="_blank" class="display-block text-center">\r\n	<figure class="remove-margin">\r\n		<img class="size-auto" height="120" width="180" src="images/website/wave.png" alt="Wave" />\r\n		<figcaption>Wave</figcaption>\r\n	</figure>\r\n</a>', 12, 'bottom-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(92, 'Icons User Guide', '', '<a href="http://www.yootheme.com/icons" target="_blank" class="display-block text-center">\r\n	<figure class="remove-margin">\r\n		<img class="size-auto" height="120" width="180" src="images/website/userguide.png" alt="User Guide" />\r\n		<figcaption>User Guide</figcaption>\r\n	</figure>\r\n</a>', 10, 'bottom-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(93, 'Buttons', '', '<p>Use the CSS classes <code>button-default</code> and <code>button-primary</code> to create nice buttons.</p>\r\n<a class="button-default" href="">Default</a>\r\n<a class="button-primary" href="">Primary</a>', 25, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(94, 'Frontpage Slideset', '', '', 1, 'innertop-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_widgetkit', 1, 0, '{"widget_id":"51","moduleclass_sfx":"","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(95, 'Frontpage Tabs', '', '', 9, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_widgetkit', 1, 0, '{"widget_id":"52","moduleclass_sfx":"style-blank","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(96, 'Features', '', '<ul class="line frontpage-icons">\r\n<li>\r\n  <h3 style="background-image: url(images/yootheme/home_icon_display.png);"> Retina display</h3>\r\n  <p>Optimized for the retina display on the new iPad.</p>\r\n</li>\r\n<li>\r\n  <h3 style="background-image: url(images/yootheme/home_icon_versions.png);">Versions</h3>\r\n  <p>Allows you to copy and share any version of your work.</p>\r\n</li>\r\n<li>\r\n  <h3 style="background-image: url(images/yootheme/home_icon_save.png);">Auto Save</h3>\r\n  <p>Auto Save technology is a clever saving  feature for your documents.\r\n</p>\r\n</li>\r\n</ul>\r\n\r\n    ', 21, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(97, 'App Store', '', '<div>\r\n  <img class="available-icon align-left" src="images/yootheme/home_app_store_icon.png" width="60" height="60" alt="Demo" />\r\n  \r\n  <h3 class="remove-margin frontpage-center" style="padding-top: 3px; line-height:24px; font-size: 15px;">Available on the<br><span style="font-size: 32px;">App Store</span></h3>\r\n</div>', 26, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(98, 'Android market', '', '<div>\r\n  <img class="align-left available-icon" src="images/yootheme/home_android_market_icon.png" width="60" height="60" alt="Demo" />\r\n  <h3 class="remove-margin frontpage-center" style="padding-top: 10px; line-height:20px; font-size: 15px;">Available in<br><span style="font-weight: bold; font-size: 20px;">Android Market</span></h3>\r\n</div>', 24, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(99, 'Tutorials', '', '<img class="size-auto" src="images/yootheme/home_tutorials.png" width="239" height="186" alt="Tutorials" />\r\n<p>\r\n  Explore the basic, intermediate, advanced or third-party tutorials to get the most out of the features and tools.\r\n</p>\r\n<p><a class="button-default" href="#">see more</a></p>', 20, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-inset","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(100, 'Latest Tweet', '', '', 13, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_widgetkit_twitter', 1, 1, '{"style_":"list","from_user":"epubviet","to_user":"","ref_user":"","hashtag":"","word":"","nots":"","limit":"1","image_size":"48","show_image":"0","show_author":"1","show_date":"1","consumer_key":"Q5hbwivftmWGun4lCIrTw","consumer_secret":"9XrofyGnFPazgmQqnXET8PH5kVrC0mxKA76Skx6YSA8","access_token":"753487272-Bqe5kcbBRXrDNnBZ4vsbOMjLxNPNTWs56h6BDGTS","access_token_secret":"EaJgJBmWHavVNmFu6Y7exVkUpAno2E5Hw9XcVoK5lgc","moduleclass_sfx":"icon-twitter","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(101, 'Social Icons', '', '<div class="float-right">\r\n  <ul class="social-icons remove-margin">\r\n    <li class="facebook"><a href="https://facebook.com/ePubViet" target="_blank"></a></li>\r\n    <li class="google-plus"><a href="https://plus.google.com/u/5/communities/104908262482586371472" target="_blank"></a></li>\r\n    <li class="twitter"><a href="https://twitter.com/ePubViet" target="_blank"></a></li>\r\n    <li class="rss"><a href="#"></a></li>\r\n  </ul>\r\n</div>\r\n', 1, 'headerbar', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(102, 'Simple Coding Box', '', '<div class="text-center frontpage-teaser-1" >\r\n  \r\n  <h1>Simple Coding Box</h1>\r\n  <p>Makes it easy for you to create fantastic looking web pages</p>\r\n  <img class="size-auto" src="images/yootheme/home_teaser.png" width="620" height="400" alt="Demo" />\r\n   <p class="remove-margin">\r\n    <a class="button-primary icon-download" href="#"><span class="icon-download"></span>DOWNLOAD NOW</a>\r\n    <a class="button-primary icon-buy" href="#"><span class="icon-buy"></span>BUY NOW</a>\r\n  </p>  \r\n      \r\n</div>', 1, 'innertop-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(103, 'Beautiful User Interface', '', '<div class="frontpage-teaser-2">\r\n  \r\n  <h1 class="text-center">Beautiful User Interface</h1>\r\n  <p class="text-center">Fully customizable menus and toolbars</p>\r\n  \r\n  <div class="grid-block"> \r\n    <div class="grid-box width66 grid-h">\r\n      <img class="size-auto float-left" style="margin-left: -20px;" src="images/yootheme/home_features2.png" width="410" height="390" alt="Demo" />\r\n    </div>\r\n\r\n    <div class="grid-box width33 grid-h">\r\n    \r\n      <div class="frontpage-center">\r\n        \r\n        <h2 class="journal-font">Minimap</h2>\r\n        <p>Use it for quick surveys</p>\r\n      </div>\r\n      \r\n      <div class="frontpage-center">\r\n        <h2 class="journal-font">Custom toolbar</h2>\r\n        <p>Add and remove tools</p>\r\n      </div>\r\n    </div>  \r\n  </div>\r\n</div>\r\n', 1, 'innerbottom-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(104, 'Fully Responsive', '', '<div class="frontpage-teaser-2">\r\n\r\n  <h1 class="text-center">Fully Responsive</h1>\r\n  <p class="text-center">Viewable on all devices including mobile phones</p>\r\n\r\n  <div class="grid-block">  \r\n\r\n    <div class="grid-box width33 grid-h frontpage-center">\r\n  \r\n      <div>  \r\n        <h2 class="journal-font">Mobile-Friendly</h2>\r\n        <p>Use new responsive menus and toolbars</p>\r\n      </div>\r\n    \r\n      <div>\r\n        <h2 class="journal-font">High Definition</h2>\r\n        <p>Displays beautifully on retina display</p>\r\n      </div> \r\n    \r\n    </div>\r\n\r\n    <div class="grid-box width66 grid-h">\r\n      <img class="size-auto float-right" style="margin-right: -20px;" src="images/yootheme/home_features3.png" width="415" height="460" alt="Demo" />\r\n    </div> \r\n  </div>\r\n</div>\r\n', 1, 'innerbottom-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 0, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(105, 'Inner Top A', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-line icon-arrow</code>', 1, 'innertop-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-line icon-arrow","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(106, 'Inner Top B', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-box color-gradient icon-rss</code>', 1, 'innertop-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-box color-gradient icon-rss","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(107, 'Inner Bottom A', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.  Module Class Suffix <code>style-inset</code>', 1, 'innerbottom-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-inset","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(108, 'Inner Bottom B', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-box color-color</code>', 2, 'innerbottom-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-box color-color","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(109, 'Sidebar A', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Module Class Suffix <code>style-box color-color</code>', 8, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_custom', 1, 1, '{"prepare_content":"1","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-box color-color","cache":"1","cache_time":"900","cachemode":"static"}', 0, '*'),
(110, 'sh404sef control panel icon', '', '', 0, 'status', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_sh404sef_cpicon', 1, 1, '', 1, '*'),
(111, 'ZOO Category', '', '', 1, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_zoocategory', 1, 1, '{"theme":"flatlist","category":"","application":"3","depth":"0","add_count":"0","menu_item":"","moduleclass_sfx":"","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(112, 'Ý kiến Bình luận', '', '', 6, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_zoocomment', 1, 1, '{"theme":"bubbles","category":"","application":"3","subcategories":"1","count":"10","show_avatar":"1","avatar_size":"40","show_author":"1","show_meta":"1","moduleclass_sfx":"icon-arrow","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(113, 'ZOO Item', '', '', 1, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_zooitem', 1, 1, '{"theme":"list","layout":"default","media_position":"left","application":"3","mode":"categories","type":"movie","category":"","item_id":"","subcategories":"0","count":"4","order":["_itemname","","","",""],"moduleclass_sfx":"","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(114, 'ZOO Quick Icons', '', '', 3, 'icon', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_zooquickicon', 1, 1, '', 1, '*'),
(115, 'Tags', '', '', 7, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_zootag', 1, 1, '{"theme":"cloud","mode":"all","type":"movie","category":"","application":"3","subcategories":"1","count":"20","order":"ocount","menu_item":"","moduleclass_sfx":"icon-arrow","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(116, 'Home Slideshow', '', '', 1, 'innertop-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_widgetkit', 1, 0, '{"widget_id":"53","moduleclass_sfx":"","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(117, 'Sách đọc nhiều', '', '', 3, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_widgetkit', 1, 1, '{"widget_id":"56","moduleclass_sfx":"badge-hot icon-plus","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(118, 'Sách mới đăng', '', '', 4, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_widgetkit', 1, 1, '{"widget_id":"57","moduleclass_sfx":"badge-new icon-plus","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(119, 'Sách ngẫu nhiên', '', '', 5, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_widgetkit', 1, 1, '{"widget_id":"55","moduleclass_sfx":"badge-free icon-plus","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*');
INSERT INTO `zjw8d_modules` (`id`, `title`, `note`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `published`, `module`, `access`, `showtitle`, `params`, `client_id`, `language`) VALUES
(120, 'Ủng hộ Thư viện', '', '<div style="text-align: center;"><form action="https://www.paypal.com/cgi-bin/webscr" method="post"><input type="hidden" name="cmd" value="_s-xclick" /> <input type="hidden" name="hosted_button_id" value="3YCX3EJEGVPQW" /> <input type="image" name="submit" src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" alt="PayPal - The safer, easier way to pay online!" /> <img class="gcjayytfhbkfmprswryi" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" border="0" alt="" width="1" height="1" /></form></div>', 12, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_custom', 1, 1, '{"prepare_content":"0","backgroundimage":"","layout":"_:default","moduleclass_sfx":"style-box color-dark icon-box","cache":"1","cache_time":"900","cachemode":"static","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(121, 'Danh ngôn Cuộc sống', '', '', 1, 'sidebar-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_tquotes', 1, 1, '{"filename":"tquotes.txt","interval":"random","quotemarks":"0","sep":"|","style_method":"2","text_color":"#bbaacc","background":"white","font-weight":"400","font-style":"normal","font-size":"medium","layout":"_:default","moduleclass_sfx":"icon-arrow","cache":"1","cache_time":"900","cachemode":"itemid","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(122, 'Văn học Việt Nam', '', '', 1, 'innerbottom-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_widgetkit', 1, 1, '{"widget_id":"59","moduleclass_sfx":"icon-box","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(123, 'Văn học cổ điển', '', '', 1, 'innerbottom-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_widgetkit', 1, 1, '{"widget_id":"54","moduleclass_sfx":"icon-box","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(124, 'Trinh thám Hình sự', '', '', 1, 'innerbottom-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_widgetkit', 1, 1, '{"widget_id":"62","moduleclass_sfx":"icon-box","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(125, 'Truyện ma Kinh dị', '', '', 1, 'innerbottom-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_widgetkit', 1, 1, '{"widget_id":"63","moduleclass_sfx":"icon-box","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(126, 'Học trò Thiếu nhi', '', '', 0, 'innerbottom-a', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_widgetkit', 1, 1, '{"widget_id":"61","moduleclass_sfx":"icon-box","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(127, 'Bản tin', '', '', 8, 'bottom-b', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 'mod_cmc', 1, 1, '{"intro-text":"Sign up to our newsletter","outro-text-1":"","outro-text-2":"","thankyou":"Thank you! Please check your email and confirm the newsletter subscription.","listid":"94b3dcb1ef","fields":["EMAIL;email;Email Address;1;"],"mapfields":"","dateFormat":"%Y-%m-%d","phoneFormat":"inter","address2":"0","newsletterCheckbox":"0","jquery":"0","bootstrap_form":"0","moduleclass_sfx":"icon-rss","module_tag":"div","bootstrap_size":"0","header_tag":"h3","header_class":"","style":"0"}', 0, '*'),
(128, 'Kunena Statistics', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_kunenastats', 1, 1, '', 0, '*'),
(129, 'Kunena Login', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_kunenalogin', 1, 1, '', 0, '*'),
(130, 'Kunena Latest', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_kunenalatest', 1, 1, '', 0, '*'),
(131, 'Kunena Search', '', '', 0, '', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 'mod_kunenasearch', 1, 1, '', 0, '*');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_modules_menu`
--

CREATE TABLE IF NOT EXISTS `zjw8d_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_modules_menu`
--

INSERT INTO `zjw8d_modules_menu` (`moduleid`, `menuid`) VALUES
(1, 0),
(2, 0),
(3, 0),
(4, 0),
(6, 0),
(7, 0),
(8, 0),
(9, 0),
(10, 0),
(12, 0),
(13, 0),
(14, 0),
(15, 0),
(17, 111),
(17, 112),
(17, 113),
(17, 114),
(17, 115),
(17, 116),
(17, 117),
(17, 118),
(17, 119),
(17, 120),
(17, 121),
(17, 122),
(17, 123),
(17, 198),
(17, 199),
(17, 200),
(17, 201),
(17, 202),
(17, 203),
(17, 204),
(17, 205),
(17, 206),
(17, 207),
(17, 208),
(17, 209),
(17, 210),
(17, 211),
(17, 212),
(17, 213),
(17, 214),
(17, 215),
(17, 216),
(17, 217),
(17, 218),
(17, 219),
(17, 220),
(17, 221),
(17, 222),
(17, 223),
(17, 224),
(17, 225),
(17, 226),
(17, 227),
(17, 228),
(17, 229),
(17, 230),
(17, 231),
(17, 232),
(17, 233),
(17, 234),
(17, 235),
(17, 236),
(17, 237),
(17, 238),
(19, 103),
(20, 103),
(21, 103),
(22, 103),
(23, 101),
(23, 102),
(23, 103),
(23, 104),
(23, 105),
(23, 106),
(23, 107),
(23, 108),
(23, 109),
(23, 110),
(23, 111),
(23, 112),
(23, 113),
(23, 114),
(23, 115),
(23, 116),
(23, 117),
(23, 118),
(23, 119),
(23, 120),
(23, 121),
(23, 122),
(23, 123),
(23, 124),
(23, 125),
(23, 126),
(23, 127),
(23, 128),
(23, 129),
(23, 130),
(23, 132),
(23, 133),
(23, 134),
(23, 135),
(23, 136),
(23, 140),
(23, 141),
(23, 142),
(23, 143),
(23, 144),
(23, 150),
(23, 151),
(23, 152),
(23, 153),
(23, 154),
(23, 155),
(23, 171),
(23, 172),
(23, 173),
(23, 174),
(23, 175),
(23, 176),
(23, 177),
(23, 178),
(23, 198),
(23, 199),
(23, 200),
(23, 201),
(23, 202),
(23, 203),
(23, 204),
(23, 205),
(23, 206),
(23, 207),
(23, 208),
(23, 209),
(23, 210),
(23, 211),
(23, 212),
(23, 213),
(23, 214),
(23, 215),
(23, 216),
(23, 217),
(23, 218),
(23, 219),
(23, 220),
(23, 221),
(23, 222),
(23, 223),
(23, 224),
(23, 225),
(23, 226),
(23, 227),
(23, 228),
(23, 229),
(23, 230),
(23, 231),
(23, 232),
(23, 233),
(23, 234),
(23, 235),
(24, 101),
(24, 102),
(24, 103),
(24, 104),
(24, 105),
(24, 106),
(24, 107),
(24, 108),
(24, 109),
(24, 110),
(24, 111),
(24, 112),
(24, 113),
(24, 114),
(24, 115),
(24, 116),
(24, 117),
(24, 118),
(24, 119),
(24, 120),
(24, 121),
(24, 122),
(24, 123),
(24, 124),
(24, 125),
(24, 126),
(24, 127),
(24, 128),
(24, 129),
(24, 130),
(24, 132),
(24, 133),
(24, 134),
(24, 135),
(24, 136),
(24, 140),
(24, 141),
(24, 142),
(24, 143),
(24, 144),
(24, 150),
(24, 151),
(24, 152),
(24, 153),
(24, 154),
(24, 155),
(24, 171),
(24, 172),
(24, 173),
(24, 174),
(24, 175),
(24, 176),
(24, 177),
(24, 178),
(24, 198),
(24, 199),
(24, 200),
(24, 201),
(24, 202),
(24, 203),
(24, 204),
(24, 205),
(24, 206),
(24, 207),
(24, 208),
(24, 209),
(24, 210),
(24, 211),
(24, 212),
(24, 213),
(24, 214),
(24, 215),
(24, 216),
(24, 217),
(24, 218),
(24, 219),
(24, 220),
(24, 221),
(24, 222),
(24, 223),
(24, 224),
(24, 225),
(24, 226),
(24, 227),
(24, 228),
(24, 229),
(24, 230),
(24, 231),
(24, 232),
(24, 233),
(24, 234),
(24, 235),
(25, 101),
(25, 102),
(25, 103),
(25, 104),
(25, 105),
(25, 106),
(25, 107),
(25, 108),
(25, 109),
(25, 110),
(25, 111),
(25, 112),
(25, 113),
(25, 114),
(25, 115),
(25, 116),
(25, 117),
(25, 118),
(25, 119),
(25, 120),
(25, 121),
(25, 122),
(25, 123),
(25, 124),
(25, 125),
(25, 126),
(25, 127),
(25, 128),
(25, 129),
(25, 130),
(25, 132),
(25, 133),
(25, 134),
(25, 135),
(25, 136),
(25, 140),
(25, 141),
(25, 142),
(25, 143),
(25, 144),
(25, 150),
(25, 151),
(25, 152),
(25, 153),
(25, 154),
(25, 155),
(25, 171),
(25, 172),
(25, 173),
(25, 174),
(25, 175),
(25, 176),
(25, 177),
(25, 178),
(25, 198),
(25, 199),
(25, 200),
(25, 201),
(25, 202),
(25, 203),
(25, 204),
(25, 205),
(25, 206),
(25, 207),
(25, 208),
(25, 209),
(25, 210),
(25, 211),
(25, 212),
(25, 213),
(25, 214),
(25, 215),
(25, 216),
(25, 217),
(25, 218),
(25, 219),
(25, 220),
(25, 221),
(25, 222),
(25, 223),
(25, 224),
(25, 225),
(25, 226),
(25, 227),
(25, 228),
(25, 229),
(25, 230),
(25, 231),
(25, 232),
(25, 233),
(25, 234),
(25, 235),
(26, 101),
(26, 102),
(26, 103),
(26, 104),
(26, 105),
(26, 106),
(26, 107),
(26, 108),
(26, 109),
(26, 110),
(26, 111),
(26, 112),
(26, 113),
(26, 114),
(26, 115),
(26, 116),
(26, 117),
(26, 118),
(26, 119),
(26, 120),
(26, 121),
(26, 122),
(26, 123),
(26, 124),
(26, 125),
(26, 126),
(26, 127),
(26, 128),
(26, 129),
(26, 130),
(26, 132),
(26, 133),
(26, 134),
(26, 135),
(26, 136),
(26, 140),
(26, 141),
(26, 142),
(26, 143),
(26, 144),
(26, 150),
(26, 151),
(26, 152),
(26, 153),
(26, 154),
(26, 155),
(26, 171),
(26, 172),
(26, 173),
(26, 174),
(26, 175),
(26, 176),
(26, 177),
(26, 178),
(26, 198),
(26, 199),
(26, 200),
(26, 201),
(26, 202),
(26, 203),
(26, 204),
(26, 205),
(26, 206),
(26, 207),
(26, 208),
(26, 209),
(26, 210),
(26, 211),
(26, 212),
(26, 213),
(26, 214),
(26, 215),
(26, 216),
(26, 217),
(26, 218),
(26, 219),
(26, 220),
(26, 221),
(26, 222),
(26, 223),
(26, 224),
(26, 225),
(26, 226),
(26, 227),
(26, 228),
(26, 229),
(26, 230),
(26, 231),
(26, 232),
(26, 233),
(26, 234),
(26, 235),
(27, 103),
(28, 103),
(29, 103),
(30, 103),
(31, 0),
(32, 0),
(33, 103),
(34, 103),
(35, 103),
(36, 103),
(37, 103),
(38, 0),
(39, 0),
(40, 101),
(40, 102),
(40, 103),
(40, 104),
(40, 106),
(40, 107),
(40, 108),
(40, 109),
(40, 110),
(40, 111),
(40, 112),
(40, 113),
(40, 114),
(40, 115),
(40, 116),
(40, 117),
(40, 118),
(40, 119),
(40, 120),
(40, 121),
(40, 122),
(40, 123),
(40, 124),
(40, 125),
(40, 126),
(40, 127),
(40, 128),
(40, 129),
(40, 130),
(40, 132),
(40, 133),
(40, 134),
(40, 135),
(40, 136),
(40, 140),
(40, 141),
(40, 142),
(40, 143),
(40, 144),
(40, 150),
(40, 151),
(40, 152),
(40, 153),
(40, 154),
(40, 155),
(40, 171),
(40, 172),
(40, 173),
(40, 174),
(40, 175),
(40, 176),
(40, 177),
(40, 178),
(40, 198),
(40, 199),
(40, 200),
(40, 201),
(40, 202),
(40, 203),
(40, 204),
(40, 205),
(40, 206),
(40, 207),
(40, 208),
(40, 209),
(40, 210),
(40, 211),
(40, 212),
(40, 213),
(40, 214),
(40, 215),
(40, 216),
(40, 217),
(40, 218),
(40, 219),
(40, 220),
(40, 221),
(40, 222),
(40, 223),
(40, 224),
(40, 225),
(40, 226),
(40, 227),
(40, 228),
(40, 229),
(40, 230),
(40, 231),
(40, 232),
(40, 233),
(40, 234),
(40, 235),
(41, 102),
(41, 104),
(41, 107),
(41, 123),
(41, 124),
(41, 125),
(41, 126),
(41, 127),
(41, 128),
(41, 129),
(41, 130),
(41, 132),
(41, 133),
(41, 134),
(41, 135),
(41, 140),
(41, 141),
(41, 142),
(41, 143),
(41, 144),
(41, 150),
(41, 151),
(41, 152),
(41, 153),
(41, 154),
(41, 155),
(42, 101),
(42, 102),
(42, 111),
(42, 112),
(42, 113),
(42, 114),
(42, 115),
(42, 116),
(42, 117),
(42, 118),
(42, 119),
(42, 120),
(42, 121),
(42, 122),
(42, 123),
(42, 198),
(42, 199),
(42, 200),
(42, 201),
(42, 202),
(42, 203),
(42, 204),
(42, 205),
(42, 206),
(42, 207),
(42, 208),
(42, 209),
(42, 210),
(42, 211),
(42, 212),
(42, 213),
(42, 214),
(42, 215),
(42, 216),
(42, 217),
(42, 218),
(42, 219),
(42, 220),
(42, 221),
(42, 222),
(42, 223),
(42, 224),
(42, 225),
(42, 226),
(42, 227),
(42, 228),
(42, 229),
(42, 230),
(42, 231),
(42, 232),
(42, 233),
(42, 234),
(42, 235),
(43, 103),
(44, 103),
(45, 104),
(46, 104),
(47, 104),
(48, 107),
(48, 124),
(48, 128),
(49, 107),
(49, 124),
(49, 128),
(50, 106),
(53, 102),
(54, 102),
(55, 102),
(57, 103),
(58, 103),
(61, 103),
(62, 103),
(63, 103),
(64, 103),
(65, 103),
(66, 105),
(67, 105),
(68, 105),
(69, 105),
(71, 103),
(72, 103),
(73, 103),
(74, 103),
(76, 136),
(77, 102),
(77, 103),
(77, 104),
(77, 108),
(77, 109),
(77, 110),
(77, 132),
(77, 133),
(77, 134),
(77, 135),
(77, 140),
(77, 141),
(77, 142),
(77, 143),
(77, 144),
(77, 171),
(78, 101),
(78, 102),
(78, 103),
(78, 104),
(78, 106),
(78, 107),
(78, 108),
(78, 109),
(78, 110),
(78, 111),
(78, 112),
(78, 113),
(78, 114),
(78, 115),
(78, 116),
(78, 117),
(78, 118),
(78, 119),
(78, 120),
(78, 121),
(78, 122),
(78, 123),
(78, 124),
(78, 125),
(78, 126),
(78, 127),
(78, 128),
(78, 129),
(78, 130),
(78, 132),
(78, 133),
(78, 134),
(78, 135),
(78, 136),
(78, 140),
(78, 141),
(78, 142),
(78, 143),
(78, 144),
(78, 150),
(78, 151),
(78, 152),
(78, 153),
(78, 154),
(78, 155),
(78, 171),
(78, 172),
(78, 173),
(78, 174),
(78, 175),
(78, 176),
(78, 177),
(78, 178),
(78, 198),
(78, 199),
(78, 200),
(78, 201),
(78, 202),
(78, 203),
(78, 204),
(78, 205),
(78, 206),
(78, 207),
(78, 208),
(78, 209),
(78, 210),
(78, 211),
(78, 212),
(78, 213),
(78, 214),
(78, 215),
(78, 216),
(78, 217),
(78, 218),
(78, 219),
(78, 220),
(78, 221),
(78, 222),
(78, 223),
(78, 224),
(78, 225),
(78, 226),
(78, 227),
(78, 228),
(78, 229),
(78, 230),
(78, 231),
(78, 232),
(78, 233),
(78, 234),
(78, 235),
(78, 236),
(78, 237),
(78, 238),
(79, 101),
(79, 136),
(80, 0),
(81, 0),
(89, 105),
(90, 105),
(91, 105),
(92, 105),
(93, 104),
(94, 101),
(95, 101),
(96, 101),
(97, 101),
(98, 101),
(99, 101),
(100, 101),
(100, 102),
(100, 103),
(100, 104),
(100, 105),
(100, 106),
(100, 107),
(100, 108),
(100, 109),
(100, 110),
(100, 111),
(100, 112),
(100, 113),
(100, 114),
(100, 115),
(100, 116),
(100, 117),
(100, 118),
(100, 119),
(100, 120),
(100, 121),
(100, 122),
(100, 123),
(100, 124),
(100, 125),
(100, 126),
(100, 127),
(100, 128),
(100, 129),
(100, 130),
(100, 132),
(100, 133),
(100, 134),
(100, 135),
(100, 136),
(100, 140),
(100, 141),
(100, 142),
(100, 143),
(100, 144),
(100, 150),
(100, 151),
(100, 152),
(100, 153),
(100, 154),
(100, 155),
(100, 171),
(100, 172),
(100, 173),
(100, 174),
(100, 175),
(100, 176),
(100, 177),
(100, 178),
(100, 198),
(100, 199),
(100, 200),
(100, 201),
(100, 202),
(100, 203),
(100, 204),
(100, 205),
(100, 206),
(100, 207),
(100, 208),
(100, 209),
(100, 210),
(100, 211),
(100, 212),
(100, 213),
(100, 214),
(100, 215),
(100, 216),
(100, 217),
(100, 218),
(100, 219),
(100, 220),
(100, 221),
(100, 222),
(100, 223),
(100, 224),
(100, 225),
(100, 226),
(100, 227),
(100, 228),
(100, 229),
(100, 230),
(100, 231),
(100, 232),
(100, 233),
(100, 234),
(100, 235),
(100, 236),
(100, 237),
(100, 238),
(101, 0),
(102, 101),
(103, 101),
(104, 101),
(105, 103),
(106, 103),
(107, 103),
(108, 103),
(109, 103),
(110, 0),
(111, 101),
(111, 102),
(111, 103),
(111, 104),
(111, 105),
(111, 106),
(111, 107),
(111, 108),
(111, 109),
(111, 110),
(111, 111),
(111, 112),
(111, 113),
(111, 114),
(111, 115),
(111, 116),
(111, 117),
(111, 118),
(111, 119),
(111, 120),
(111, 121),
(111, 122),
(111, 123),
(111, 124),
(111, 125),
(111, 126),
(111, 127),
(111, 128),
(111, 129),
(111, 130),
(111, 132),
(111, 133),
(111, 134),
(111, 135),
(111, 136),
(111, 140),
(111, 141),
(111, 142),
(111, 143),
(111, 144),
(111, 150),
(111, 151),
(111, 152),
(111, 153),
(111, 154),
(111, 155),
(111, 171),
(111, 172),
(111, 173),
(111, 174),
(111, 175),
(111, 176),
(111, 177),
(111, 178),
(111, 198),
(111, 199),
(111, 200),
(111, 201),
(111, 202),
(111, 203),
(111, 204),
(111, 205),
(111, 206),
(111, 207),
(111, 208),
(111, 209),
(111, 210),
(111, 211),
(111, 212),
(111, 213),
(111, 214),
(111, 215),
(111, 216),
(111, 217),
(111, 218),
(111, 219),
(111, 220),
(111, 221),
(111, 222),
(111, 223),
(111, 224),
(111, 225),
(111, 226),
(111, 227),
(111, 228),
(111, 229),
(111, 230),
(111, 231),
(111, 232),
(111, 233),
(111, 234),
(111, 235),
(111, 236),
(111, 237),
(111, 238),
(112, 101),
(112, 102),
(112, 103),
(112, 104),
(112, 106),
(112, 107),
(112, 108),
(112, 109),
(112, 110),
(112, 111),
(112, 112),
(112, 113),
(112, 114),
(112, 115),
(112, 116),
(112, 117),
(112, 118),
(112, 119),
(112, 120),
(112, 121),
(112, 122),
(112, 123),
(112, 124),
(112, 125),
(112, 126),
(112, 127),
(112, 128),
(112, 129),
(112, 130),
(112, 132),
(112, 133),
(112, 134),
(112, 135),
(112, 136),
(112, 140),
(112, 141),
(112, 142),
(112, 143),
(112, 144),
(112, 150),
(112, 151),
(112, 152),
(112, 153),
(112, 154),
(112, 155),
(112, 171),
(112, 172),
(112, 173),
(112, 174),
(112, 175),
(112, 176),
(112, 177),
(112, 178),
(112, 198),
(112, 199),
(112, 200),
(112, 201),
(112, 202),
(112, 203),
(112, 204),
(112, 205),
(112, 206),
(112, 207),
(112, 208),
(112, 209),
(112, 210),
(112, 211),
(112, 212),
(112, 213),
(112, 214),
(112, 215),
(112, 216),
(112, 217),
(112, 218),
(112, 219),
(112, 220),
(112, 221),
(112, 222),
(112, 223),
(112, 224),
(112, 225),
(112, 226),
(112, 227),
(112, 228),
(112, 229),
(112, 230),
(112, 231),
(112, 232),
(112, 233),
(112, 234),
(112, 235),
(112, 236),
(112, 237),
(112, 238),
(114, 0),
(115, 101),
(115, 102),
(115, 103),
(115, 104),
(115, 106),
(115, 107),
(115, 108),
(115, 109),
(115, 110),
(115, 111),
(115, 112),
(115, 113),
(115, 114),
(115, 115),
(115, 116),
(115, 117),
(115, 118),
(115, 119),
(115, 120),
(115, 121),
(115, 122),
(115, 123),
(115, 124),
(115, 125),
(115, 126),
(115, 127),
(115, 128),
(115, 129),
(115, 130),
(115, 132),
(115, 133),
(115, 134),
(115, 135),
(115, 136),
(115, 140),
(115, 141),
(115, 142),
(115, 143),
(115, 144),
(115, 150),
(115, 151),
(115, 152),
(115, 153),
(115, 154),
(115, 155),
(115, 171),
(115, 172),
(115, 173),
(115, 174),
(115, 175),
(115, 176),
(115, 177),
(115, 178),
(115, 198),
(115, 199),
(115, 200),
(115, 201),
(115, 202),
(115, 203),
(115, 204),
(115, 205),
(115, 206),
(115, 207),
(115, 208),
(115, 209),
(115, 210),
(115, 211),
(115, 212),
(115, 213),
(115, 214),
(115, 215),
(115, 216),
(115, 217),
(115, 218),
(115, 219),
(115, 220),
(115, 221),
(115, 222),
(115, 223),
(115, 224),
(115, 225),
(115, 226),
(115, 227),
(115, 228),
(115, 229),
(115, 230),
(115, 231),
(115, 232),
(115, 233),
(115, 234),
(115, 235),
(115, 236),
(115, 237),
(115, 238),
(116, 101),
(117, 101),
(117, 102),
(117, 111),
(117, 112),
(117, 113),
(117, 114),
(117, 115),
(117, 116),
(117, 117),
(117, 118),
(117, 119),
(117, 120),
(117, 121),
(117, 122),
(117, 123),
(117, 171),
(117, 198),
(117, 199),
(117, 200),
(117, 201),
(117, 202),
(117, 203),
(117, 204),
(117, 205),
(117, 206),
(117, 207),
(117, 208),
(117, 209),
(117, 210),
(117, 211),
(117, 212),
(117, 213),
(117, 214),
(117, 215),
(117, 216),
(117, 217),
(117, 218),
(117, 219),
(117, 220),
(117, 221),
(117, 222),
(117, 223),
(117, 224),
(117, 225),
(117, 226),
(117, 227),
(117, 228),
(117, 229),
(117, 230),
(117, 231),
(117, 232),
(117, 233),
(117, 234),
(117, 235),
(118, 101),
(118, 102),
(118, 111),
(118, 112),
(118, 113),
(118, 114),
(118, 115),
(118, 116),
(118, 117),
(118, 118),
(118, 119),
(118, 120),
(118, 121),
(118, 122),
(118, 123),
(118, 171),
(118, 198),
(118, 199),
(118, 200),
(118, 201),
(118, 202),
(118, 203),
(118, 204),
(118, 205),
(118, 206),
(118, 207),
(118, 208),
(118, 209),
(118, 210),
(118, 211),
(118, 212),
(118, 213),
(118, 214),
(118, 215),
(118, 216),
(118, 217),
(118, 218),
(118, 219),
(118, 220),
(118, 221),
(118, 222),
(118, 223),
(118, 224),
(118, 225),
(118, 226),
(118, 227),
(118, 228),
(118, 229),
(118, 230),
(118, 231),
(118, 232),
(118, 233),
(118, 234),
(118, 235),
(119, 101),
(119, 102),
(119, 111),
(119, 112),
(119, 113),
(119, 114),
(119, 115),
(119, 116),
(119, 117),
(119, 118),
(119, 119),
(119, 120),
(119, 121),
(119, 122),
(119, 123),
(119, 171),
(119, 198),
(119, 199),
(119, 200),
(119, 201),
(119, 202),
(119, 203),
(119, 204),
(119, 205),
(119, 206),
(119, 207),
(119, 208),
(119, 209),
(119, 210),
(119, 211),
(119, 212),
(119, 213),
(119, 214),
(119, 215),
(119, 216),
(119, 217),
(119, 218),
(119, 219),
(119, 220),
(119, 221),
(119, 222),
(119, 223),
(119, 224),
(119, 225),
(119, 226),
(119, 227),
(119, 228),
(119, 229),
(119, 230),
(119, 231),
(119, 232),
(119, 233),
(119, 234),
(119, 235),
(120, 101),
(120, 102),
(120, 103),
(120, 104),
(120, 106),
(120, 107),
(120, 108),
(120, 109),
(120, 110),
(120, 111),
(120, 112),
(120, 113),
(120, 114),
(120, 115),
(120, 116),
(120, 117),
(120, 118),
(120, 119),
(120, 120),
(120, 121),
(120, 122),
(120, 123),
(120, 124),
(120, 125),
(120, 126),
(120, 127),
(120, 128),
(120, 129),
(120, 130),
(120, 132),
(120, 133),
(120, 134),
(120, 135),
(120, 136),
(120, 140),
(120, 141),
(120, 142),
(120, 143),
(120, 144),
(120, 150),
(120, 151),
(120, 152),
(120, 153),
(120, 154),
(120, 155),
(120, 171),
(120, 172),
(120, 173),
(120, 174),
(120, 175),
(120, 176),
(120, 177),
(120, 178),
(120, 198),
(120, 199),
(120, 200),
(120, 201),
(120, 202),
(120, 203),
(120, 204),
(120, 205),
(120, 206),
(120, 207),
(120, 208),
(120, 209),
(120, 210),
(120, 211),
(120, 212),
(120, 213),
(120, 214),
(120, 215),
(120, 216),
(120, 217),
(120, 218),
(120, 219),
(120, 220),
(120, 221),
(120, 222),
(120, 223),
(120, 224),
(120, 225),
(120, 226),
(120, 227),
(120, 228),
(120, 229),
(120, 230),
(120, 231),
(120, 232),
(120, 233),
(120, 234),
(120, 235),
(120, 236),
(120, 237),
(120, 238),
(121, 101),
(121, 102),
(121, 103),
(121, 104),
(121, 106),
(121, 107),
(121, 108),
(121, 109),
(121, 110),
(121, 111),
(121, 112),
(121, 113),
(121, 114),
(121, 115),
(121, 116),
(121, 117),
(121, 118),
(121, 119),
(121, 120),
(121, 121),
(121, 122),
(121, 123),
(121, 124),
(121, 125),
(121, 126),
(121, 127),
(121, 128),
(121, 129),
(121, 130),
(121, 132),
(121, 133),
(121, 134),
(121, 135),
(121, 136),
(121, 140),
(121, 141),
(121, 142),
(121, 143),
(121, 144),
(121, 150),
(121, 151),
(121, 152),
(121, 153),
(121, 154),
(121, 155),
(121, 171),
(121, 172),
(121, 173),
(121, 174),
(121, 175),
(121, 176),
(121, 177),
(121, 178),
(121, 198),
(121, 199),
(121, 200),
(121, 201),
(121, 202),
(121, 203),
(121, 204),
(121, 205),
(121, 206),
(121, 207),
(121, 208),
(121, 209),
(121, 210),
(121, 211),
(121, 212),
(121, 213),
(121, 214),
(121, 215),
(121, 216),
(121, 217),
(121, 218),
(121, 219),
(121, 220),
(121, 221),
(121, 222),
(121, 223),
(121, 224),
(121, 225),
(121, 226),
(121, 227),
(121, 228),
(121, 229),
(121, 230),
(121, 231),
(121, 232),
(121, 233),
(121, 234),
(121, 235),
(121, 236),
(121, 237),
(121, 238),
(122, 101),
(123, 101),
(124, 101),
(125, 101),
(126, 101),
(127, 101),
(127, 102),
(127, 103),
(127, 104),
(127, 105),
(127, 106),
(127, 107),
(127, 108),
(127, 109),
(127, 110),
(127, 111),
(127, 112),
(127, 113),
(127, 114),
(127, 115),
(127, 116),
(127, 117),
(127, 118),
(127, 119),
(127, 120),
(127, 121),
(127, 122),
(127, 123),
(127, 124),
(127, 125),
(127, 126),
(127, 127),
(127, 128),
(127, 129),
(127, 130),
(127, 132),
(127, 133),
(127, 134),
(127, 135),
(127, 136),
(127, 140),
(127, 141),
(127, 142),
(127, 143),
(127, 144),
(127, 150),
(127, 151),
(127, 152),
(127, 153),
(127, 154),
(127, 155),
(127, 171),
(127, 172),
(127, 173),
(127, 174),
(127, 175),
(127, 176),
(127, 177),
(127, 178),
(127, 198),
(127, 199),
(127, 200),
(127, 201),
(127, 202),
(127, 203),
(127, 204),
(127, 205),
(127, 206),
(127, 207),
(127, 208),
(127, 209),
(127, 210),
(127, 211),
(127, 212),
(127, 213),
(127, 214),
(127, 215),
(127, 216),
(127, 217),
(127, 218),
(127, 219),
(127, 220),
(127, 221),
(127, 222),
(127, 223),
(127, 224),
(127, 225),
(127, 226),
(127, 227),
(127, 228),
(127, 229),
(127, 230),
(127, 231),
(127, 232),
(127, 233),
(127, 234),
(127, 235),
(127, 236),
(127, 237),
(127, 238);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_newsfeeds`
--

CREATE TABLE IF NOT EXISTS `zjw8d_newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
`id` int(10) unsigned NOT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `link` varchar(200) NOT NULL DEFAULT '',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(10) unsigned NOT NULL DEFAULT '1',
  `cache_time` int(10) unsigned NOT NULL DEFAULT '3600',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rtl` tinyint(4) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `description` text NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `images` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_overrider`
--

CREATE TABLE IF NOT EXISTS `zjw8d_overrider` (
`id` int(10) NOT NULL COMMENT 'Primary Key',
  `constant` varchar(255) NOT NULL,
  `string` text NOT NULL,
  `file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_postinstall_messages`
--

CREATE TABLE IF NOT EXISTS `zjw8d_postinstall_messages` (
`postinstall_message_id` bigint(20) unsigned NOT NULL,
  `extension_id` bigint(20) NOT NULL DEFAULT '700' COMMENT 'FK to #__extensions',
  `title_key` varchar(255) NOT NULL DEFAULT '' COMMENT 'Lang key for the title',
  `description_key` varchar(255) NOT NULL DEFAULT '' COMMENT 'Lang key for description',
  `action_key` varchar(255) NOT NULL DEFAULT '',
  `language_extension` varchar(255) NOT NULL DEFAULT 'com_postinstall' COMMENT 'Extension holding lang keys',
  `language_client_id` tinyint(3) NOT NULL DEFAULT '1',
  `type` varchar(10) NOT NULL DEFAULT 'link' COMMENT 'Message type - message, link, action',
  `action_file` varchar(255) DEFAULT '' COMMENT 'RAD URI to the PHP file containing action method',
  `action` varchar(255) DEFAULT '' COMMENT 'Action method name or URL',
  `condition_file` varchar(255) DEFAULT NULL COMMENT 'RAD URI to file holding display condition method',
  `condition_method` varchar(255) DEFAULT NULL COMMENT 'Display condition method, must return boolean',
  `version_introduced` varchar(50) NOT NULL DEFAULT '3.2.0' COMMENT 'Version when this message was introduced',
  `enabled` tinyint(3) NOT NULL DEFAULT '1'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `zjw8d_postinstall_messages`
--

INSERT INTO `zjw8d_postinstall_messages` (`postinstall_message_id`, `extension_id`, `title_key`, `description_key`, `action_key`, `language_extension`, `language_client_id`, `type`, `action_file`, `action`, `condition_file`, `condition_method`, `version_introduced`, `enabled`) VALUES
(1, 700, 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_TITLE', 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_BODY', 'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_ACTION', 'plg_twofactorauth_totp', 1, 'action', 'site://plugins/twofactorauth/totp/postinstall/actions.php', 'twofactorauth_postinstall_action', 'site://plugins/twofactorauth/totp/postinstall/actions.php', 'twofactorauth_postinstall_condition', '3.2.0', 1),
(2, 700, 'COM_CPANEL_MSG_EACCELERATOR_TITLE', 'COM_CPANEL_MSG_EACCELERATOR_BODY', 'COM_CPANEL_MSG_EACCELERATOR_BUTTON', 'com_cpanel', 1, 'action', 'admin://components/com_admin/postinstall/eaccelerator.php', 'admin_postinstall_eaccelerator_action', 'admin://components/com_admin/postinstall/eaccelerator.php', 'admin_postinstall_eaccelerator_condition', '3.2.0', 1),
(3, 700, 'COM_CPANEL_WELCOME_BEGINNERS_TITLE', 'COM_CPANEL_WELCOME_BEGINNERS_MESSAGE', '', 'com_cpanel', 1, 'message', '', '', '', '', '3.2.0', 1),
(4, 700, 'COM_CPANEL_MSG_PHPVERSION_TITLE', 'COM_CPANEL_MSG_PHPVERSION_BODY', '', 'com_cpanel', 1, 'message', '', '', 'admin://components/com_admin/postinstall/phpversion.php', 'admin_postinstall_phpversion_condition', '3.2.2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_redirect_links`
--

CREATE TABLE IF NOT EXISTS `zjw8d_redirect_links` (
`id` int(10) unsigned NOT NULL,
  `old_url` varchar(255) NOT NULL,
  `new_url` varchar(255) NOT NULL,
  `referer` varchar(150) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(4) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `zjw8d_redirect_links`
--

INSERT INTO `zjw8d_redirect_links` (`id`, `old_url`, `new_url`, `referer`, `comment`, `hits`, `published`, `created_date`, `modified_date`) VALUES
(1, 'http://localhost/epubviet/one/index.php?Itemid=111', '', 'http://localhost/epubviet/one/index.php?option=com_content&view=article&id=5&Itemid=116', '', 5, 0, '2014-09-18 22:33:46', '0000-00-00 00:00:00'),
(2, 'http://localhost/epubviet/one/index.php/sach-tuoi-hoa', '', '', '', 1, 0, '2014-09-20 03:45:18', '0000-00-00 00:00:00'),
(3, 'http://localhost/epubviet/one/index.php/widgetkit/twitter', '', '', '', 1, 0, '2014-09-22 15:21:23', '0000-00-00 00:00:00'),
(4, 'http://localhost/epubviet/one/index.php/sach-vien-tuong-than-thoai/vien-tuong/item/harry-potter-va-hon-da-phu-thuy-j-k-rowling', '', 'http://localhost/epubviet/one/index.php/sach-truyen', '', 1, 0, '2014-09-30 09:44:14', '0000-00-00 00:00:00'),
(5, 'http://localhost/epubviet/one/index.php/sach-vien-tuong-than-thoai/vien-tuong/item/', '', 'http://localhost/epubviet/one/index.php/sach-vien-tuong-than-thoai/vien-tuong/item/harry-potter-va-hoi-phuong-hoang', '', 10, 0, '2014-10-09 16:21:40', '0000-00-00 00:00:00'),
(6, 'http://localhost/epubviet/one/index.php/sach-vien-tuong-than-thoai/vien-tuong/item/harry-potter', '', '', '', 5, 0, '2014-10-14 11:39:40', '0000-00-00 00:00:00'),
(7, 'http://localhost/epubviet/one/index.php/sach-truyen', '', 'http://localhost/epubviet/one/index.php/van-hoa-doc-reading-culture', '', 1, 0, '2014-10-14 21:53:59', '0000-00-00 00:00:00'),
(8, 'http://localhost/epubviet/one/index.php/sach-vien-tuong-than-thoai/vien-tuong/item/harry-potter-va-hoi-phuong-hoang', '', 'http://localhost/epubviet/one/', '', 2, 0, '2014-10-14 22:23:28', '0000-00-00 00:00:00'),
(9, 'http://localhost/epubviet/one/index.php/sach-truyen-works/alphaindex/', '', 'http://localhost/epubviet/one/index.php/sach-truyen-works/alphaindex/j', '', 3, 0, '2014-10-14 23:01:00', '0000-00-00 00:00:00'),
(10, 'http://localhost/epubviet/one/sach-vien-tuong-than-thoai/vien-tuong/item/', '', 'http://localhost/epubviet/one/sach-vien-tuong-than-thoai/vien-tuong/item/harry-potter-va-bao-boi-tu-than', '', 9, 0, '2014-10-17 14:15:08', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_schemas`
--

CREATE TABLE IF NOT EXISTS `zjw8d_schemas` (
  `extension_id` int(11) NOT NULL,
  `version_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_schemas`
--

INSERT INTO `zjw8d_schemas` (`extension_id`, `version_id`) VALUES
(700, '3.3.0-2014-04-02');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_session`
--

CREATE TABLE IF NOT EXISTS `zjw8d_session` (
  `session_id` varchar(200) NOT NULL DEFAULT '',
  `client_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guest` tinyint(4) unsigned DEFAULT '1',
  `time` varchar(14) DEFAULT '',
  `data` mediumtext,
  `userid` int(11) DEFAULT '0',
  `username` varchar(150) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_session`
--

INSERT INTO `zjw8d_session` (`session_id`, `client_id`, `guest`, `time`, `data`, `userid`, `username`) VALUES
('gs8e358vupb05jgigtbuv1cmt5', 1, 0, '1413591815', '__default|a:8:{s:15:"session.counter";i:96;s:19:"session.timer.start";i:1413583994;s:18:"session.timer.last";i:1413591793;s:17:"session.timer.now";i:1413591813;s:22:"session.client.browser";s:72:"Mozilla/5.0 (Windows NT 6.3; WOW64; rv:34.0) Gecko/20100101 Firefox/34.0";s:8:"registry";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":5:{s:11:"application";O:8:"stdClass":1:{s:4:"lang";s:0:"";}s:13:"com_installer";O:8:"stdClass":2:{s:7:"message";s:0:"";s:17:"extension_message";s:0:"";}s:11:"com_modules";O:8:"stdClass":3:{s:7:"modules";O:8:"stdClass":4:{s:6:"filter";O:8:"stdClass":8:{s:18:"client_id_previous";i:0;s:6:"search";s:0:"";s:6:"access";i:0;s:5:"state";s:1:"1";s:8:"position";s:0:"";s:6:"module";s:0:"";s:9:"client_id";i:0;s:8:"language";s:0:"";}s:8:"ordercol";s:8:"position";s:9:"orderdirn";s:3:"asc";s:10:"limitstart";i:0;}s:4:"edit";O:8:"stdClass":1:{s:6:"module";O:8:"stdClass":2:{s:2:"id";a:0:{}s:4:"data";N;}}s:3:"add";O:8:"stdClass":1:{s:6:"module";O:8:"stdClass":2:{s:12:"extension_id";N;s:6:"params";N;}}}s:6:"global";O:8:"stdClass":1:{s:4:"list";O:8:"stdClass":1:{s:5:"limit";i:20;}}s:10:"com_config";O:8:"stdClass":1:{s:6:"config";O:8:"stdClass":1:{s:6:"global";O:8:"stdClass":1:{s:4:"data";a:85:{s:7:"offline";s:1:"0";s:15:"offline_message";s:70:"This site is down for maintenance.<br /> Please check back again soon.";s:23:"display_offline_message";s:1:"1";s:13:"offline_image";s:0:"";s:8:"sitename";s:65:"Thư viện ePub Việt ~ Thư viện sách của người Việt";s:6:"editor";s:4:"none";s:7:"captcha";s:1:"0";s:10:"list_limit";s:2:"20";s:6:"access";s:1:"1";s:5:"debug";s:1:"0";s:10:"debug_lang";s:1:"0";s:6:"dbtype";s:5:"mysql";s:4:"host";s:9:"localhost";s:4:"user";s:4:"root";s:8:"password";s:4:"root";s:2:"db";s:10:"epw_sphere";s:8:"dbprefix";s:6:"zjw8d_";s:9:"live_site";s:0:"";s:6:"secret";s:16:"OM35nsZkF1sNmw9I";s:4:"gzip";s:1:"1";s:15:"error_reporting";s:4:"none";s:7:"helpurl";s:89:"http://help.joomla.org/proxy/index.php?option=com_help&keyref=Help{major}{minor}:{keyref}";s:8:"ftp_host";s:0:"";s:8:"ftp_port";s:0:"";s:8:"ftp_user";s:5:"admin";s:8:"ftp_pass";s:5:"admin";s:8:"ftp_root";s:0:"";s:10:"ftp_enable";s:1:"0";s:6:"offset";s:16:"Asia/Ho_Chi_Minh";s:10:"mailonline";s:1:"1";s:6:"mailer";s:4:"smtp";s:8:"mailfrom";s:26:"contact.epubviet@gmail.com";s:8:"fromname";s:16:"ePubViet Library";s:8:"sendmail";s:18:"/usr/sbin/sendmail";s:8:"smtpauth";s:1:"1";s:8:"smtpuser";s:26:"contact.epubviet@gmail.com";s:8:"smtppass";s:12:"69AKhuDongY@";s:8:"smtphost";s:14:"smtp.gmail.com";s:10:"smtpsecure";s:3:"ssl";s:8:"smtpport";s:3:"465";s:7:"caching";s:1:"0";s:13:"cache_handler";s:4:"file";s:9:"cachetime";s:2:"15";s:8:"MetaDesc";s:223:"Chuyên chia sẻ các sách điện tử định dạng epub hỗ trợ đa nền tảng: máy đọc sách (eReader), máy tính (computer), điện thoại di động (smartphone), máy tính bảng (tablet, phablet),...";s:8:"MetaKeys";s:393:"epub, epub việt, epub việt nam, epub ebook tiếng việt, sách tiếng việt epub, epub tiếng việt, truyện việt epub, sách việt epub, epub truyện tiếng việt, epub tiếng việt ipad, epub tiếng việt iphone, epub ibooks, sách di động, sách cho điện thoại, sách cho máy tính bảng, sách cho máy đọc sách, sách điện tử, sách truyện, ebook";s:9:"MetaTitle";s:1:"1";s:10:"MetaAuthor";s:1:"1";s:11:"MetaVersion";s:1:"0";s:6:"robots";s:0:"";s:3:"sef";s:1:"1";s:11:"sef_rewrite";s:1:"1";s:10:"sef_suffix";s:1:"0";s:12:"unicodeslugs";s:1:"1";s:10:"feed_limit";s:2:"10";s:8:"log_path";s:24:"D:\\www\\epubviet\\one/logs";s:8:"tmp_path";s:23:"D:\\www\\epubviet\\one/tmp";s:8:"lifetime";s:3:"150";s:15:"session_handler";s:8:"database";s:16:"memcache_persist";s:1:"1";s:17:"memcache_compress";s:1:"0";s:20:"memcache_server_host";s:9:"localhost";s:20:"memcache_server_port";s:5:"11211";s:17:"memcached_persist";s:1:"1";s:18:"memcached_compress";s:1:"0";s:21:"memcached_server_host";s:9:"localhost";s:21:"memcached_server_port";s:5:"11211";s:12:"proxy_enable";s:1:"0";s:10:"proxy_host";s:0:"";s:10:"proxy_port";s:0:"";s:10:"proxy_user";s:0:"";s:10:"proxy_pass";s:0:"";s:10:"MetaRights";s:75:"©2010-2014 Nội dung độc quyền thuộc về Thư viện ePub Việt.";s:19:"sitename_pagetitles";s:1:"1";s:9:"force_ssl";s:1:"0";s:28:"session_memcache_server_host";s:9:"localhost";s:28:"session_memcache_server_port";s:5:"11211";s:29:"session_memcached_server_host";s:9:"localhost";s:29:"session_memcached_server_port";s:5:"11211";s:12:"frontediting";s:1:"1";s:10:"feed_email";s:6:"author";s:13:"cookie_domain";s:0:"";s:11:"cookie_path";s:0:"";s:8:"asset_id";i:1;s:7:"filters";a:9:{i:1;a:3:{s:11:"filter_type";s:2:"BL";s:11:"filter_tags";s:0:"";s:17:"filter_attributes";s:0:"";}i:9;a:3:{s:11:"filter_type";s:2:"BL";s:11:"filter_tags";s:0:"";s:17:"filter_attributes";s:0:"";}i:6;a:3:{s:11:"filter_type";s:2:"BL";s:11:"filter_tags";s:0:"";s:17:"filter_attributes";s:0:"";}i:7;a:3:{s:11:"filter_type";s:2:"BL";s:11:"filter_tags";s:0:"";s:17:"filter_attributes";s:0:"";}i:2;a:3:{s:11:"filter_type";s:2:"BL";s:11:"filter_tags";s:0:"";s:17:"filter_attributes";s:0:"";}i:3;a:3:{s:11:"filter_type";s:2:"BL";s:11:"filter_tags";s:0:"";s:17:"filter_attributes";s:0:"";}i:4;a:3:{s:11:"filter_type";s:2:"BL";s:11:"filter_tags";s:0:"";s:17:"filter_attributes";s:0:"";}i:5;a:3:{s:11:"filter_type";s:2:"BL";s:11:"filter_tags";s:0:"";s:17:"filter_attributes";s:0:"";}i:8;a:3:{s:11:"filter_type";s:4:"NONE";s:11:"filter_tags";s:0:"";s:17:"filter_attributes";s:0:"";}}s:5:"rules";a:10:{s:15:"core.login.site";a:9:{i:1;s:0:"";i:9;s:0:"";i:6;s:1:"1";i:7;s:0:"";i:2;s:1:"1";i:3;s:0:"";i:4;s:0:"";i:5;s:0:"";i:8;s:0:"";}s:16:"core.login.admin";a:9:{i:1;s:0:"";i:9;s:0:"";i:6;s:1:"1";i:7;s:0:"";i:2;s:0:"";i:3;s:0:"";i:4;s:0:"";i:5;s:0:"";i:8;s:0:"";}s:18:"core.login.offline";a:9:{i:1;s:0:"";i:9;s:0:"";i:6;s:0:"";i:7;s:0:"";i:2;s:0:"";i:3;s:0:"";i:4;s:0:"";i:5;s:0:"";i:8;s:0:"";}s:10:"core.admin";a:9:{i:1;s:0:"";i:9;s:0:"";i:6;s:0:"";i:7;s:0:"";i:2;s:0:"";i:3;s:0:"";i:4;s:0:"";i:5;s:0:"";i:8;s:1:"1";}s:11:"core.manage";a:9:{i:1;s:0:"";i:9;s:0:"";i:6;s:0:"";i:7;s:1:"1";i:2;s:0:"";i:3;s:0:"";i:4;s:0:"";i:5;s:0:"";i:8;s:0:"";}s:11:"core.create";a:9:{i:1;s:0:"";i:9;s:0:"";i:6;s:1:"1";i:7;s:0:"";i:2;s:0:"";i:3;s:1:"1";i:4;s:0:"";i:5;s:0:"";i:8;s:0:"";}s:11:"core.delete";a:9:{i:1;s:0:"";i:9;s:0:"";i:6;s:1:"1";i:7;s:0:"";i:2;s:0:"";i:3;s:0:"";i:4;s:0:"";i:5;s:0:"";i:8;s:0:"";}s:9:"core.edit";a:9:{i:1;s:0:"";i:9;s:0:"";i:6;s:1:"1";i:7;s:0:"";i:2;s:0:"";i:3;s:0:"";i:4;s:1:"1";i:5;s:0:"";i:8;s:0:"";}s:15:"core.edit.state";a:9:{i:1;s:0:"";i:9;s:0:"";i:6;s:1:"1";i:7;s:0:"";i:2;s:0:"";i:3;s:0:"";i:4;s:0:"";i:5;s:1:"1";i:8;s:0:"";}s:13:"core.edit.own";a:9:{i:1;s:0:"";i:9;s:0:"";i:6;s:1:"1";i:7;s:0:"";i:2;s:0:"";i:3;s:1:"1";i:4;s:0:"";i:5;s:0:"";i:8;s:0:"";}}}}}}}}s:4:"user";O:5:"JUser":28:{s:9:"\\0\\0\\0isRoot";b:1;s:2:"id";s:3:"585";s:4:"name";s:23:"Thư viện ePub Việt";s:8:"username";s:5:"admin";s:5:"email";s:18:"epubviet@gmail.com";s:8:"password";s:60:"$2y$10$rEVDLxK16TbgKohTwPpR6uVzk1s1g4nPGh0Y7lZhIa87TwHNhQb1u";s:14:"password_clear";s:0:"";s:5:"block";s:1:"0";s:9:"sendEmail";s:1:"0";s:12:"registerDate";s:19:"2014-09-18 03:23:25";s:13:"lastvisitDate";s:19:"2014-10-17 10:46:43";s:10:"activation";s:0:"";s:6:"params";s:109:"{"admin_style":"","admin_language":"","language":"","editor":"","helpsite":"","timezone":"Asia\\/Ho_Chi_Minh"}";s:6:"groups";a:1:{i:8;s:1:"8";}s:5:"guest";i:0;s:13:"lastResetTime";s:19:"0000-00-00 00:00:00";s:10:"resetCount";s:1:"0";s:12:"requireReset";s:1:"0";s:10:"\\0\\0\\0_params";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":6:{s:11:"admin_style";s:0:"";s:14:"admin_language";s:0:"";s:8:"language";s:0:"";s:6:"editor";s:0:"";s:8:"helpsite";s:0:"";s:8:"timezone";s:16:"Asia/Ho_Chi_Minh";}}s:14:"\\0\\0\\0_authGroups";a:2:{i:0;i:1;i:1;i:8;}s:14:"\\0\\0\\0_authLevels";a:5:{i:0;i:1;i:1;i:1;i:2;i:2;i:3;i:3;i:4;i:6;}s:15:"\\0\\0\\0_authActions";N;s:12:"\\0\\0\\0_errorMsg";N;s:10:"\\0\\0\\0_errors";a:0:{}s:3:"aid";i:0;s:6:"otpKey";s:0:"";s:4:"otep";s:0:"";s:10:"superadmin";b:1;}s:13:"session.token";s:32:"9ea721703a13a687ab0a3f47bfff2ffb";}', 585, 'admin'),
('ikqmjnvbn2l2qok92idljj9ub6', 0, 1, '1413591797', '__default|a:9:{s:15:"session.counter";i:174;s:19:"session.timer.start";i:1413456373;s:18:"session.timer.last";i:1413591775;s:17:"session.timer.now";i:1413591796;s:22:"session.client.browser";s:72:"Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0";s:8:"registry";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":1:{s:10:"com_kunena";O:8:"stdClass":2:{s:10:"user0_read";a:82:{i:51;s:2:"51";i:42;s:2:"42";i:79;s:2:"79";i:67;s:2:"67";i:21;s:2:"21";i:8;s:1:"8";i:48;s:2:"48";i:36;s:2:"36";i:14;s:2:"14";i:12;s:2:"12";i:2;s:1:"2";i:24;s:2:"24";i:71;s:2:"71";i:39;s:2:"39";i:64;s:2:"64";i:59;s:2:"59";i:82;s:2:"82";i:1;s:1:"1";i:30;s:2:"30";i:18;s:2:"18";i:33;s:2:"33";i:61;s:2:"61";i:27;s:2:"27";i:40;s:2:"40";i:31;s:2:"31";i:80;s:2:"80";i:7;s:1:"7";i:9;s:1:"9";i:49;s:2:"49";i:34;s:2:"34";i:25;s:2:"25";i:37;s:2:"37";i:22;s:2:"22";i:52;s:2:"52";i:72;s:2:"72";i:43;s:2:"43";i:68;s:2:"68";i:28;s:2:"28";i:3;s:1:"3";i:15;s:2:"15";i:19;s:2:"19";i:65;s:2:"65";i:60;s:2:"60";i:62;s:2:"62";i:53;s:2:"53";i:47;s:2:"47";i:44;s:2:"44";i:66;s:2:"66";i:16;s:2:"16";i:75;s:2:"75";i:6;s:1:"6";i:69;s:2:"69";i:63;s:2:"63";i:50;s:2:"50";i:81;s:2:"81";i:54;s:2:"54";i:45;s:2:"45";i:70;s:2:"70";i:76;s:2:"76";i:4;s:1:"4";i:5;s:1:"5";i:13;s:2:"13";i:78;s:2:"78";i:74;s:2:"74";i:46;s:2:"46";i:17;s:2:"17";i:73;s:2:"73";i:11;s:2:"11";i:77;s:2:"77";i:10;s:2:"10";i:20;s:2:"20";i:23;s:2:"23";i:26;s:2:"26";i:29;s:2:"29";i:32;s:2:"32";i:38;s:2:"38";i:35;s:2:"35";i:41;s:2:"41";i:56;s:2:"56";i:55;s:2:"55";i:57;s:2:"57";i:58;s:2:"58";}s:5:"topic";O:8:"stdClass":1:{s:7:"lasthit";i:1;}}}}s:4:"user";O:5:"JUser":26:{s:9:"\\0\\0\\0isRoot";b:0;s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:5:"block";N;s:9:"sendEmail";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:6:"groups";a:1:{i:0;i:1;}s:5:"guest";i:1;s:13:"lastResetTime";N;s:10:"resetCount";N;s:12:"requireReset";N;s:10:"\\0\\0\\0_params";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":0:{}}s:14:"\\0\\0\\0_authGroups";a:1:{i:0;i:1;}s:14:"\\0\\0\\0_authLevels";a:2:{i:0;i:1;i:1;i:1;}s:15:"\\0\\0\\0_authActions";N;s:12:"\\0\\0\\0_errorMsg";N;s:10:"\\0\\0\\0_errors";a:0:{}s:3:"aid";i:0;s:10:"superadmin";N;}s:13:"session.token";s:32:"ed0104922b064b3f0b62afd8ba401b34";s:23:"com_zoo.comment.content";s:11:"fasasfasfas";}twitter_oauth_token|N;twitter_oauth_token_secret|N;facebook_access_token|N;', 0, ''),
('t8v170c1g4u8qq56i4vgi70625', 0, 1, '1413592947', '__default|a:8:{s:15:"session.counter";i:7;s:19:"session.timer.start";i:1413592826;s:18:"session.timer.last";i:1413592928;s:17:"session.timer.now";i:1413592947;s:22:"session.client.browser";s:72:"Mozilla/5.0 (Windows NT 6.3; WOW64; rv:33.0) Gecko/20100101 Firefox/33.0";s:8:"registry";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":1:{s:10:"com_kunena";O:8:"stdClass":1:{s:10:"user0_read";a:82:{i:51;s:2:"51";i:42;s:2:"42";i:79;s:2:"79";i:67;s:2:"67";i:21;s:2:"21";i:8;s:1:"8";i:48;s:2:"48";i:36;s:2:"36";i:14;s:2:"14";i:12;s:2:"12";i:2;s:1:"2";i:24;s:2:"24";i:71;s:2:"71";i:39;s:2:"39";i:64;s:2:"64";i:59;s:2:"59";i:82;s:2:"82";i:1;s:1:"1";i:30;s:2:"30";i:18;s:2:"18";i:33;s:2:"33";i:61;s:2:"61";i:27;s:2:"27";i:40;s:2:"40";i:31;s:2:"31";i:80;s:2:"80";i:7;s:1:"7";i:9;s:1:"9";i:49;s:2:"49";i:34;s:2:"34";i:25;s:2:"25";i:37;s:2:"37";i:22;s:2:"22";i:52;s:2:"52";i:72;s:2:"72";i:43;s:2:"43";i:68;s:2:"68";i:28;s:2:"28";i:3;s:1:"3";i:15;s:2:"15";i:19;s:2:"19";i:65;s:2:"65";i:60;s:2:"60";i:62;s:2:"62";i:53;s:2:"53";i:47;s:2:"47";i:44;s:2:"44";i:66;s:2:"66";i:16;s:2:"16";i:75;s:2:"75";i:6;s:1:"6";i:69;s:2:"69";i:63;s:2:"63";i:50;s:2:"50";i:81;s:2:"81";i:54;s:2:"54";i:45;s:2:"45";i:70;s:2:"70";i:76;s:2:"76";i:4;s:1:"4";i:5;s:1:"5";i:13;s:2:"13";i:78;s:2:"78";i:74;s:2:"74";i:46;s:2:"46";i:17;s:2:"17";i:73;s:2:"73";i:11;s:2:"11";i:77;s:2:"77";i:10;s:2:"10";i:20;s:2:"20";i:23;s:2:"23";i:26;s:2:"26";i:29;s:2:"29";i:32;s:2:"32";i:38;s:2:"38";i:35;s:2:"35";i:41;s:2:"41";i:56;s:2:"56";i:55;s:2:"55";i:57;s:2:"57";i:58;s:2:"58";}}}}s:4:"user";O:5:"JUser":26:{s:9:"\\0\\0\\0isRoot";b:0;s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:5:"block";N;s:9:"sendEmail";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:6:"groups";a:1:{i:0;i:1;}s:5:"guest";i:1;s:13:"lastResetTime";N;s:10:"resetCount";N;s:12:"requireReset";N;s:10:"\\0\\0\\0_params";O:9:"JRegistry":1:{s:7:"\\0\\0\\0data";O:8:"stdClass":0:{}}s:14:"\\0\\0\\0_authGroups";a:1:{i:0;i:1;}s:14:"\\0\\0\\0_authLevels";a:2:{i:0;i:1;i:1;i:1;}s:15:"\\0\\0\\0_authActions";N;s:12:"\\0\\0\\0_errorMsg";N;s:10:"\\0\\0\\0_errors";a:0:{}s:3:"aid";i:0;s:10:"superadmin";N;}s:13:"session.token";s:32:"4a35ce02e732f1429989c10d09005a20";}twitter_oauth_token|N;twitter_oauth_token_secret|N;facebook_access_token|N;', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_sh404sef_aliases`
--

CREATE TABLE IF NOT EXISTS `zjw8d_sh404sef_aliases` (
`id` int(11) NOT NULL,
  `newurl` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(3) NOT NULL DEFAULT '0',
  `hits` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_sh404sef_metas`
--

CREATE TABLE IF NOT EXISTS `zjw8d_sh404sef_metas` (
`id` int(11) NOT NULL,
  `newurl` varchar(255) NOT NULL DEFAULT '',
  `metadesc` varchar(255) DEFAULT '',
  `metakey` varchar(255) DEFAULT '',
  `metatitle` varchar(255) DEFAULT '',
  `metalang` varchar(30) DEFAULT '',
  `metarobots` varchar(30) DEFAULT '',
  `canonical` varchar(255) DEFAULT '',
  `og_enable` tinyint(3) NOT NULL DEFAULT '2',
  `og_type` varchar(30) DEFAULT '',
  `og_image` varchar(255) DEFAULT '',
  `og_enable_description` tinyint(3) NOT NULL DEFAULT '2',
  `og_enable_site_name` tinyint(3) NOT NULL DEFAULT '2',
  `og_site_name` varchar(255) DEFAULT '',
  `fb_admin_ids` varchar(255) DEFAULT '',
  `og_enable_location` tinyint(3) NOT NULL DEFAULT '2',
  `og_latitude` varchar(30) DEFAULT '',
  `og_longitude` varchar(30) DEFAULT '',
  `og_street_address` varchar(255) DEFAULT '',
  `og_locality` varchar(255) DEFAULT '',
  `og_postal_code` varchar(30) DEFAULT '',
  `og_region` varchar(255) DEFAULT '',
  `og_country_name` varchar(255) DEFAULT '',
  `og_enable_contact` tinyint(3) NOT NULL DEFAULT '2',
  `og_email` varchar(255) DEFAULT '',
  `og_phone_number` varchar(255) DEFAULT '',
  `og_fax_number` varchar(255) DEFAULT '',
  `og_enable_fb_admin_ids` tinyint(3) NOT NULL DEFAULT '2',
  `twittercards_enable` tinyint(3) NOT NULL DEFAULT '2',
  `twittercards_site_account` varchar(100) DEFAULT '',
  `twittercards_creator_account` varchar(100) DEFAULT '',
  `google_authorship_enable` tinyint(3) NOT NULL DEFAULT '2',
  `google_authorship_author_profile` varchar(255) DEFAULT '',
  `google_authorship_author_name` varchar(255) DEFAULT '',
  `google_publisher_enable` tinyint(3) NOT NULL DEFAULT '2',
  `google_publisher_url` varchar(255) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_sh404sef_pageids`
--

CREATE TABLE IF NOT EXISTS `zjw8d_sh404sef_pageids` (
`id` int(11) NOT NULL,
  `newurl` varchar(255) NOT NULL DEFAULT '',
  `pageid` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(3) NOT NULL DEFAULT '0',
  `hits` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_sh404sef_urls`
--

CREATE TABLE IF NOT EXISTS `zjw8d_sh404sef_urls` (
`id` int(11) NOT NULL,
  `cpt` int(11) NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0',
  `oldurl` varchar(255) NOT NULL DEFAULT '',
  `newurl` varchar(255) NOT NULL DEFAULT '',
  `dateadd` date NOT NULL DEFAULT '0000-00-00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_shlib_consumers`
--

CREATE TABLE IF NOT EXISTS `zjw8d_shlib_consumers` (
`id` int(10) unsigned NOT NULL,
  `resource` varchar(50) NOT NULL DEFAULT '',
  `context` varchar(50) NOT NULL DEFAULT '',
  `min_version` varchar(20) NOT NULL DEFAULT '0',
  `max_version` varchar(20) NOT NULL DEFAULT '0',
  `refuse_versions` varchar(255) NOT NULL DEFAULT '',
  `accept_versions` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `zjw8d_shlib_consumers`
--

INSERT INTO `zjw8d_shlib_consumers` (`id`, `resource`, `context`, `min_version`, `max_version`, `refuse_versions`, `accept_versions`) VALUES
(1, 'shlib', 'com_sh404sef', '0.2.0', '0', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_shlib_resources`
--

CREATE TABLE IF NOT EXISTS `zjw8d_shlib_resources` (
`id` int(10) unsigned NOT NULL,
  `resource` varchar(50) NOT NULL DEFAULT '',
  `current_version` varchar(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `zjw8d_shlib_resources`
--

INSERT INTO `zjw8d_shlib_resources` (`id`, `resource`, `current_version`) VALUES
(1, 'shlib', '0.2.9.370');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_tags`
--

CREATE TABLE IF NOT EXISTS `zjw8d_tags` (
`id` int(10) unsigned NOT NULL,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `note` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `metadesc` varchar(1024) NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `zjw8d_tags`
--

INSERT INTO `zjw8d_tags` (`id`, `parent_id`, `lft`, `rgt`, `level`, `path`, `title`, `alias`, `note`, `description`, `published`, `checked_out`, `checked_out_time`, `access`, `params`, `metadesc`, `metakey`, `metadata`, `created_user_id`, `created_time`, `created_by_alias`, `modified_user_id`, `modified_time`, `images`, `urls`, `hits`, `language`, `version`, `publish_up`, `publish_down`) VALUES
(1, 0, 0, 1, 0, '', 'ROOT', 'root', '', '', 1, 0, '0000-00-00 00:00:00', 1, '', '', '', '', 0, '2011-01-01 00:00:01', '', 0, '0000-00-00 00:00:00', '', '', 0, '*', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_template_styles`
--

CREATE TABLE IF NOT EXISTS `zjw8d_template_styles` (
`id` int(10) unsigned NOT NULL,
  `template` varchar(50) NOT NULL DEFAULT '',
  `client_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `home` char(7) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `params` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `zjw8d_template_styles`
--

INSERT INTO `zjw8d_template_styles` (`id`, `template`, `client_id`, `home`, `title`, `params`) VALUES
(3, 'atomic', 0, '0', 'Atomic - Default', '{}'),
(6, 'beez5', 0, '0', 'Beez5 - Default-Fruit Shop', '{"wrapperSmall":"53","wrapperLarge":"72","logo":"images\\/sampledata\\/fruitshop\\/fruits.gif","sitetitle":"Matuna Market ","sitedescription":"Fruit Shop Sample Site","navposition":"left","html5":"0"}'),
(7, 'yoo_sphere', 0, '1', 'yoo_sphere - Default', '{"config":""}'),
(8, 'protostar', 0, '0', 'protostar - Default', '{"templateColor":"","logoFile":"","googleFont":"1","googleFontName":"Open+Sans","fluidContainer":"0"}'),
(9, 'isis', 1, '1', 'isis - Default', '{"templateColor":"","logoFile":""}');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_ucm_base`
--

CREATE TABLE IF NOT EXISTS `zjw8d_ucm_base` (
  `ucm_id` int(10) unsigned NOT NULL,
  `ucm_item_id` int(10) NOT NULL,
  `ucm_type_id` int(11) NOT NULL,
  `ucm_language_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_ucm_content`
--

CREATE TABLE IF NOT EXISTS `zjw8d_ucm_content` (
`core_content_id` int(10) unsigned NOT NULL,
  `core_type_alias` varchar(255) NOT NULL DEFAULT '' COMMENT 'FK to the content types table',
  `core_title` varchar(255) NOT NULL,
  `core_alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `core_body` mediumtext NOT NULL,
  `core_state` tinyint(1) NOT NULL DEFAULT '0',
  `core_checked_out_time` varchar(255) NOT NULL DEFAULT '',
  `core_checked_out_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_access` int(10) unsigned NOT NULL DEFAULT '0',
  `core_params` text NOT NULL,
  `core_featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `core_metadata` varchar(2048) NOT NULL COMMENT 'JSON encoded metadata properties.',
  `core_created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `core_created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_modified_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Most recent user that modified',
  `core_modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_language` char(7) NOT NULL,
  `core_publish_up` datetime NOT NULL,
  `core_publish_down` datetime NOT NULL,
  `core_content_item_id` int(10) unsigned DEFAULT NULL COMMENT 'ID from the individual type table',
  `asset_id` int(10) unsigned DEFAULT NULL COMMENT 'FK to the #__assets table.',
  `core_images` text NOT NULL,
  `core_urls` text NOT NULL,
  `core_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `core_version` int(10) unsigned NOT NULL DEFAULT '1',
  `core_ordering` int(11) NOT NULL DEFAULT '0',
  `core_metakey` text NOT NULL,
  `core_metadesc` text NOT NULL,
  `core_catid` int(10) unsigned NOT NULL DEFAULT '0',
  `core_xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `core_type_id` int(10) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Contains core content data in name spaced fields' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_ucm_history`
--

CREATE TABLE IF NOT EXISTS `zjw8d_ucm_history` (
`version_id` int(10) unsigned NOT NULL,
  `ucm_item_id` int(10) unsigned NOT NULL,
  `ucm_type_id` int(10) unsigned NOT NULL,
  `version_note` varchar(255) NOT NULL DEFAULT '' COMMENT 'Optional version name',
  `save_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `character_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Number of characters in this version.',
  `sha1_hash` varchar(50) NOT NULL DEFAULT '' COMMENT 'SHA1 hash of the version_data column.',
  `version_data` mediumtext NOT NULL COMMENT 'json-encoded string of version data',
  `keep_forever` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=auto delete; 1=keep'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_updates`
--

CREATE TABLE IF NOT EXISTS `zjw8d_updates` (
`update_id` int(11) NOT NULL,
  `update_site_id` int(11) DEFAULT '0',
  `extension_id` int(11) DEFAULT '0',
  `name` varchar(100) DEFAULT '',
  `description` text NOT NULL,
  `element` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `folder` varchar(20) DEFAULT '',
  `client_id` tinyint(3) DEFAULT '0',
  `version` varchar(32) DEFAULT '',
  `data` text NOT NULL,
  `detailsurl` text NOT NULL,
  `infourl` text NOT NULL,
  `extra_query` varchar(1000) DEFAULT ''
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Available Updates' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `zjw8d_updates`
--

INSERT INTO `zjw8d_updates` (`update_id`, `update_site_id`, `extension_id`, `name`, `description`, `element`, `type`, `folder`, `client_id`, `version`, `data`, `detailsurl`, `infourl`, `extra_query`) VALUES
(1, 1, 700, 'Joomla', '', 'joomla', 'file', '', 0, '3.3.6', '', 'http://update.joomla.org/core/sts/extension_sts.xml', '', ''),
(2, 1, 700, 'Joomla', '', 'joomla', 'file', '', 0, '3.3.6', '', 'http://update.joomla.org/core/sts/extension_sts.xml', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_update_sites`
--

CREATE TABLE IF NOT EXISTS `zjw8d_update_sites` (
`update_site_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT '',
  `type` varchar(20) DEFAULT '',
  `location` text NOT NULL,
  `enabled` int(11) DEFAULT '0',
  `last_check_timestamp` bigint(20) DEFAULT '0',
  `extra_query` varchar(1000) DEFAULT ''
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='Update Sites' AUTO_INCREMENT=7 ;

--
-- Dumping data for table `zjw8d_update_sites`
--

INSERT INTO `zjw8d_update_sites` (`update_site_id`, `name`, `type`, `location`, `enabled`, `last_check_timestamp`, `extra_query`) VALUES
(1, 'Joomla Core', 'collection', 'http://update.joomla.org/core/sts/list_sts.xml', 1, 1413591795, ''),
(2, 'Joomla Extension Directory', 'collection', 'http://update.joomla.org/jed/list.xml', 1, 1413591795, ''),
(3, 'Accredited Joomla! Translations', 'collection', 'http://update.joomla.org/language/translationlist_3.xml', 0, 0, ''),
(4, 'Tquotes', 'extension', 'http://mytidbits.us/joomla173/updateserver/tquotes-update.xml', 1, 1413591794, ''),
(5, 'CMC Updates', 'extension', 'https://compojoom.com/index.php?option=com_ars&view=update&task=stream&format=xml&id=13&dummy=extension.xml', 0, 0, ''),
(6, 'Kunena 3.0 Update Site', 'collection', 'http://update.kunena.org/3.0/list.xml', 1, 1413591794, '');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_update_sites_extensions`
--

CREATE TABLE IF NOT EXISTS `zjw8d_update_sites_extensions` (
  `update_site_id` int(11) NOT NULL DEFAULT '0',
  `extension_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Links extensions to update sites';

--
-- Dumping data for table `zjw8d_update_sites_extensions`
--

INSERT INTO `zjw8d_update_sites_extensions` (`update_site_id`, `extension_id`) VALUES
(1, 700),
(2, 700),
(3, 600),
(3, 10056),
(4, 10059),
(5, 10060),
(6, 10078);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_usergroups`
--

CREATE TABLE IF NOT EXISTS `zjw8d_usergroups` (
`id` int(10) unsigned NOT NULL COMMENT 'Primary Key',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Adjacency List Reference Id',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `title` varchar(100) NOT NULL DEFAULT ''
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `zjw8d_usergroups`
--

INSERT INTO `zjw8d_usergroups` (`id`, `parent_id`, `lft`, `rgt`, `title`) VALUES
(1, 0, 1, 18, 'Public'),
(2, 1, 8, 15, 'Registered'),
(3, 2, 9, 14, 'Author'),
(4, 3, 10, 13, 'Editor'),
(5, 4, 11, 12, 'Publisher'),
(6, 1, 4, 7, 'Manager'),
(7, 6, 5, 6, 'Administrator'),
(8, 1, 16, 17, 'Super Users'),
(9, 1, 2, 3, 'Guest');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_users`
--

CREATE TABLE IF NOT EXISTS `zjw8d_users` (
`id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  `lastResetTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date of last password reset',
  `resetCount` int(11) NOT NULL DEFAULT '0' COMMENT 'Count of password resets since lastResetTime',
  `otpKey` varchar(1000) NOT NULL DEFAULT '' COMMENT 'Two factor authentication encrypted keys',
  `otep` varchar(1000) NOT NULL DEFAULT '' COMMENT 'One time emergency passwords',
  `requireReset` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Require user to reset password on next login'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=586 ;

--
-- Dumping data for table `zjw8d_users`
--

INSERT INTO `zjw8d_users` (`id`, `name`, `username`, `email`, `password`, `block`, `sendEmail`, `registerDate`, `lastvisitDate`, `activation`, `params`, `lastResetTime`, `resetCount`, `otpKey`, `otep`, `requireReset`) VALUES
(584, 'Super User', 'administrator', 'admin@mail.com', '$2y$10$iZOZa3IgF44AL.uhxstklOJkouFkLjJlF6Fj3OHxJnVhEbOwtJ7s6', 0, 1, '2014-07-14 07:24:00', '2014-09-17 23:10:03', '0', '{}', '0000-00-00 00:00:00', 0, '', '', 0),
(585, 'Thư viện ePub Việt', 'admin', 'epubviet@gmail.com', '$2y$10$rEVDLxK16TbgKohTwPpR6uVzk1s1g4nPGh0Y7lZhIa87TwHNhQb1u', 0, 0, '2014-09-18 03:23:25', '2014-10-17 22:14:03', '', '{"admin_style":"","admin_language":"","language":"","editor":"","helpsite":"","timezone":"Asia\\/Ho_Chi_Minh"}', '0000-00-00 00:00:00', 0, '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_user_keys`
--

CREATE TABLE IF NOT EXISTS `zjw8d_user_keys` (
`id` int(10) unsigned NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `series` varchar(255) NOT NULL,
  `invalid` tinyint(4) NOT NULL,
  `time` varchar(200) NOT NULL,
  `uastring` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_user_notes`
--

CREATE TABLE IF NOT EXISTS `zjw8d_user_notes` (
`id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(100) NOT NULL DEFAULT '',
  `body` text NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL,
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_user_profiles`
--

CREATE TABLE IF NOT EXISTS `zjw8d_user_profiles` (
  `user_id` int(11) NOT NULL,
  `profile_key` varchar(100) NOT NULL,
  `profile_value` varchar(255) NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Simple user profile storage table';

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_user_usergroup_map`
--

CREATE TABLE IF NOT EXISTS `zjw8d_user_usergroup_map` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__users.id',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__usergroups.id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_user_usergroup_map`
--

INSERT INTO `zjw8d_user_usergroup_map` (`user_id`, `group_id`) VALUES
(584, 8),
(585, 8);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_viewlevels`
--

CREATE TABLE IF NOT EXISTS `zjw8d_viewlevels` (
`id` int(10) unsigned NOT NULL COMMENT 'Primary Key',
  `title` varchar(100) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rules` varchar(5120) NOT NULL COMMENT 'JSON encoded access control.'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `zjw8d_viewlevels`
--

INSERT INTO `zjw8d_viewlevels` (`id`, `title`, `ordering`, `rules`) VALUES
(1, 'Public', 0, '[1]'),
(2, 'Registered', 1, '[6,2,8]'),
(3, 'Special', 2, '[6,3,8]'),
(5, 'Guest', 0, '[9]'),
(6, 'Super Users', 0, '[8]');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_weblinks`
--

CREATE TABLE IF NOT EXISTS `zjw8d_weblinks` (
`id` int(10) unsigned NOT NULL,
  `catid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `url` varchar(250) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `language` char(7) NOT NULL DEFAULT '',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if link is featured.',
  `xreference` varchar(50) NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `images` text NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `zjw8d_weblinks`
--

INSERT INTO `zjw8d_weblinks` (`id`, `catid`, `title`, `alias`, `url`, `description`, `hits`, `state`, `checked_out`, `checked_out_time`, `ordering`, `access`, `params`, `language`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `metakey`, `metadesc`, `metadata`, `featured`, `xreference`, `publish_up`, `publish_down`, `version`, `images`) VALUES
(1, 9, 'YOOtheme', 'yootheme', 'http://www.yootheme.com', '', 2, 1, 0, '0000-00-00 00:00:00', 1, 1, '{"target":"","width":"","height":"","count_clicks":""}', '*', '2012-01-22 12:45:30', 390, '', '2012-01-22 12:46:11', 42, '', '', '', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(2, 9, 'Icons', 'icons', 'http://www.yootheme.com/icons', '', 0, 1, 0, '0000-00-00 00:00:00', 2, 1, '{"target":"","width":"","height":"","count_clicks":""}', '*', '2012-01-22 12:45:46', 390, '', '2012-01-22 12:46:06', 42, '', '', '', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(3, 9, 'ZOO', 'zoo', 'http://www.yootheme.com/zoo', '', 0, 1, 0, '0000-00-00 00:00:00', 3, 1, '{"target":"","width":"","height":"","count_clicks":""}', '*', '2012-01-22 12:45:58', 390, '', '2012-01-22 12:46:15', 42, '', '', '', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_widgetkit_widget`
--

CREATE TABLE IF NOT EXISTS `zjw8d_widgetkit_widget` (
`id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `style` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=65 ;

--
-- Dumping data for table `zjw8d_widgetkit_widget`
--

INSERT INTO `zjw8d_widgetkit_widget` (`id`, `type`, `style`, `name`, `content`, `created`, `modified`) VALUES
(10, 'slideshow', 'default', 'Demo Default', '{"type":"slideshow","id":10,"name":"Demo Default","settings":{"style":"default","autoplay":1,"interval":5000,"width":600,"height":300,"duration":500,"index":0,"order":"default","navigation":1,"buttons":1,"slices":15,"animated":"randomFx","caption_animation_duration":500},"style":"default","items":{"4dd00c3ee01f3":{"title":"Slide 1","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/image1.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 01\\" \\/><\\/a>","caption":""},"4dd00c473c0f2":{"title":"Slide 2","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/image2.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 02\\" \\/><\\/a>","caption":"This is a HTML caption with a <a href=\\"#\\">link<\\/a>."},"4dd00c4eb7982":{"title":"Slide 3","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/image3.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 03\\" \\/><\\/a>","caption":"This is another HTML caption with a <a href=\\"#\\">link<\\/a>."},"4de3f1aa49f9a":{"title":"Slide 4","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/image4.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 04\\" \\/><\\/a>","caption":""},"4de3f1ab9f6c9":{"title":"Slide 5","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/image5.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 05\\" \\/><\\/a>","caption":""}}}', '2011-05-15 17:24:01', '2012-06-05 16:58:49'),
(19, 'gallery', 'default', 'Demo Slideshow', '{"type":"gallery","id":19,"name":"Demo Slideshow","settings":{"style":"default","width":600,"height":300,"order":"default","autoplay":0,"interval":5000,"duration":500,"index":0,"navigation":1,"buttons":1,"slices":15,"animated":"randomFx","caption_animation_duration":500,"lightbox":0},"style":"default","paths":["\\/yootheme\\/widgetkit\\/slideshow"],"captions":{"\\/yootheme\\/widgetkit\\/slideshow\\/image1.jpg":"","\\/yootheme\\/widgetkit\\/slideshow\\/image2.jpg":"This is a HTML caption with a <a href=\\"#\\">link<\\/a>.","\\/yootheme\\/widgetkit\\/slideshow\\/image3.jpg":"This is another HTML caption with a <a href=\\"#\\">link<\\/a>.","\\/yootheme\\/widgetkit\\/slideshow\\/image4.jpg":"","\\/yootheme\\/widgetkit\\/slideshow\\/image5.jpg":""},"links":{"\\/yootheme\\/widgetkit\\/slideshow\\/image1.jpg":"","\\/yootheme\\/widgetkit\\/slideshow\\/image2.jpg":"","\\/yootheme\\/widgetkit\\/slideshow\\/image3.jpg":"","\\/yootheme\\/widgetkit\\/slideshow\\/image4.jpg":"","\\/yootheme\\/widgetkit\\/slideshow\\/image5.jpg":""}}', '2011-06-29 17:52:08', '2011-09-12 15:47:24'),
(23, 'gallery', 'wall', 'Demo Wall Spotlight', '{"type":"gallery","id":23,"name":"Demo Wall Spotlight","settings":{"style":"wall","width":200,"height":150,"effect":"spotlight","margin":"margin","corners":"round","lightbox":1,"lightbox_caption":1,"spotlight_effect":""},"style":"wall","paths":["\\/yootheme\\/widgetkit\\/gallery"],"captions":{"\\/yootheme\\/widgetkit\\/gallery\\/image1.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/image2.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/image3.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/image4.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/image5.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/image6.jpg":""},"links":{"\\/yootheme\\/widgetkit\\/gallery\\/image1.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/image2.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/image3.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/image4.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/image5.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/image6.jpg":""}}', '2011-07-03 16:53:00', '2011-07-28 16:18:08'),
(24, 'gallery', 'wall', 'Demo Wall Zoom', '{"type":"gallery","id":24,"name":"Demo Wall Zoom","settings":{"style":"wall","width":200,"height":150,"effect":"zoom","margin":"","corners":"","lightbox":1,"lightbox_caption":1,"spotlight_effect":""},"style":"wall","paths":["\\/yootheme\\/widgetkit\\/gallery\\/zoom"],"captions":{"\\/yootheme\\/widgetkit\\/gallery\\/zoom\\/image1.jpg":"Model 1","\\/yootheme\\/widgetkit\\/gallery\\/zoom\\/image2.jpg":"Model 2","\\/yootheme\\/widgetkit\\/gallery\\/zoom\\/image3.jpg":"Model 3","\\/yootheme\\/widgetkit\\/gallery\\/zoom\\/image4.jpg":"Model 4","\\/yootheme\\/widgetkit\\/gallery\\/zoom\\/image5.jpg":"Model 5","\\/yootheme\\/widgetkit\\/gallery\\/zoom\\/image6.jpg":"Model 6"},"links":{"\\/yootheme\\/widgetkit\\/gallery\\/zoom\\/image1.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/zoom\\/image2.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/zoom\\/image3.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/zoom\\/image4.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/zoom\\/image5.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/zoom\\/image6.jpg":""}}', '2011-07-07 15:41:12', '2011-07-29 10:38:06'),
(25, 'gallery', 'wall', 'Demo Wall Polaroid', '{"type":"gallery","id":25,"name":"Demo Wall Polaroid","settings":{"style":"wall","width":200,"height":150,"order":"default","effect":"polaroid","margin":"","corners":"","lightbox":1,"lightbox_caption":1,"spotlight_effect":""},"style":"wall","paths":["\\/yootheme\\/widgetkit\\/gallery\\/polaroid"],"captions":{"\\/yootheme\\/widgetkit\\/gallery\\/polaroid\\/image1.jpg":"Tony","\\/yootheme\\/widgetkit\\/gallery\\/polaroid\\/image2.jpg":"Susan","\\/yootheme\\/widgetkit\\/gallery\\/polaroid\\/image3.jpg":"Jennifer","\\/yootheme\\/widgetkit\\/gallery\\/polaroid\\/image4.jpg":"Kim","\\/yootheme\\/widgetkit\\/gallery\\/polaroid\\/image5.jpg":"Vanessa","\\/yootheme\\/widgetkit\\/gallery\\/polaroid\\/image6.jpg":"Clark"},"links":{"\\/yootheme\\/widgetkit\\/gallery\\/polaroid\\/image1.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/polaroid\\/image2.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/polaroid\\/image3.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/polaroid\\/image4.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/polaroid\\/image5.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/polaroid\\/image6.jpg":""}}', '2011-07-07 15:44:32', '2012-01-26 09:53:13'),
(26, 'map', 'default', 'Demo Default', '{"type":"map","id":26,"name":"Demo Default","settings":{"style":"default","width":"auto","height":500,"mapTypeId":"roadmap","zoom":13,"mapCtrl":1,"typeCtrl":1,"popup":2,"directions":1,"styler_invert_lightness":0,"styler_hue":"","styler_saturation":0,"styler_lightness":0,"styler_gamma":0},"style":"default","items":{"4e16d63a2bc97":{"title":"Museum of Modern Art","location":"Museum of Modern Art, New York, NY 10019, USA","lat":"40.7613983","lng":"-73.9776179","icon":"red-dot","popup":"<h3>Museum of Modern Art<\\/h3>\\r\\n11 W 53rd St\\r\\n<br \\/>New York, NY 10019\\r\\n<br \\/>(212) 708-9400\\r\\n<br \\/><a href=\\"http:\\/\\/www.moma.org\\">moma.org<\\/a>"},"4e16d65531670":{"title":"Madison Square Garden","location":"Penn Station, New York, NY 10001, USA","lat":"40.75058","lng":"-73.99358","icon":"red-dot","popup":"<h3>Madison Square Garden<\\/h3>\\r\\n2 Penn Plz # 15\\r\\n<br \\/>New York, NY 10121\\r\\n<br \\/>Get Directions\\r\\n<br \\/>(212) 465-6000\\r\\n<br \\/><a href=\\"http:\\/\\/www.msg.com\\">msg.com<\\/a>"},"4e16d5e1740d8":{"title":"Rockefeller Center","location":"Rockefeller Plaza, Rockefeller Center, New York, NY 10112, USA","lat":"40.7584384","lng":"-73.9789121","icon":"red-dot","popup":"<h3>Rockefeller Center<\\/h3>\\r\\n25 W 51st St\\r\\n<br \\/>New York, NY 10019\\r\\n<br \\/>(212) 262-1600\\r\\n<br \\/><a href=\\"http:\\/\\/www.rockefellercenterhotel.com\\">rockefellercenterhotel.com<\\/a>"},"4e16d6476a880":{"title":"Empire State Building","location":"Empire State Bldg, 350 5th Ave, New York, NY 10001, USA","lat":"40.748379","lng":"-73.98555999999999","icon":"red-dot","popup":"<h3>Empire State Building<\\/h3>\\r\\n350 5th Ave # 3210\\r\\n<br \\/>New York, NY 10118\\r\\n<br \\/>(212) 736-3100\\r\\n<br \\/><a href=\\"http:\\/\\/www.esbnyc.com\\">esbnyc.com<\\/a>"}}}', '2011-07-08 10:05:25', '2011-07-31 15:23:06'),
(27, 'gallery', 'slider', 'Demo Slider Center', '{"type":"gallery","id":27,"name":"Demo Slider Center","settings":{"style":"slider","width":300,"height":200,"total_width":600,"spacing":3,"center":1,"sticky":0,"duration":400,"lightbox":1,"lightbox_caption":1,"spotlight":1,"spotlight_effect":"bottom"},"style":"slider","paths":["\\/yootheme\\/widgetkit\\/gallery\\/slider2"],"captions":{"\\/yootheme\\/widgetkit\\/gallery\\/slider2\\/image1.jpg":"This is a caption for the first image.","\\/yootheme\\/widgetkit\\/gallery\\/slider2\\/image2.jpg":"This is a caption for the second image.","\\/yootheme\\/widgetkit\\/gallery\\/slider2\\/image3.jpg":"This is a caption for the third image.","\\/yootheme\\/widgetkit\\/gallery\\/slider2\\/image4.jpg":"This is a caption for the fourth image."},"links":{"\\/yootheme\\/widgetkit\\/gallery\\/slider2\\/image1.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/slider2\\/image2.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/slider2\\/image3.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/slider2\\/image4.jpg":""}}', '2011-07-08 15:28:38', '2011-07-29 08:28:24'),
(28, 'map', 'default', 'Demo Black', '{"type":"map","id":28,"name":"Demo Black","settings":{"style":"default","width":"auto","height":300,"mapTypeId":"roadmap","zoom":13,"mapCtrl":1,"typeCtrl":0,"popup":1,"directions":0,"styler_invert_lightness":1,"styler_hue":"#ff3300","styler_saturation":-50,"styler_lightness":0,"styler_gamma":0.91},"style":"default","items":{"4e19a7ec5f75a":{"title":"London","location":"Westminster, London, UK","lat":"51.5001524","lng":"-0.1262362","icon":"purple-dot","popup":""}}}', '2011-07-10 13:25:58', '2011-07-12 08:24:47'),
(29, 'map', 'default', 'Demo Minimal', '{"type":"map","id":29,"name":"Demo Minimal","settings":{"style":"default","width":400,"height":200,"mapTypeId":"roadmap","zoom":13,"mapCtrl":0,"typeCtrl":0,"popup":0,"directions":0,"styler_invert_lightness":0,"styler_hue":"","styler_saturation":0,"styler_lightness":0,"styler_gamma":0},"style":"default","items":{"4e1ac310cf33e":{"title":"Hamburg","location":"Hamburg, Germany","lat":"53.553813","lng":"9.991586","icon":"red-dot","popup":""}}}', '2011-07-11 09:33:05', '2011-07-31 15:08:57'),
(30, 'accordion', 'default', 'Demo Default', '{"type":"accordion","id":30,"name":"Demo Default","settings":{"style":"default","collapseall":1,"matchheight":1,"index":0,"duration":500,"width":500},"style":"default","items":{"4e1ac6fe6a20d":{"title":"Slide 1","content":"<img class=\\"align-left\\" src=\\"images\\/yootheme\\/widgetkit\\/accordion\\/image1.png\\" width=\\"115\\" height=\\"105\\" alt=\\"Icon 01\\" \\/>\\r\\n<h3 class=\\"remove-margin-t\\">Headline<\\/h3>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>"},"4e1ac708561be":{"title":"Slide 2","content":"<img class=\\"align-left\\" src=\\"images\\/yootheme\\/widgetkit\\/accordion\\/image2.png\\" width=\\"115\\" height=\\"105\\" alt=\\"Icon 02\\" \\/>\\r\\n<h3 class=\\"remove-margin-t\\">Headline<\\/h3>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>"},"4e1ac70cb840e":{"title":"Slide 3","content":"<img class=\\"align-left\\" src=\\"images\\/yootheme\\/widgetkit\\/accordion\\/image3.png\\" width=\\"115\\" height=\\"105\\" alt=\\"Icon 03\\" \\/>\\r\\n<h3 class=\\"remove-margin-t\\">Headline<\\/h3>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>"},"4e1ac711bbabe":{"title":"Slide 4","content":"<img class=\\"align-left\\" src=\\"images\\/yootheme\\/widgetkit\\/accordion\\/image4.png\\" width=\\"115\\" height=\\"105\\" alt=\\"Icon 04\\" \\/>\\r\\n<h3 class=\\"remove-margin-t\\">Headline<\\/h3>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>"}}}', '2011-07-11 09:49:12', '2011-12-13 20:05:58'),
(31, 'gallery', 'slider', 'Demo Slider Left', '{"type":"gallery","id":31,"name":"Demo Slider Left","settings":{"style":"slider","width":300,"height":200,"total_width":600,"spacing":3,"center":0,"sticky":0,"duration":400,"lightbox":0,"lightbox_caption":1,"spotlight":0,"spotlight_effect":""},"style":"slider","paths":["\\/yootheme\\/widgetkit\\/gallery\\/slider1"],"captions":{"\\/yootheme\\/widgetkit\\/gallery\\/slider1\\/image1.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/slider1\\/image2.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/slider1\\/image3.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/slider1\\/image4.jpg":""},"links":{"\\/yootheme\\/widgetkit\\/gallery\\/slider1\\/image1.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/slider1\\/image2.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/slider1\\/image3.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/slider1\\/image4.jpg":""}}', '2011-07-12 18:23:44', '2011-07-29 07:48:55'),
(32, 'slideset', 'default', 'Demo Slide', '{"type":"slideset","id":32,"name":"Demo Slide","settings":{"style":"default","width":"auto","height":"auto","effect":"slide","index":0,"autoplay":1,"interval":5000,"items_per_set":4,"navigation":1,"buttons":0,"title":1,"duration":300},"style":"default","items":{"4e30070bb3f2c":{"title":"Radio","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image1.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 01\\" \\/><\\/a>","group":"","set":"Set 1"},"4e30071628817":{"title":"Camera","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image2.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 02\\" \\/><\\/a>","group":"","set":"Set 1"},"4e30071b515e1":{"title":"Calendar","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image3.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 03\\" \\/><\\/a>","group":"","set":"Set 1"},"4e300720a131e":{"title":"Volume","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image4.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 04\\" \\/><\\/a>","group":"","set":"Set 1"},"4e300725404e2":{"title":"Chat","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image5.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 05\\" \\/><\\/a>","group":"","set":"Set 2"},"4e301094b3b19":{"title":"Tunes","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image6.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 06\\" \\/><\\/a>","set":"Set 2"},"4e301099469eb":{"title":"E-Mail","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image7.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 07\\" \\/><\\/a>","set":"Set 2"},"4e30109dc7253":{"title":"Google+","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image8.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 08\\" \\/><\\/a>","set":"Set 2"},"4e30109faa62d":{"title":"Player","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image9.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 09\\" \\/><\\/a>","set":"Set 3"},"4e3010a16c585":{"title":"Like","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image10.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 10\\" \\/><\\/a>","set":"Set 3"},"4e329ee00dfeb":{"title":"Twitter","set":"Set 3","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image11.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 12\\" \\/><\\/a>"},"4e329ee198f40":{"title":"Weather","set":"Set 3","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image12.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 12\\" \\/><\\/a>"}}}', '2011-07-27 12:40:13', '2012-01-04 15:38:42'),
(33, 'slideset', 'default', 'Demo Zoom', '{"type":"slideset","id":33,"name":"Demo Zoom","settings":{"style":"default","width":"auto","height":"auto","effect":"zoom","index":0,"autoplay":1,"interval":7000,"items_per_set":"set","navigation":2,"buttons":0,"title":0,"duration":300},"style":"default","items":{"4e30070bb3f2c":{"title":"Icon 1","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/sets\\/movie1.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 01\\" \\/><\\/a>","group":"","set":"Movies"},"4e30071628817":{"title":"Icon 2","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/sets\\/movie2.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 02\\" \\/><\\/a>","group":"","set":"Movies"},"4e30071b515e1":{"title":"Icon 3","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/sets\\/movie3.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 03\\" \\/><\\/a>","group":"","set":"Movies"},"4e300720a131e":{"title":"Icon 4","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/sets\\/movie4.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 04\\" \\/><\\/a>","group":"","set":"Movies"},"4e300725404e2":{"title":"Item 5","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/sets\\/book1.png\\" width=\\"90\\" height=\\"115\\" alt=\\"Icon 05\\" \\/><\\/a>","group":"","set":"Books"},"4e301094b3b19":{"title":"Icon 6","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/sets\\/book2.png\\" width=\\"90\\" height=\\"115\\" alt=\\"Icon 06\\" \\/><\\/a>","set":"Books"},"4e301099469eb":{"title":"Icon 7","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/sets\\/book3.png\\" width=\\"90\\" height=\\"115\\" alt=\\"Icon 07\\" \\/><\\/a>","set":"Books"},"4e30109dc7253":{"title":"Icon 8","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/sets\\/book4.png\\" width=\\"90\\" height=\\"115\\" alt=\\"Icon 08\\" \\/><\\/a>","set":"Books"},"4e30109faa62d":{"title":"Icon 9","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/sets\\/book5.png\\" width=\\"90\\" height=\\"115\\" alt=\\"Icon 09\\" \\/><\\/a>","set":"Books"},"4e3010a16c585":{"title":"Icon 10","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/sets\\/music1.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 10\\" \\/><\\/a>","set":"Music"},"4e329ee00dfeb":{"title":"Icon 11","set":"Music","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/sets\\/music2.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 12\\" \\/><\\/a>"},"4e329ee198f40":{"title":"Icon 12","set":"Music","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/sets\\/music3.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 12\\" \\/><\\/a>"},"4f2a65a31c537":{"title":"Icon 13","set":"Music","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/sets\\/music4.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 13\\" \\/><\\/a>"}}}', '2011-07-29 11:53:34', '2012-02-27 10:52:54'),
(34, 'slideshow', 'tabs_bar', 'Demo Tabs Bar', '{"type":"slideshow","id":34,"name":"Demo Tabs Bar","settings":{"style":"tabs_bar","autoplay":0,"interval":5000,"width":"auto","height":"auto","duration":500,"index":0,"order":"default","navigation":"left","animated":"scroll"},"style":"tabs_bar","items":{"4e511fb86001b":{"title":"Tab One","content":"<img class=\\"align-left\\" src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/icons\\/image1.png\\" width=\\"115\\" height=\\"105\\" alt=\\"Icon 01\\" \\/>\\r\\n<h3 class=\\"remove-margin-t\\">Headline<\\/h3>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>","caption":""},"4e511fd616557":{"title":"Tab Two","content":"<img class=\\"align-left\\" src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/icons\\/image2.png\\" width=\\"115\\" height=\\"105\\" alt=\\"Icon 02\\" \\/>\\r\\n<h3 class=\\"remove-margin-t\\">Headline<\\/h3>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>"},"4e511fd6eeb3b":{"title":"Tab Three","content":"<img class=\\"align-left\\" src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/icons\\/image3.png\\" width=\\"115\\" height=\\"105\\" alt=\\"Icon 03\\" \\/>\\r\\n<h3 class=\\"remove-margin-t\\">Headline<\\/h3>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>"}}}', '2011-08-21 15:09:51', '2011-09-12 12:38:06'),
(35, 'slideshow', 'tabs', 'Demo Tabs', '{"type":"slideshow","id":35,"name":"Demo Tabs","settings":{"style":"tabs","autoplay":0,"interval":5000,"width":"auto","height":"auto","duration":500,"index":0,"order":"default","navigation":"left","animated":"scroll"},"style":"tabs","items":{"4e511fb86001b":{"title":"Tab One","content":"<img class=\\"align-left\\" src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/icons\\/image4.png\\" width=\\"115\\" height=\\"105\\" alt=\\"Icon 04\\" \\/>\\r\\n<h3 class=\\"remove-margin-t\\">Headline<\\/h3>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>","caption":""},"4e511fd616557":{"title":"Tab Two","content":"<img class=\\"align-left\\" src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/icons\\/image5.png\\" width=\\"115\\" height=\\"105\\" alt=\\"Icon 05\\" \\/>\\r\\n<h3 class=\\"remove-margin-t\\">Headline<\\/h3>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>"},"4e511fd6eeb3b":{"title":"Tab Three","content":"<img class=\\"align-left\\" src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/icons\\/image6.png\\" width=\\"115\\" height=\\"105\\" alt=\\"Icon 06\\" \\/>\\r\\n<h3 class=\\"remove-margin-t\\">Headline<\\/h3>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>"}}}', '2011-08-22 13:43:01', '2011-09-09 15:54:58'),
(36, 'slideshow', 'list', 'Demo List', '{"type":"slideshow","id":36,"name":"Demo List","settings":{"style":"list","autoplay":0,"interval":5000,"width":"auto","height":"auto","duration":500,"index":0,"order":"default","navigation":200,"animated":"scroll"},"style":"list","items":{"4e511fb86001b":{"title":"Item One","content":"<h3 class=\\"remove-margin-t\\">Headline<\\/h3>\\r\\n<img class=\\"align-right\\" src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/icons\\/image9.png\\" width=\\"115\\" height=\\"105\\" alt=\\"Icon 09\\" \\/>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>","caption":""},"4e511fd616557":{"title":"Item Two","content":"<h3 class=\\"remove-margin-t\\">Headline<\\/h3>\\r\\n<img class=\\"align-right\\" src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/icons\\/image8.png\\" width=\\"115\\" height=\\"105\\" alt=\\"Icon 08\\" \\/>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>"},"4e511fd6eeb3b":{"title":"Item Three","content":"<h3 class=\\"remove-margin-t\\">Headline<\\/h3>\\r\\n<img class=\\"align-right\\" src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/icons\\/image7.png\\" width=\\"115\\" height=\\"105\\" alt=\\"Icon 07\\" \\/>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>"}}}', '2011-08-23 09:54:41', '2011-09-05 12:36:22'),
(37, 'slideshow', 'showcase_box', 'Demo Showcase Box', '{"type":"slideshow","id":37,"name":"Demo Showcase Box","settings":{"style":"showcase_box","autoplay":0,"interval":5000,"width":600,"height":270,"duration":500,"index":0,"order":"default","buttons":0,"slices":20,"animated":"scroll","caption_animation_duration":500,"effect":"slide","slideset_buttons":1,"items_per_set":4,"slideset_effect_duration":400},"style":"showcase_box","items":{"4dd00c3ee01f3":{"title":"Slide 1","content":"<img class=\\"align-right\\" src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image1.png\\" width=\\"210\\" height=\\"220\\" alt=\\"Image 01\\" \\/>\\r\\n<h2 class=\\"remove-margin-t\\">Headline<\\/h2>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<a href=\\"#\\" class=\\"button-more\\">Read more<\\/a>","caption":"","navigation":"<img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image1_thumb.png\\" width=\\"35\\" height=\\"35\\" alt=\\"Image 01\\" \\/> Item 1"},"4dd00c473c0f2":{"title":"Slide 2","content":"<img class=\\"align-right\\" src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image2.png\\" width=\\"210\\" height=\\"220\\" alt=\\"Image 02\\" \\/>\\r\\n<h2 class=\\"remove-margin-t\\">Headline<\\/h2>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<a href=\\"#\\" class=\\"button-more\\">Read more<\\/a>","caption":"","navigation":"<img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image2_thumb.png\\" width=\\"35\\" height=\\"35\\" alt=\\"Image 02\\" \\/> Item 2"},"4dd00c4eb7982":{"title":"Slide 3","content":"<img class=\\"align-right\\" src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image3.png\\" width=\\"210\\" height=\\"220\\" alt=\\"Image 03\\" \\/>\\r\\n<h2 class=\\"remove-margin-t\\">Headline<\\/h2>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<a href=\\"#\\" class=\\"button-more\\">Read more<\\/a>","caption":"","navigation":"<img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image3_thumb.png\\" width=\\"35\\" height=\\"35\\" alt=\\"Image 03\\" \\/> Item 3"},"4de3f1aa49f9a":{"title":"Slide 4","content":"<img class=\\"align-right\\" src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image4.png\\" width=\\"210\\" height=\\"220\\" alt=\\"Image 04\\" \\/>\\r\\n<h2 class=\\"remove-margin-t\\">Headline<\\/h2>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<a href=\\"#\\" class=\\"button-more\\">Read more<\\/a>","caption":"","navigation":"<img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image4_thumb.png\\" width=\\"35\\" height=\\"35\\" alt=\\"Image 04\\" \\/> Item 4"},"4de3f1ab9f6c9":{"title":"Slide 5","content":"<img class=\\"align-right\\" src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image5.png\\" width=\\"210\\" height=\\"220\\" alt=\\"Image 05\\" \\/>\\r\\n<h2 class=\\"remove-margin-t\\">Headline<\\/h2>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<a href=\\"#\\" class=\\"button-more\\">Read more<\\/a>","caption":"","navigation":"<img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image5_thumb.png\\" width=\\"35\\" height=\\"35\\" alt=\\"Image 05\\" \\/> Item 5"},"4e65eda9682e1":{"title":"Slide 6","content":"<img class=\\"align-right\\" src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image6.png\\" width=\\"210\\" height=\\"220\\" alt=\\"Image 06\\" \\/>\\r\\n<h2 class=\\"remove-margin-t\\">Headline<\\/h2>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<a href=\\"#\\" class=\\"button-more\\">Read more<\\/a>","navigation":"<img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image6_thumb.png\\" width=\\"35\\" height=\\"35\\" alt=\\"Image 06\\" \\/> Item 6","caption":""},"4e65edadd0d97":{"title":"Slide 7","content":"<img class=\\"align-right\\" src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image7.png\\" width=\\"210\\" height=\\"220\\" alt=\\"Image 07\\" \\/>\\r\\n<h2 class=\\"remove-margin-t\\">Headline<\\/h2>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<a href=\\"#\\" class=\\"button-more\\">Read more<\\/a>","navigation":"<img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image7_thumb.png\\" width=\\"35\\" height=\\"35\\" alt=\\"Image 07\\" \\/> Item 7","caption":""},"4e65edb02bf73":{"title":"Slide 8","content":"<img class=\\"align-right\\" src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image8.png\\" width=\\"210\\" height=\\"220\\" alt=\\"Image 08\\" \\/>\\r\\n<h2 class=\\"remove-margin-t\\">Headline<\\/h2>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.<\\/p>\\r\\n<a href=\\"#\\" class=\\"button-more\\">Read more<\\/a>","navigation":"<img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image8_thumb.png\\" width=\\"35\\" height=\\"35\\" alt=\\"Image 08\\" \\/> Item 8","caption":""}}}', '2011-08-23 15:51:42', '2011-09-29 15:18:40'),
(39, 'gallery', 'showcase_box', 'Demo Showcase Box', '{"type":"gallery","id":39,"name":"Demo Showcase Box","settings":{"style":"showcase_box","width":600,"height":"auto","thumb_width":85,"thumb_height":55,"autoplay":1,"interval":5000,"duration":400,"index":0,"buttons":0,"slices":15,"animated":"randomFx","caption_animation_duration":500,"effect":"zoom","slideset_buttons":1,"items_per_set":4,"slideset_effect_duration":300},"style":"showcase_box","paths":["\\/yootheme\\/widgetkit\\/gallery\\/showcase1"],"captions":{"\\/yootheme\\/widgetkit\\/gallery\\/showcase1\\/image1.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase1\\/image2.jpg":"This is a HTML caption with a <a href=\\"#\\">link<\\/a>.","\\/yootheme\\/widgetkit\\/gallery\\/showcase1\\/image3.jpg":"This is another HTML caption with a <a href=\\"#\\">link<\\/a>.","\\/yootheme\\/widgetkit\\/gallery\\/showcase1\\/image4.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase1\\/image5.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase1\\/image6.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase1\\/image7.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase1\\/image8.jpg":""},"links":{"\\/yootheme\\/widgetkit\\/gallery\\/showcase1\\/image1.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase1\\/image2.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase1\\/image3.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase1\\/image4.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase1\\/image5.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase1\\/image6.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase1\\/image7.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase1\\/image8.jpg":""}}', '2011-09-07 16:58:35', '2012-01-06 13:04:19'),
(40, 'gallery', 'showcase', 'Demo Showcase', '{"type":"gallery","id":40,"name":"Demo Showcase","settings":{"style":"showcase","width":600,"height":"auto","thumb_width":80,"thumb_height":45,"autoplay":0,"interval":5000,"duration":500,"index":0,"buttons":0,"slices":15,"animated":"randomSimple","caption_animation_duration":500,"effect":"zoom","slideset_buttons":1,"items_per_set":5,"slideset_effect_duration":300},"style":"showcase","paths":["\\/yootheme\\/widgetkit\\/gallery\\/showcase2"],"captions":{"\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image01.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image02.jpg":"This is a HTML caption with a <a href=\\"#\\">link<\\/a>.","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image03.jpg":"This is another HTML caption with a <a href=\\"#\\">link<\\/a>.","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image04.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image05.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image06.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image07.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image08.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image09.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image10.jpg":""},"links":{"\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image01.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image02.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image03.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image04.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image05.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image06.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image07.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image08.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image09.jpg":"","\\/yootheme\\/widgetkit\\/gallery\\/showcase2\\/image10.jpg":""}}', '2011-09-09 15:18:41', '2012-01-05 16:56:06'),
(41, 'slideshow', 'showcase_buttons', 'Demo Showcase Buttons', '{"type":"slideshow","id":41,"name":"Demo Showcase Buttons","settings":{"style":"showcase_buttons","autoplay":0,"interval":5000,"width":600,"height":300,"duration":500,"index":0,"order":"default","buttons":1,"slices":20,"animated":"randomFx","caption_animation_duration":500,"effect":"zoom","slideset_buttons":0,"items_per_set":4,"slideset_effect_duration":400},"style":"showcase_buttons","items":{"4dd00c3ee01f3":{"title":"Slide 1","content":"<img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase2\\/image1.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 01\\" \\/>","caption":"","navigation":"<img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image1_thumb.png\\" width=\\"35\\" height=\\"35\\" alt=\\"Image 01\\" \\/> Item 1"},"4dd00c473c0f2":{"title":"Slide 2","content":"<img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase2\\/image2.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 02\\" \\/>","caption":"","navigation":"<img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image2_thumb.png\\" width=\\"35\\" height=\\"35\\" alt=\\"Image 02\\" \\/> Item 2"},"4dd00c4eb7982":{"title":"Slide 3","content":"<img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase2\\/image3.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 03\\" \\/>","caption":"","navigation":"<img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image3_thumb.png\\" width=\\"35\\" height=\\"35\\" alt=\\"Image 03\\" \\/> Item 3"},"4de3f1aa49f9a":{"title":"Slide 4","content":"<img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase2\\/image4.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 04\\" \\/>","caption":"","navigation":"<img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/showcase1\\/image4_thumb.png\\" width=\\"35\\" height=\\"35\\" alt=\\"Image 04\\" \\/> Item 4"}}}', '2011-09-12 15:52:19', '2011-09-13 10:04:58'),
(43, 'slideset', 'default', 'Demo Deck', '{"type":"slideset","id":43,"name":"Demo Deck","settings":{"style":"default","width":"auto","height":"auto","effect":"deck","index":0,"autoplay":1,"interval":11000,"items_per_set":4,"navigation":0,"buttons":1,"title":0,"duration":300},"style":"default","items":{"4e30070bb3f2c":{"title":"Radio","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image1.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 01\\" \\/><\\/a>","group":"","set":"Set 1"},"4e30071628817":{"title":"Camera","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image2.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 02\\" \\/><\\/a>","group":"","set":"Set 1"},"4e30071b515e1":{"title":"Calendar","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image3.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 03\\" \\/><\\/a>","group":"","set":"Set 1"},"4e300720a131e":{"title":"Volume","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image4.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 04\\" \\/><\\/a>","group":"","set":"Set 1"},"4e300725404e2":{"title":"Chat","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image5.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 05\\" \\/><\\/a>","group":"","set":"Set 2"},"4e301094b3b19":{"title":"Tunes","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image6.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 06\\" \\/><\\/a>","set":"Set 2"},"4e301099469eb":{"title":"E-Mail","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image7.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 07\\" \\/><\\/a>","set":"Set 2"},"4e30109dc7253":{"title":"Google+","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image8.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 08\\" \\/><\\/a>","set":"Set 2"},"4e30109faa62d":{"title":"Player","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image9.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 09\\" \\/><\\/a>","set":"Set 3"},"4e3010a16c585":{"title":"Like","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image10.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 10\\" \\/><\\/a>","set":"Set 3"},"4e329ee00dfeb":{"title":"Twitter","set":"Set 3","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image11.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 12\\" \\/><\\/a>"},"4e329ee198f40":{"title":"Weather","set":"Set 3","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/image12.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 12\\" \\/><\\/a>"}}}', '2011-09-12 18:34:35', '2012-02-02 10:38:45'),
(44, 'gallery', 'slideset', 'Demo Slideset', '{"type":"gallery","id":44,"name":"Demo Slideset","settings":{"style":"slideset","width":"auto","height":"auto","effect":"slide","autoplay":1,"interval":5000,"items_per_set":4,"navigation":1,"buttons":1,"title":1,"duration":500,"lightbox":0},"style":"slideset","paths":["\\/yootheme\\/widgetkit\\/slideset"],"captions":{"\\/yootheme\\/widgetkit\\/slideset\\/image1.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image10.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image11.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image12.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image2.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image3.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image4.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image5.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image6.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image7.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image8.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image9.png":""},"links":{"\\/yootheme\\/widgetkit\\/slideset\\/image1.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image10.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image11.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image12.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image2.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image3.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image4.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image5.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image6.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image7.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image8.png":"","\\/yootheme\\/widgetkit\\/slideset\\/image9.png":""}}', '2012-01-04 12:20:06', '2012-01-06 11:25:05'),
(45, 'slideshow', 'screen', 'Demo Screen', '{"type":"slideshow","id":45,"name":"Demo Screen","settings":{"style":"screen","autoplay":1,"interval":10000,"width":600,"height":300,"duration":1000,"index":0,"order":"default","navigation":1,"buttons":1,"slices":15,"animated":"kenburns","caption_animation_duration":500},"style":"screen","items":{"4dd00c3ee01f3":{"title":"Slide 1","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/screen\\/image1.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 01\\" \\/><\\/a>","caption":""},"4dd00c473c0f2":{"title":"Slide 2","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/screen\\/image2.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 02\\" \\/><\\/a>","caption":"This is a HTML caption with a <a href=\\"#\\">link<\\/a>."},"4dd00c4eb7982":{"title":"Slide 3","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/screen\\/image3.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 03\\" \\/><\\/a>","caption":"This is another HTML caption with a <a href=\\"#\\">link<\\/a>."},"4de3f1aa49f9a":{"title":"Slide 4","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/screen\\/image4.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 04\\" \\/><\\/a>","caption":""},"4f27c34aee78f":{"title":"Slide 5","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/screen\\/image5.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 05\\" \\/><\\/a>","caption":""}}}', '2012-01-30 16:15:12', '2012-02-01 09:22:15'),
(48, 'gallery', 'screen', 'Demo Slideshow Screen', '{"type":"gallery","id":48,"name":"Demo Slideshow Screen","settings":{"style":"screen","width":600,"height":"auto","autoplay":0,"order":"default","interval":5000,"duration":500,"index":0,"navigation":1,"buttons":1,"slices":20,"animated":"swipe","caption_animation_duration":500,"lightbox":0},"style":"screen","paths":["\\/yootheme\\/widgetkit\\/slideshow\\/screen"],"captions":{"\\/yootheme\\/widgetkit\\/slideshow\\/screen\\/image1.jpg":"","\\/yootheme\\/widgetkit\\/slideshow\\/screen\\/image2.jpg":"","\\/yootheme\\/widgetkit\\/slideshow\\/screen\\/image3.jpg":"","\\/yootheme\\/widgetkit\\/slideshow\\/screen\\/image4.jpg":"","\\/yootheme\\/widgetkit\\/slideshow\\/screen\\/image5.jpg":""},"links":{"\\/yootheme\\/widgetkit\\/slideshow\\/screen\\/image1.jpg":"","\\/yootheme\\/widgetkit\\/slideshow\\/screen\\/image2.jpg":"","\\/yootheme\\/widgetkit\\/slideshow\\/screen\\/image3.jpg":"","\\/yootheme\\/widgetkit\\/slideshow\\/screen\\/image4.jpg":"","\\/yootheme\\/widgetkit\\/slideshow\\/screen\\/image5.jpg":""}}', '2012-02-01 13:57:51', '2012-02-02 09:32:52'),
(49, 'slideset', 'default', 'Demo Drops', '{"type":"slideset","id":49,"name":"Demo Drops","settings":{"style":"default","width":"auto","height":"auto","effect":"drops","index":0,"autoplay":1,"interval":9000,"items_per_set":4,"navigation":1,"buttons":0,"title":1,"duration":200},"style":"default","items":{"4e30070bb3f2c":{"title":"Album 1","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/music\\/music1.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 01\\" \\/><\\/a>","group":"","set":"Set 1"},"4e30071628817":{"title":"Album 2","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/music\\/music2.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 02\\" \\/><\\/a>","group":"","set":"Set 1"},"4e30071b515e1":{"title":"Album 3","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/music\\/music3.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 03\\" \\/><\\/a>","group":"","set":"Set 1"},"4e300720a131e":{"title":"Album 4","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/music\\/music4.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 04\\" \\/><\\/a>","group":"","set":"Set 1"},"4e300725404e2":{"title":"Album 5","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/music\\/music5.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 05\\" \\/><\\/a>","group":"","set":"Set 2"},"4e301094b3b19":{"title":"Album 6","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/music\\/music6.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 06\\" \\/><\\/a>","set":"Set 2"},"4e301099469eb":{"title":"Album 7","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/music\\/music7.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 07\\" \\/><\\/a>","set":"Set 2"},"4e30109dc7253":{"title":"Album 8","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/music\\/music8.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 08\\" \\/><\\/a>","set":"Set 2"},"4e30109faa62d":{"title":"Album 9","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/music\\/music9.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 09\\" \\/><\\/a>","set":"Set 3"},"4e3010a16c585":{"title":"Album 10","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/music\\/music10.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 10\\" \\/><\\/a>","set":"Set 3"},"4e329ee00dfeb":{"title":"Album 11","set":"Set 3","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/music\\/music11.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 12\\" \\/><\\/a>"},"4e329ee198f40":{"title":"Album 12","set":"Set 3","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideset\\/music\\/music12.png\\" width=\\"115\\" height=\\"115\\" alt=\\"Icon 12\\" \\/><\\/a>"}}}', '2012-02-02 10:32:01', '2012-02-02 10:57:03'),
(50, 'slideshow', 'default', 'Demo Lightbox', '{"type":"slideshow","id":50,"name":"Demo Lightbox","settings":{"style":"default","autoplay":1,"interval":5000,"width":600,"height":300,"duration":500,"index":0,"order":"default","navigation":0,"buttons":1,"slices":15,"animated":"randomFx","caption_animation_duration":500},"style":"default","items":{"4dd00c3ee01f3":{"title":"Slide 1","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/image1.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 01\\" \\/><\\/a>","caption":""},"4dd00c473c0f2":{"title":"Slide 2","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/image2.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 02\\" \\/><\\/a>","caption":"This is a HTML caption with a <a href=\\"#\\">link<\\/a>."},"4dd00c4eb7982":{"title":"Slide 3","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/image3.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 03\\" \\/><\\/a>","caption":"This is another HTML caption with a <a href=\\"#\\">link<\\/a>."},"4de3f1aa49f9a":{"title":"Slide 4","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/image4.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 04\\" \\/><\\/a>","caption":""},"4de3f1ab9f6c9":{"title":"Slide 5","content":"<a href=\\"#\\"><img src=\\"images\\/yootheme\\/widgetkit\\/slideshow\\/image5.jpg\\" width=\\"600\\" height=\\"300\\" alt=\\"Image 05\\" \\/><\\/a>","caption":""}}}', '2012-02-02 12:42:27', '2012-02-02 12:43:08');
INSERT INTO `zjw8d_widgetkit_widget` (`id`, `type`, `style`, `name`, `content`, `created`, `modified`) VALUES
(51, 'slideset', 'sphere', 'Frontpage Slideset', '{"type":"slideset","id":51,"name":"Frontpage Slideset","settings":{"style":"sphere","width":"auto","height":"auto","effect":"zoom","index":0,"autoplay":0,"interval":5000,"items_per_set":2,"navigation":0,"buttons":1,"title":0,"duration":300},"style":"sphere","items":{"4fe055aa2f60d":{"title":"Support","set":"","content":"<div class=\\"text-left frontpage-center\\" style=\\"width: 240px;\\">\\r\\n  <img class=\\"align-left\\" src=\\"images\\/yootheme\\/demo\\/slideset\\/icon_support.png\\" width=\\"48\\" height=\\"48\\" alt=\\"01\\" \\/>\\r\\n    <h3 style=\\"margin: 0; padding-top: 5px;\\">SUPPORT<\\/h3>\\r\\n    <p style=\\"margin-top: 5px; margin-bottom: 0;\\">Our team is here for you<\\/p>\\r\\n<\\/div>"},"4fe055bfbfb15":{"title":"Sync","set":"","content":"<div class=\\"text-left frontpage-center\\" style=\\"width: 240px;\\">\\r\\n  <img class=\\"align-left\\" src=\\"images\\/yootheme\\/demo\\/slideset\\/icon_sync.png\\" width=\\"48\\" height=\\"48\\" alt=\\"01\\" \\/>\\r\\n    <h3 style=\\"margin: 0; padding-top: 5px;\\">SYNC<\\/h3>\\r\\n    <p style=\\"margin-top: 5px; margin-bottom: 0;\\">Updates for all devices<\\/p>\\r\\n<\\/div>"},"4fe055d3a06c3":{"title":"Tips","set":"","content":"<div class=\\"text-left frontpage-center\\" style=\\"width: 240px;\\">\\r\\n  <img class=\\"align-left\\" src=\\"images\\/yootheme\\/demo\\/slideset\\/icon_light_bulb.png\\" width=\\"48\\" height=\\"48\\" alt=\\"01\\" \\/>\\r\\n    <h3 style=\\"margin: 0; padding-top: 5px;\\">TIPS<\\/h3>\\r\\n    <p style=\\"margin-top: 5px; margin-bottom: 0;\\">How to use sphere<\\/p>\\r\\n<\\/div>"},"4fe055f14e07f":{"title":"Todo List","set":"","content":"<div class=\\"text-left frontpage-center\\" style=\\"width: 240px;\\">\\r\\n  <img class=\\"align-left\\" src=\\"images\\/yootheme\\/demo\\/slideset\\/icon_to_do.png\\" width=\\"48\\" height=\\"48\\" alt=\\"01\\" \\/>\\r\\n    <h3 style=\\"margin: 0; padding-top: 5px;\\">TO DO LIST<\\/h3>\\r\\n    <p style=\\"margin-top: 5px; margin-bottom: 0;\\">Plan your tasks<\\/p>\\r\\n<\\/div>"},"4fe055dfa2860":{"title":"Notes","set":"","content":"<div class=\\"text-left frontpage-center\\" style=\\"width: 240px;\\">\\r\\n  <img class=\\"align-left\\" src=\\"images\\/yootheme\\/demo\\/slideset\\/icon_notes.png\\" width=\\"48\\" height=\\"48\\" alt=\\"01\\" \\/>\\r\\n    <h3 style=\\"margin: 0; padding-top: 5px;\\">NOTES<\\/h3>\\r\\n    <p style=\\"margin-top: 5px; margin-bottom: 0;\\">Capture your ideas<\\/p>\\r\\n<\\/div>"},"4fe055c89e13d":{"title":"Customization","set":"","content":"<div class=\\"text-left frontpage-center\\" style=\\"width: 240px;\\">\\r\\n  <img class=\\"align-left\\" src=\\"images\\/yootheme\\/demo\\/slideset\\/icon_settings.png\\" width=\\"48\\" height=\\"48\\" alt=\\"01\\" \\/>\\r\\n    <h3 style=\\"margin: 0; padding-top: 5px;\\">MANY OPTIONS<\\/h3>\\r\\n    <p style=\\"margin-top: 5px; margin-bottom: 0;\\">To fit all your needs<\\/p>\\r\\n<\\/div>"}}}', '2012-06-19 10:36:08', '2012-07-23 09:07:38'),
(52, 'slideshow', 'sphere_tabs', 'Frontpage Tabs', '{"type":"slideshow","id":52,"name":"Frontpage Tabs","settings":{"style":"sphere_tabs","autoplay":0,"interval":5000,"width":"auto","height":"auto","duration":500,"index":0,"order":"default","navigation":"left","animated":"fade"},"style":"sphere_tabs","items":{"4fe0567ad5af6":{"title":"Quotes","content":"<ul class=\\"line\\">\\r\\n<li><a href=\\"#\\" style=\\"margin: 3px 0;\\">Easy for beginners<\\/a><img style=\\"margin-top: 10px;\\" src=\\"images\\/yootheme\\/stars_full.png\\" width=\\"100\\" height=\\"20\\" alt=\\"Icon 01\\" \\/><p style=\\"margin-top:5px;\\"> \\"For every function we offer an extensive tutorial with helpful tips and tricks.\\"<\\/p><\\/li>\\r\\n<li><a href=\\"#\\" style=\\"margin: 3px 0;\\">Filters and special effects<\\/a><img style=\\"margin-top: 10px;\\" src=\\"images\\/yootheme\\/stars_empty.png\\" width=\\"100\\" height=\\"20\\" alt=\\"Icon 01\\" \\/><p style=\\"margin-top:5px;\\"> \\"Includes an easily manageable filter library.\\"<\\/p><\\/li>\\r\\n<\\/ul>\\r\\n","caption":""},"4fe056962586f":{"title":"News","content":"<ul class=\\"line\\">\\r\\n<li>\\r\\n  <h4 style=\\"margin-top: 0;\\"><strong>New Filters<\\/strong><\\/h4>\\r\\n  <p>Our filter gallery has been extended by 10 new effects.<br \\/> \\r\\n    <a href=\\"#\\">Read more<\\/a>\\r\\n  <\\/p>\\r\\n<\\/li>\\r\\n<li>\\r\\n  <h6 style=\\"margin-top: 10px;\\"><strong>Cross Platforms<\\/strong><\\/h6>\\r\\n  <p>Sphere is available for OS X and Windows. One license is all you need to use it on every computer you own.<br \\/> \\r\\n    <a href=\\"#\\">Read more<\\/a><\\/p>\\r\\n<\\/li>\\r\\n<\\/ul>","caption":""},"4fe056a0de145":{"title":"Tags","content":"<ul class=\\"tagcloud\\">\\r\\n  <li><a href=\\"#\\">Tools<\\/a><\\/li>\\r\\n  <li><a href=\\"#\\">Better UI<\\/a><\\/li>\\r\\n  <li><a href=\\"#\\">100 New Features<\\/a><\\/li>\\r\\n  <li><a href=\\"#\\">Plugin API<\\/a><\\/li>\\r\\n  <li><a href=\\"#\\">Split Editing<\\/a><\\/li>\\r\\n  <li><a href=\\"#\\">Multiple Selections<\\/a><\\/li>\\r\\n  <li><a href=\\"#\\">New Update<\\/a><\\/li>\\r\\n  <li><a href=\\"#\\">Cross Platforms<\\/a><\\/li>\\r\\n  <li><a href=\\"#\\">Responsive<\\/a><\\/li>\\r\\n  <li><a href=\\"#\\">HTML5<\\/a><\\/li>\\r\\n  <li><a href=\\"#\\">CSS3<\\/a><\\/li>\\r\\n<\\/ul>","caption":""}}}', '2012-06-19 10:38:50', '2012-07-23 11:42:41'),
(53, 'slideshow', 'default', 'Home Slideshow', '{"type":"slideshow","id":53,"name":"Home Slideshow","settings":{"style":"default","autoplay":1,"interval":4000,"width":"auto","height":"auto","duration":500,"index":1,"order":"default","navigation":1,"buttons":1,"slices":20,"animated":"fade","caption_animation_duration":500},"style":"default","zoo":{"params":{"application":"3","mode":"types","category":"5","type":"tac-pham","subcategories":"1","count":"9","order":["_itemname","","","","","_random"],"layout":"article","media_position":"right"}}}', '2014-09-18 17:41:12', '2014-10-08 10:05:35'),
(54, 'slideset', 'default', 'Văn học cổ điển', '{"type":"slideset","id":54,"name":"V\\u0103n h\\u1ecdc c\\u1ed5 \\u0111i\\u1ec3n","settings":{"style":"default","width":"auto","height":"auto","effect":"slide","index":0,"autoplay":1,"interval":5000,"items_per_set":3,"navigation":1,"buttons":1,"title":1,"duration":300},"style":"default","zoo":{"params":{"application":"3","mode":"categories","category":"3","type":"movie","subcategories":"0","count":"18","order":["_itempublish_up","","","","","_random"],"layout":"image","media_position":"left"}}}', '2014-09-18 17:53:17', '2014-10-08 10:28:00'),
(55, 'slideset', 'default', 'Sách ngẫu nhiên', '{"type":"slideset","id":55,"name":"S\\u00e1ch ng\\u1eabu nhi\\u00ean","settings":{"style":"default","width":"auto","height":"auto","effect":"deck","index":20,"autoplay":1,"interval":6000,"items_per_set":1,"navigation":1,"buttons":1,"title":0,"duration":300},"style":"default","zoo":{"params":{"application":"3","mode":"types","category":"","type":"tac-pham","subcategories":"1","count":"6","order":["_itemname","","","","","_random"],"layout":"image","media_position":"left"}}}', '2014-09-22 14:25:47', '2014-10-08 08:05:46'),
(56, 'slideset', 'default', 'Sách đọc nhiều', '{"type":"slideset","id":56,"name":"S\\u00e1ch \\u0111\\u1ecdc nhi\\u1ec1u","settings":{"style":"default","width":"auto","height":"auto","effect":"slide","index":0,"autoplay":1,"interval":5000,"items_per_set":1,"navigation":1,"buttons":0,"title":0,"duration":300},"style":"default","zoo":{"params":{"application":"3","mode":"types","category":"","type":"tac-pham","subcategories":"1","count":"6","order":["_itemhits","","","",""],"layout":"image","media_position":"left"}}}', '2014-09-22 14:27:01', '2014-09-30 10:04:28'),
(57, 'slideset', 'default', 'Sách mới đăng', '{"type":"slideset","id":57,"name":"S\\u00e1ch m\\u1edbi \\u0111\\u0103ng","settings":{"style":"default","width":"auto","height":"auto","effect":"drops","index":0,"autoplay":1,"interval":4000,"items_per_set":1,"navigation":1,"buttons":1,"title":0,"duration":300},"style":"default","zoo":{"params":{"application":"3","mode":"types","category":"","type":"tac-pham","subcategories":"1","count":"6","order":["_itempublish_up","","","",""],"layout":"image","media_position":"left"}}}', '2014-09-22 14:33:20', '2014-09-30 10:00:37'),
(59, 'slideset', 'default', 'Văn học Việt Nam', '{"type":"slideset","id":0,"name":"V\\u0103n h\\u1ecdc Vi\\u1ec7t Nam","settings":{"style":"default","width":"auto","height":"auto","effect":"drops","index":0,"autoplay":1,"interval":5000,"items_per_set":3,"navigation":1,"buttons":1,"title":1,"duration":300},"style":"default","zoo":{"params":{"application":"3","mode":"categories","category":"1","type":"movie","subcategories":"1","count":"18","order":["_itemname","","","","","_random"],"layout":"article","media_position":"left"}}}', '2014-10-08 10:14:59', '2014-10-08 10:14:59'),
(60, 'slideset', 'default', 'Tiểu thuyết', '{"type":"slideset","id":0,"name":"Ti\\u1ec3u thuy\\u1ebft","settings":{"style":"default","width":"auto","height":"auto","effect":"deck","index":0,"autoplay":1,"interval":5000,"items_per_set":3,"navigation":1,"buttons":1,"title":1,"duration":300},"style":"default","zoo":{"params":{"application":"3","mode":"categories","category":"9","type":"movie","subcategories":"1","count":"18","order":["_itemname","","","","84202d33-adbc-4a87-9113-fb286416ee4f","_random"],"layout":"article","media_position":"left"}}}', '2014-10-08 10:16:28', '2014-10-08 10:16:28'),
(61, 'slideset', 'default', 'Học trò Thiếu nhi', '{"type":"slideset","id":61,"name":"H\\u1ecdc tr\\u00f2 Thi\\u1ebfu nhi","settings":{"style":"default","width":"auto","height":"auto","effect":"zoom","index":0,"autoplay":1,"interval":5000,"items_per_set":3,"navigation":1,"buttons":1,"title":0,"duration":300},"style":"default","zoo":{"params":{"application":"3","mode":"categories","category":"5","type":"movie","subcategories":"1","count":"18","order":["_itemname","","","","","_random"],"layout":"article","media_position":"top"}}}', '2014-10-08 10:18:16', '2014-10-14 11:31:57'),
(62, 'slideset', 'default', 'Trinh thám Hình sự', '{"type":"slideset","id":0,"name":"Trinh th\\u00e1m H\\u00ecnh s\\u1ef1","settings":{"style":"default","width":"auto","height":"auto","effect":"slide","index":0,"autoplay":1,"interval":5000,"items_per_set":3,"navigation":1,"buttons":0,"title":1,"duration":300},"style":"default","zoo":{"params":{"application":"3","mode":"categories","category":"12","type":"movie","subcategories":"1","count":"18","order":["_itemname","","","","","_random"],"layout":"article","media_position":"left"}}}', '2014-10-08 10:19:09', '2014-10-08 10:19:09'),
(63, 'slideset', 'default', 'Truyện ma Kinh dị', '{"type":"slideset","id":0,"name":"Truy\\u1ec7n ma Kinh d\\u1ecb","settings":{"style":"default","width":"auto","height":"auto","effect":"slide","index":0,"autoplay":1,"interval":5000,"items_per_set":3,"navigation":1,"buttons":0,"title":1,"duration":300},"style":"default","zoo":{"params":{"application":"3","mode":"categories","category":"11","type":"movie","subcategories":"1","count":"18","order":["_itemname","","","","","_random"],"layout":"article","media_position":"left"}}}', '2014-10-08 10:20:29', '2014-10-08 10:20:29'),
(64, 'slideset', '', '', '{"type":"slideset","id":null,"name":null,"settings":null,"style":null,"zoo":null}', '2014-10-09 01:35:34', '2014-10-09 01:35:34');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_zoo_application`
--

CREATE TABLE IF NOT EXISTS `zjw8d_zoo_application` (
`id` int(11) NOT NULL,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `application_group` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `params` text NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `zjw8d_zoo_application`
--

INSERT INTO `zjw8d_zoo_application` (`id`, `asset_id`, `name`, `alias`, `application_group`, `description`, `params`) VALUES
(1, 70, 'Bài viết đơn', 'bai-viet-don', 'page', '', ' {\n	"group": "page",\n	"template": "default",\n	"global.template.item_media_alignment": "right",\n	"global.template.show_item_meta": "1",\n	"global.template.show_item_related": "1",\n	"global.comments.enable_comments": "1",\n	"global.comments.require_name_and_mail": "1",\n	"global.comments.registered_users_only": "0",\n	"global.comments.approved": "0",\n	"global.comments.time_between_user_posts": "120",\n	"global.comments.email_notification": "contact.epubviet@gmail.com",\n	"global.comments.email_reply_notification": "1",\n	"global.comments.avatar": "1",\n	"global.comments.order": "ASC",\n	"global.comments.max_depth": "5",\n	"global.comments.facebook_enable": "0",\n	"global.comments.facebook_app_id": "",\n	"global.comments.facebook_app_secret": "",\n	"global.comments.twitter_enable": "0",\n	"global.comments.twitter_consumer_key": "",\n	"global.comments.twitter_consumer_secret": "",\n	"global.comments.akismet_enable": "0",\n	"global.comments.akismet_api_key": "",\n	"global.comments.mollom_enable": "0",\n	"global.comments.mollom_public_key": "",\n	"global.comments.mollom_private_key": "",\n	"global.comments.captcha": "",\n	"global.comments.captcha_guest_only": "1",\n	"global.comments.blacklist": ""\n}'),
(2, 72, 'Liên hệ', 'lien-he', 'business', '', ' {\n	"group": "business",\n	"template": "default",\n	"global.config.items_per_page": "15",\n	"global.config.item_order":  {\n		"0": "_itemname",\n		"1": "",\n		"2": ""\n	},\n	"global.config.alpha_index": "2",\n	"global.config.show_feed_link": "0",\n	"global.config.feed_title": "",\n	"global.config.alternate_feed_link": "",\n	"global.config.show_empty_categories": "0",\n	"global.template.show_alpha_index": "1",\n	"global.template.show_title": "1",\n	"global.template.show_description": "1",\n	"global.template.show_image": "1",\n	"global.template.alignment": "left",\n	"global.template.show_categories": "1",\n	"global.template.categories_cols": "4",\n	"global.template.categories_order": "1",\n	"global.template.show_categories_titles": "1",\n	"global.template.show_categories_item_count": "1",\n	"global.template.show_categories_descriptions": "1",\n	"global.template.show_categories_images": "1",\n	"global.template.show_sub_categories": "1",\n	"global.template.show_sub_categories_item_count": "1",\n	"global.template.items_cols": "2",\n	"global.template.show_items_titles": "1",\n	"global.template.items_media_alignment": "left",\n	"global.template.item_sidebar_alignment": "right",\n	"global.comments.enable_comments": "1",\n	"global.comments.require_name_and_mail": "1",\n	"global.comments.registered_users_only": "0",\n	"global.comments.approved": "0",\n	"global.comments.time_between_user_posts": "120",\n	"global.comments.email_notification": "contact.epubviet@gmail.com",\n	"global.comments.email_reply_notification": "0",\n	"global.comments.avatar": "1",\n	"global.comments.order": "ASC",\n	"global.comments.max_depth": "5",\n	"global.comments.facebook_enable": "0",\n	"global.comments.facebook_app_id": "",\n	"global.comments.facebook_app_secret": "",\n	"global.comments.twitter_enable": "0",\n	"global.comments.twitter_consumer_key": "",\n	"global.comments.twitter_consumer_secret": "",\n	"global.comments.akismet_enable": "0",\n	"global.comments.akismet_api_key": "",\n	"global.comments.mollom_enable": "0",\n	"global.comments.mollom_public_key": "",\n	"global.comments.mollom_private_key": "",\n	"global.comments.captcha": "",\n	"global.comments.captcha_guest_only": "1",\n	"global.comments.blacklist": ""\n}'),
(3, 75, 'Sách truyện', 'sach-truyen', 'movie', '', ' {\n	"group": "movie",\n	"template": "default",\n	"content.title": "Kho s\\u00e1ch Th\\u01b0 vi\\u1ec7n ePub Vi\\u1ec7t",\n	"content.subtitle": "H\\u00e0ng tr\\u0103m ngh\\u00ecn cu\\u1ed1n \\u0111\\u1ecbnh d\\u1ea1ng epub (+prc)",\n	"content.image": "images\\/epub-library\\/lib\\/library.png",\n	"content.image_width": "",\n	"content.image_height": "",\n	"template.show_categories_descriptions": "0",\n	"template.show_sub_categories": "0",\n	"template.show_sub_categories_item_count": "0",\n	"global.config.items_per_page": "36",\n	"global.config.item_order":  {\n		"0": "_itemname",\n		"1": "",\n		"2": "",\n		"3": "",\n		"4": ""\n	},\n	"global.config.alpha_index": "2",\n	"global.config.show_feed_link": "0",\n	"global.config.feed_title": "",\n	"global.config.alternate_feed_link": "",\n	"global.config.show_empty_categories": "1",\n	"global.template.show_alpha_index": "1",\n	"global.template.show_title": "1",\n	"global.template.show_description": "1",\n	"global.template.show_image": "1",\n	"global.template.alignment": "center",\n	"global.template.show_categories": "1",\n	"global.template.categories_cols": "4",\n	"global.template.categories_order": "1",\n	"global.template.show_categories_titles": "1",\n	"global.template.show_categories_item_count": "1",\n	"global.template.show_categories_descriptions": "1",\n	"global.template.show_categories_images": "1",\n	"global.template.show_sub_categories": "1",\n	"global.template.show_sub_categories_item_count": "1",\n	"global.template.show_sub_categories_items": "0",\n	"global.template.items_cols": "5",\n	"global.template.items_media_alignment": "center",\n	"global.template.item_sidebar_alignment": "right",\n	"global.template.show_spoiler_warning": "0",\n	"global.comments.enable_comments": "1",\n	"global.comments.require_name_and_mail": "1",\n	"global.comments.registered_users_only": "0",\n	"global.comments.approved": "0",\n	"global.comments.time_between_user_posts": "120",\n	"global.comments.email_notification": "",\n	"global.comments.email_reply_notification": "0",\n	"global.comments.avatar": "1",\n	"global.comments.order": "ASC",\n	"global.comments.max_depth": "5",\n	"global.comments.facebook_enable": "1",\n	"global.comments.facebook_app_id": "475742735814268",\n	"global.comments.facebook_app_secret": "cf55c041c47f480781d7fb51ec0b759a",\n	"global.comments.twitter_enable": "1",\n	"global.comments.twitter_consumer_key": "Q5hbwivftmWGun4lCIrTw",\n	"global.comments.twitter_consumer_secret": "9XrofyGnFPazgmQqnXET8PH5kVrC0mxKA76Skx6YSA8",\n	"global.comments.akismet_enable": "1",\n	"global.comments.akismet_api_key": "e42600efcc61",\n	"global.comments.mollom_enable": "0",\n	"global.comments.mollom_public_key": "",\n	"global.comments.mollom_private_key": "",\n	"global.comments.captcha": "recaptcha",\n	"global.comments.captcha_guest_only": "1",\n	"global.comments.blacklist": "l\\u1ed3n, \\u0111\\u1ecbt, bu\\u1ed3i, fuck"\n}'),
(4, 80, 'Văn hóa đọc', 'van-hoa-doc', 'blog', '', ' {\n	"group": "blog",\n	"template": "warp6",\n	"global.config.items_per_page": "15",\n	"global.config.item_order":  {\n		"0": "_itemname",\n		"1": "",\n		"2": "",\n		"3": "",\n		"4": ""\n	},\n	"global.config.show_feed_link": "1",\n	"global.config.feed_title": "",\n	"global.config.alternate_feed_link": "",\n	"global.template.show_title": "1",\n	"global.template.show_description": "1",\n	"global.template.show_image": "1",\n	"global.template.alignment": "left",\n	"global.template.date": "0",\n	"global.template.date_format": "%d||%B||%Y",\n	"global.template.items_cols": "1",\n	"global.template.items_order": "0",\n	"global.template.teaseritem_media_alignment": "left",\n	"global.template.item_media_alignment": "left",\n	"global.comments.enable_comments": "1",\n	"global.comments.require_name_and_mail": "1",\n	"global.comments.registered_users_only": "0",\n	"global.comments.approved": "0",\n	"global.comments.time_between_user_posts": "120",\n	"global.comments.email_notification": "",\n	"global.comments.email_reply_notification": "0",\n	"global.comments.avatar": "1",\n	"global.comments.order": "ASC",\n	"global.comments.max_depth": "5",\n	"global.comments.facebook_enable": "0",\n	"global.comments.facebook_app_id": "",\n	"global.comments.facebook_app_secret": "",\n	"global.comments.twitter_enable": "0",\n	"global.comments.twitter_consumer_key": "",\n	"global.comments.twitter_consumer_secret": "",\n	"global.comments.akismet_enable": "0",\n	"global.comments.akismet_api_key": "",\n	"global.comments.mollom_enable": "0",\n	"global.comments.mollom_public_key": "",\n	"global.comments.mollom_private_key": "",\n	"global.comments.captcha": "",\n	"global.comments.captcha_guest_only": "1",\n	"global.comments.blacklist": ""\n}');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_zoo_category`
--

CREATE TABLE IF NOT EXISTS `zjw8d_zoo_category` (
`id` int(11) NOT NULL,
  `application_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `parent` int(11) NOT NULL,
  `ordering` int(11) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `params` text NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=62 ;

--
-- Dumping data for table `zjw8d_zoo_category`
--

INSERT INTO `zjw8d_zoo_category` (`id`, `application_id`, `name`, `alias`, `description`, `parent`, `ordering`, `published`, `params`) VALUES
(1, 3, 'Văn học Việt Nam', 'van-hoc-viet-nam', '', 36, 2, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(2, 3, 'Văn học nước ngoài', 'van-hoc-nuoc-ngoai', '', 36, 1, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(3, 3, 'Văn học cổ điển', 'van-hoc-co-dien', '', 36, 0, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(4, 3, 'Thi ca - Ngụ ngôn', 'thi-ca-ngu-ngon', '', 0, 10, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(5, 3, 'Học trò - Thiếu nhi', 'hoc-tro-thieu-nhi', '', 0, 3, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(6, 3, 'Tuổi học trò', 'tuoi-hoc-tro', '', 5, 1, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(7, 3, 'Thiếu nhi', 'thieu-nhi', '', 5, 0, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(8, 3, 'Ngôn tình Trung Quốc', 'ngon-tinh-trung-quoc', '', 9, 0, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(9, 3, 'Tiểu thuyết Tình cảm', 'tieu-thuyet-tinh-cam', '', 0, 11, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(10, 3, 'Viễn tưởng - Thần thoại', 'vien-tuong-than-thoai', '', 0, 19, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(11, 3, 'Truyện ma - Kinh dị', 'truyen-ma-kinh-di', '', 0, 15, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(12, 3, 'Trinh thám - Hình sự', 'trinh-tham-hinh-su', '', 0, 12, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(13, 3, 'Truyện chưởng', 'truyen-chuong', '', 0, 13, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(14, 3, 'Kiếm hiệp', 'kiem-hiep', '', 13, 0, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(15, 3, 'Sắc hiệp', 'sac-hiep', '', 13, 2, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(16, 3, 'Tiên hiệp', 'tien-hiep', '', 13, 1, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(17, 3, 'Dã sử', 'da-su', '', 19, 0, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(18, 3, 'Văn hóa - Xã hội', 'van-hoa-xa-hoi', '', 0, 17, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(19, 3, 'Lịch sử - Địa lý', 'lich-su-dia-ly', '', 0, 7, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(20, 3, 'Chứng khoán Đầu tư', 'chung-khoan-dau-tu', '', 25, 2, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(36, 3, 'Văn học', 'van-hoc', '', 0, 18, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(21, 3, 'Địa lý', 'dia-ly', '', 19, 4, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(22, 3, 'Khoa học - Kĩ thuật', 'khoa-hoc-ki-thuat', '', 0, 5, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(23, 3, 'Khoa học', 'khoa-hoc', '', 22, 0, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(24, 3, 'Kĩ thuật', 'ki-thuat', '', 22, 1, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(25, 3, 'Kinh tế - Pháp luật', 'kinh-te-phap-luat', '', 0, 6, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(26, 3, 'Quản trị Kinh doanh', 'quan-tri-kinh-doanh', '', 25, 1, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(27, 3, 'Kiến thức Pháp luật', 'kien-thuc-phap-luat', '', 25, 3, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(28, 3, 'Tâm lý - Giới tính', 'tam-ly-gioi-tinh', '', 0, 9, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(29, 3, 'Tâm lý', 'tam-ly', '', 28, 0, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(30, 3, 'Giới tính', 'gioi-tinh', '', 28, 1, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(31, 3, 'Nghệ thuật sống', 'nghe-thuat-song', '', 18, 1, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(32, 3, 'Giáo trình', 'giao-trinh', '', 0, 2, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(33, 3, 'Chuyên ngành', 'chuyen-nganh', '', 0, 1, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(34, 3, 'Tự sáng tác', 'tu-sang-tac', '', 0, 16, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(35, 3, 'Chưa phân loại', 'chua-phan-loai', '', 0, 0, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(39, 3, 'Khoa học thường thức', 'khoa-hoc-thuong-thuc', '', 18, 0, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(37, 3, 'Thi ca', 'thi-ca', '', 4, 0, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(38, 3, 'Ngụ ngôn', 'ngu-ngon', '', 4, 1, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(40, 3, 'Trinh thám', 'trinh-tham', '', 12, 0, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(41, 3, 'Hình sự', 'hinh-su', '', 12, 1, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(42, 3, 'Sử thi', 'su-thi', '', 19, 1, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(43, 3, 'Lịch sử Việt Nam', 'lich-su-viet-nam', '', 19, 3, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(44, 3, 'Lịch sử Thế giới', 'lich-su-the-gioi', '', 19, 2, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(45, 3, 'Bài học Thành công', 'bai-hoc-thanh-cong', '', 25, 0, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(46, 3, 'Viễn tưởng', 'vien-tuong', '', 10, 0, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(50, 3, 'Phiêu lưu - Mạo hiểm', 'phieu-luu-mao-hiem', '', 0, 8, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(47, 3, 'Thần thoại', 'than-thoai', '', 10, 1, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(48, 3, 'Truyện ma', 'truyen-ma', '', 11, 0, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(49, 3, 'Kinh dị', 'kinh-di', '', 11, 1, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(51, 3, 'Phiêu lưu', 'phieu-luu', '', 50, 0, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(52, 3, 'Mạo hiểm', 'mao-hiem', '', 50, 1, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(53, 3, 'Hồi ký - Nhật ký', 'hoi-ky-nhat-ky', '', 0, 4, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(54, 3, 'Hồi ký', 'hoi-ky', '', 53, 0, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(55, 3, 'Nhật ký', 'nhat-ky', '', 53, 1, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(56, 3, 'Truyện cười - Dân gian', 'truyen-cuoi-dan-gian', '', 0, 14, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(57, 3, 'Truyện cười Tiếu lâm', 'truyen-cuoi-tieu-lam', '', 56, 0, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(59, 4, 'Đọc sách', 'doc-sach', '', 0, 2, 1, ' {\n	"content.subtitle": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(58, 3, 'Truyện Dân gian', 'truyen-dan-gian', '', 56, 1, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(60, 4, 'Sách & Giá trị của sách', 'sach-va-gia-tri-cua-sach', '', 0, 1, 1, ' {\n	"content.subtitle": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}'),
(61, 3, 'Tác giả', 'tac-gia', '', 0, 20, 1, ' {\n	"content.teaser_description": "",\n	"content.teaser_image": "",\n	"content.teaser_image_width": "",\n	"content.teaser_image_height": "",\n	"content.image": "",\n	"content.image_width": "",\n	"content.image_height": "",\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": ""\n}');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_zoo_category_item`
--

CREATE TABLE IF NOT EXISTS `zjw8d_zoo_category_item` (
  `category_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_zoo_category_item`
--

INSERT INTO `zjw8d_zoo_category_item` (`category_id`, `item_id`) VALUES
(0, 1),
(0, 2),
(0, 3),
(0, 4),
(0, 5),
(0, 6),
(0, 7),
(0, 8),
(0, 9),
(0, 10),
(0, 11),
(0, 12),
(0, 13),
(5, 6),
(5, 7),
(5, 8),
(5, 9),
(5, 10),
(5, 11),
(5, 13),
(6, 12),
(6, 13),
(7, 13),
(10, 6),
(10, 7),
(10, 8),
(10, 9),
(10, 10),
(10, 11),
(10, 12),
(10, 13),
(46, 6),
(46, 7),
(46, 8),
(46, 9),
(46, 10),
(46, 11),
(46, 12),
(46, 13),
(61, 13);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_zoo_comment`
--

CREATE TABLE IF NOT EXISTS `zjw8d_zoo_comment` (
`id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `content` text NOT NULL,
  `state` tinyint(4) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `zjw8d_zoo_comment`
--

INSERT INTO `zjw8d_zoo_comment` (`id`, `parent_id`, `item_id`, `user_id`, `user_type`, `author`, `email`, `url`, `ip`, `created`, `content`, `state`) VALUES
(1, 0, 8, '', '', 'Họ tên', 'email@mail.com', 'http://www.epubviet.com', '::1', '2014-10-15 00:59:08', 'Nội dung', 0),
(2, 0, 10, '', '', 'Họ tên', 'email@mail.com', 'http://epubviet.com', '::1', '2014-10-17 11:51:09', 'tessst capchapt', 0);

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_zoo_item`
--

CREATE TABLE IF NOT EXISTS `zjw8d_zoo_item` (
`id` int(11) NOT NULL,
  `application_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `publish_up` datetime NOT NULL,
  `publish_down` datetime NOT NULL,
  `priority` int(11) NOT NULL,
  `hits` int(11) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `access` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_by_alias` varchar(255) NOT NULL,
  `searchable` int(11) NOT NULL,
  `elements` longtext NOT NULL,
  `params` longtext NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `zjw8d_zoo_item`
--

INSERT INTO `zjw8d_zoo_item` (`id`, `application_id`, `type`, `name`, `alias`, `created`, `modified`, `modified_by`, `publish_up`, `publish_down`, `priority`, `hits`, `state`, `access`, `created_by`, `created_by_alias`, `searchable`, `elements`, `params`) VALUES
(1, 1, 'page', 'Giới thiệu', 'gioi-thieu', '2014-09-18 04:30:52', '2014-09-18 04:35:17', 584, '2014-09-18 04:30:52', '0000-00-00 00:00:00', 0, 5, 1, 1, 584, '', 1, ' {\n	"6cb20a9f-27fa-4d98-ac2e-e959eb3f0f63":  {\n		"file": "",\n		"title": "",\n		"link": "",\n		"target": "0",\n		"rel": "",\n		"lightbox_image": "",\n		"spotlight_effect": "",\n		"caption": ""\n	},\n	"43aa1b15-986e-4303-afcf-628b835f10e5":  {\n		"0":  {\n			"value": ""\n		}\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": ""\n}'),
(2, 1, 'page', 'Ủng hộ', 'ung-ho', '2014-09-18 04:35:21', '2014-09-18 04:42:27', 584, '2014-09-18 04:35:21', '0000-00-00 00:00:00', 0, 0, 1, 1, 584, '', 1, ' {\n	"6cb20a9f-27fa-4d98-ac2e-e959eb3f0f63":  {\n		"file": "",\n		"title": "",\n		"link": "",\n		"target": "0",\n		"rel": "",\n		"lightbox_image": "",\n		"spotlight_effect": "",\n		"caption": ""\n	},\n	"43aa1b15-986e-4303-afcf-628b835f10e5":  {\n		"0":  {\n			"value": ""\n		}\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": ""\n}'),
(3, 1, 'page', 'Hướng dẫn gửi sách', 'huong-dan-gui-sach', '2014-09-18 04:42:32', '2014-09-18 04:43:19', 584, '2014-09-18 04:42:32', '0000-00-00 00:00:00', 0, 0, 1, 1, 584, '', 1, ' {\n	"6cb20a9f-27fa-4d98-ac2e-e959eb3f0f63":  {\n		"file": "",\n		"title": "",\n		"link": "",\n		"target": "0",\n		"rel": "",\n		"lightbox_image": "",\n		"spotlight_effect": "",\n		"caption": ""\n	},\n	"43aa1b15-986e-4303-afcf-628b835f10e5":  {\n		"0":  {\n			"value": ""\n		}\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": ""\n}'),
(4, 2, 'employee', 'ePub Việt', 'epub-viet', '2014-09-18 04:50:13', '2014-09-18 04:52:23', 584, '2014-09-18 04:50:13', '0000-00-00 00:00:00', 0, 0, 1, 1, 584, '', 1, ' {\n	"96624fe5-ff5a-4f1b-800e-a125e3980d43":  {\n		"file": "",\n		"title": "",\n		"link": "",\n		"target": "0",\n		"rel": "",\n		"lightbox_image": "",\n		"spotlight_effect": "",\n		"caption": ""\n	},\n	"507fbea1-7974-4a67-aec8-3649cc41a067":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"241905cc-36d4-4611-a1d5-fadfe280f70e":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"59788cf7-338f-47b4-8eb2-9a9e8eb36fbf":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"b05cdf78-0375-457f-897a-f68f7ce0a776":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"subject": "",\n			"body": ""\n		}\n	},\n	"3adbf326-7845-4e0d-8a11-cd631a829e96":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "0",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"9f6a2113-ff5b-4974-9c19-5cb8eafb41ef":  {\n\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": ""\n}'),
(5, 2, 'company', 'ePub Việt', 'thong-tin-lien-he', '2014-09-18 04:52:29', '2014-09-18 04:52:46', 584, '2014-09-18 04:52:29', '0000-00-00 00:00:00', 0, 0, 1, 1, 584, '', 1, ' {\n	"ed9cdd4c-ae8b-4ecb-bca7-e12a5153bc02":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"a77f06fc-1561-453c-a429-8dd05cdc29f5":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"1a85a7a6-2aba-4480-925b-6b97d311ee6c":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"ffcc1c50-8dbd-4115-b463-b43bdcd44a57":  {\n		"file": "",\n		"title": "",\n		"link": "",\n		"target": "0",\n		"rel": "",\n		"lightbox_image": "",\n		"spotlight_effect": "",\n		"caption": ""\n	},\n	"4339a108-f907-4661-9aab-d6f3f00e736e":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"ea0666d7-51e3-4e52-8617-25e3ad61f8b8":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"90a18889-884b-4d53-a302-4e6e4595efa0":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"6a20c005-7bd3-4014-919a-6edfd2239284":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"81c5f642-2f7f-491f-b1c2-ce32ec688125":  {\n\n	},\n	"b870164b-fe78-45b0-b840-8ebceb9b9cb6":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"8a91aab2-7862-4a04-bd28-07f1ff4acce5":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"3f15b5e4-0dea-4114-a870-1106b85248de":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"subject": "",\n			"body": ""\n		}\n	},\n	"0b3d983e-b2fa-4728-afa0-a0b640fa34dc":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "0",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"7056f1d2-5253-40b6-8efd-d289b10a8c69":  {\n\n	},\n	"cf6dd846-5774-47aa-8ca7-c1623c06e130":  {\n		"votes": 0,\n		"value": 0\n	},\n	"160bd40a-3e0e-48de-b6cd-56cdcc9db892":  {\n		"location": ""\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": ""\n}'),
(6, 3, 'tac-pham', 'Harry Potter và Hòn đá phù thủy', 'harry-potter-va-hon-da-phu-thuy', '2014-09-30 09:12:17', '2014-09-30 09:38:49', 585, '2014-09-30 09:12:17', '0000-00-00 00:00:00', 0, 1, 1, 1, 585, '', 1, ' {\n	"84202d33-adbc-4a87-9113-fb286416ee4f":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"c57cb1d8-2195-43e8-a1f6-bfee0c025973":  {\n		"option":  {\n			"0": "tieng-viet"\n		},\n		"select": "1"\n	},\n	"252d93a7-e9d3-40f9-b56d-155faf1faa10":  {\n		"file": "images\\/epub-library\\/works\\/demo_large.jpg",\n		"title": "",\n		"link": "",\n		"target": "0",\n		"rel": "",\n		"lightbox_image": "",\n		"spotlight_effect": "",\n		"caption": "",\n		"width": 245,\n		"height": 350\n	},\n	"77132b90-fe4f-40a1-963f-4e8c8749a55d":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"f808f10a-b32d-4350-9e2c-26329877979d":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"0081b1b9-23c7-4e9d-aacb-c2caa3b2adb5":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"8a57c3e5-8e00-4ae9-b3da-7d844af9ab9e":  {\n\n	},\n	"5955ce16-9453-4ee5-b2b4-edb148ceb5fb":  {\n\n	},\n	"5c0566bd-581c-4404-8947-c621d98b39df":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"84cc9780-390e-4b50-92df-df2f4c15d35f":  {\n		"votes": 0,\n		"value": 0\n	},\n	"8c504b3c-6667-4f5b-8aae-e84ffd33e083":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "1",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"4c16262a-2080-4d3d-ba85-82e4c629065b":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "1",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"284cc0f3-b896-4ddd-a9d4-80b1e60fa4eb":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "0",\n			"custom_title": "",\n			"rel": ""\n		}\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": "46"\n}'),
(7, 3, 'tac-pham', 'Harry Potter và Chiếc cốc lửa', 'harry-potter-va-chiec-coc-lua', '2014-09-30 09:35:29', '2014-10-09 01:43:15', 585, '2014-09-30 09:12:17', '0000-00-00 00:00:00', 0, 0, 1, 1, 585, '', 1, ' {\n	"84202d33-adbc-4a87-9113-fb286416ee4f":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"c57cb1d8-2195-43e8-a1f6-bfee0c025973":  {\n		"option":  {\n			"0": "tieng-viet"\n		},\n		"select": "1"\n	},\n	"252d93a7-e9d3-40f9-b56d-155faf1faa10":  {\n		"file": "images\\/epub-library\\/works\\/demo_large.jpg",\n		"title": "",\n		"link": "",\n		"target": "0",\n		"rel": "",\n		"lightbox_image": "",\n		"spotlight_effect": "",\n		"caption": "",\n		"width": 245,\n		"height": 350\n	},\n	"77132b90-fe4f-40a1-963f-4e8c8749a55d":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"f808f10a-b32d-4350-9e2c-26329877979d":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"0081b1b9-23c7-4e9d-aacb-c2caa3b2adb5":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"8a57c3e5-8e00-4ae9-b3da-7d844af9ab9e":  {\n\n	},\n	"5955ce16-9453-4ee5-b2b4-edb148ceb5fb":  {\n\n	},\n	"5c0566bd-581c-4404-8947-c621d98b39df":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"84cc9780-390e-4b50-92df-df2f4c15d35f":  {\n		"votes": 0,\n		"value": 0\n	},\n	"8c504b3c-6667-4f5b-8aae-e84ffd33e083":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "1",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"4c16262a-2080-4d3d-ba85-82e4c629065b":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "1",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"284cc0f3-b896-4ddd-a9d4-80b1e60fa4eb":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "0",\n			"custom_title": "",\n			"rel": ""\n		}\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": "46"\n}'),
(13, 3, 'tac-gia', 'J.K. Rowling', 'j-k-rowling', '2014-10-09 11:43:20', '2014-10-14 21:55:32', 585, '2014-10-09 11:43:20', '0000-00-00 00:00:00', 0, 1, 1, 1, 585, '', 1, ' {\n	"438ab2da-a715-4c8d-ad3d-28d056aced1f":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"17414f94-2fe5-40dd-b006-2eb12322fb5b":  {\n		"file": "",\n		"title": "",\n		"link": "",\n		"target": "0",\n		"rel": "",\n		"lightbox_image": "",\n		"spotlight_effect": "",\n		"caption": ""\n	},\n	"2994648a-c963-4351-9cb1-6c874c787431":  {\n		"0":  {\n			"value": "1965-07-30 17:00:00"\n		}\n	},\n	"9b49b9ac-2e16-4594-9d19-478ff1014a21":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"49b3364b-9404-42b8-95fa-852218e61801":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"5d781ac1-f2cb-412a-b1c2-908781180a30":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"65f1e002-59d3-4710-9690-b8685cb4aa81":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"18b5a3ef-ea7f-42f2-9f99-c5548bd2054f":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "0",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"380325d1-b7af-41ec-adcd-b29a8b02d46f":  {\n		"category":  {\n			"0": "46"\n		}\n	},\n	"75c55a0c-4460-4463-8e1c-2525ac4fbc13":  {\n		"item":  {\n			"0": "6",\n			"1": "11",\n			"2": "12",\n			"3": "7",\n			"4": "9",\n			"5": "8",\n			"6": "10"\n		}\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": "6"\n}'),
(8, 3, 'tac-pham', 'Harry Potter và Hội Phượng hoàng', 'harry-potter-va-hoi-phuong-hoang', '2014-09-30 09:39:24', '2014-10-09 15:19:04', 585, '2014-09-30 09:12:17', '0000-00-00 00:00:00', 0, 20, 1, 1, 585, '', 1, ' {\n	"84202d33-adbc-4a87-9113-fb286416ee4f":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"c57cb1d8-2195-43e8-a1f6-bfee0c025973":  {\n		"option":  {\n			"0": "tieng-viet"\n		},\n		"select": "1"\n	},\n	"252d93a7-e9d3-40f9-b56d-155faf1faa10":  {\n		"file": "images\\/epub-library\\/works\\/demo_large.jpg",\n		"title": "",\n		"link": "",\n		"target": "0",\n		"rel": "",\n		"lightbox_image": "",\n		"spotlight_effect": "",\n		"caption": "",\n		"width": 245,\n		"height": 350\n	},\n	"77132b90-fe4f-40a1-963f-4e8c8749a55d":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"f808f10a-b32d-4350-9e2c-26329877979d":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"0081b1b9-23c7-4e9d-aacb-c2caa3b2adb5":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"8a57c3e5-8e00-4ae9-b3da-7d844af9ab9e":  {\n		"item":  {\n			"0": "13"\n		}\n	},\n	"5955ce16-9453-4ee5-b2b4-edb148ceb5fb":  {\n\n	},\n	"5c0566bd-581c-4404-8947-c621d98b39df":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"84cc9780-390e-4b50-92df-df2f4c15d35f":  {\n		"votes": "1",\n		"value": "5.0000"\n	},\n	"8c504b3c-6667-4f5b-8aae-e84ffd33e083":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "1",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"4c16262a-2080-4d3d-ba85-82e4c629065b":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "1",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"284cc0f3-b896-4ddd-a9d4-80b1e60fa4eb":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "0",\n			"custom_title": "",\n			"rel": ""\n		}\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": "46"\n}'),
(9, 3, 'tac-pham', 'Harry Potter và Hoàng tử lai', 'harry-potter-va-hoang-tu-lai', '2014-09-30 09:39:32', '2014-10-09 01:43:19', 585, '2014-09-30 09:12:17', '0000-00-00 00:00:00', 0, 2, 1, 1, 585, '', 1, ' {\n	"84202d33-adbc-4a87-9113-fb286416ee4f":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"c57cb1d8-2195-43e8-a1f6-bfee0c025973":  {\n		"option":  {\n			"0": "tieng-viet"\n		},\n		"select": "1"\n	},\n	"252d93a7-e9d3-40f9-b56d-155faf1faa10":  {\n		"file": "images\\/epub-library\\/works\\/demo_large.jpg",\n		"title": "",\n		"link": "",\n		"target": "0",\n		"rel": "",\n		"lightbox_image": "",\n		"spotlight_effect": "",\n		"caption": "",\n		"width": 245,\n		"height": 350\n	},\n	"77132b90-fe4f-40a1-963f-4e8c8749a55d":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"f808f10a-b32d-4350-9e2c-26329877979d":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"0081b1b9-23c7-4e9d-aacb-c2caa3b2adb5":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"8a57c3e5-8e00-4ae9-b3da-7d844af9ab9e":  {\n\n	},\n	"5955ce16-9453-4ee5-b2b4-edb148ceb5fb":  {\n\n	},\n	"5c0566bd-581c-4404-8947-c621d98b39df":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"84cc9780-390e-4b50-92df-df2f4c15d35f":  {\n		"votes": 0,\n		"value": 0\n	},\n	"8c504b3c-6667-4f5b-8aae-e84ffd33e083":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "1",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"4c16262a-2080-4d3d-ba85-82e4c629065b":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "1",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"284cc0f3-b896-4ddd-a9d4-80b1e60fa4eb":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "0",\n			"custom_title": "",\n			"rel": ""\n		}\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": "46"\n}'),
(10, 3, 'tac-pham', 'Harry Potter và Bảo bối Tử thần', 'harry-potter-va-bao-boi-tu-than', '2014-09-30 09:39:39', '2014-09-30 10:06:51', 585, '2014-09-30 09:12:17', '0000-00-00 00:00:00', 0, 14, 1, 1, 585, '', 1, ' {\n	"84202d33-adbc-4a87-9113-fb286416ee4f":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"c57cb1d8-2195-43e8-a1f6-bfee0c025973":  {\n		"option":  {\n			"0": "tieng-viet"\n		},\n		"select": "1"\n	},\n	"252d93a7-e9d3-40f9-b56d-155faf1faa10":  {\n		"file": "images\\/epub-library\\/works\\/demo_large.jpg",\n		"title": "",\n		"link": "",\n		"target": "0",\n		"rel": "",\n		"lightbox_image": "",\n		"spotlight_effect": "",\n		"caption": "",\n		"width": 245,\n		"height": 350\n	},\n	"77132b90-fe4f-40a1-963f-4e8c8749a55d":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"f808f10a-b32d-4350-9e2c-26329877979d":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"0081b1b9-23c7-4e9d-aacb-c2caa3b2adb5":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"8a57c3e5-8e00-4ae9-b3da-7d844af9ab9e":  {\n\n	},\n	"5955ce16-9453-4ee5-b2b4-edb148ceb5fb":  {\n\n	},\n	"5c0566bd-581c-4404-8947-c621d98b39df":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"84cc9780-390e-4b50-92df-df2f4c15d35f":  {\n		"votes": 0,\n		"value": 0\n	},\n	"8c504b3c-6667-4f5b-8aae-e84ffd33e083":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "1",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"4c16262a-2080-4d3d-ba85-82e4c629065b":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "1",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"284cc0f3-b896-4ddd-a9d4-80b1e60fa4eb":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "0",\n			"custom_title": "",\n			"rel": ""\n		}\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": "46"\n}'),
(11, 3, 'tac-pham', 'Harry Potter và Phòng chứa bí mật', 'harry-potter-va-phong-chua-bi-mat', '2014-09-30 09:39:46', '2014-09-30 10:06:16', 585, '2014-09-30 09:12:17', '0000-00-00 00:00:00', 0, 0, 1, 1, 585, '', 1, ' {\n	"84202d33-adbc-4a87-9113-fb286416ee4f":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"c57cb1d8-2195-43e8-a1f6-bfee0c025973":  {\n		"option":  {\n			"0": "tieng-viet"\n		},\n		"select": "1"\n	},\n	"252d93a7-e9d3-40f9-b56d-155faf1faa10":  {\n		"file": "images\\/epub-library\\/works\\/demo_large.jpg",\n		"title": "",\n		"link": "",\n		"target": "0",\n		"rel": "",\n		"lightbox_image": "",\n		"spotlight_effect": "",\n		"caption": "",\n		"width": 245,\n		"height": 350\n	},\n	"77132b90-fe4f-40a1-963f-4e8c8749a55d":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"f808f10a-b32d-4350-9e2c-26329877979d":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"0081b1b9-23c7-4e9d-aacb-c2caa3b2adb5":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"8a57c3e5-8e00-4ae9-b3da-7d844af9ab9e":  {\n\n	},\n	"5955ce16-9453-4ee5-b2b4-edb148ceb5fb":  {\n\n	},\n	"5c0566bd-581c-4404-8947-c621d98b39df":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"84cc9780-390e-4b50-92df-df2f4c15d35f":  {\n		"votes": 0,\n		"value": 0\n	},\n	"8c504b3c-6667-4f5b-8aae-e84ffd33e083":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "1",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"4c16262a-2080-4d3d-ba85-82e4c629065b":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "1",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"284cc0f3-b896-4ddd-a9d4-80b1e60fa4eb":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "0",\n			"custom_title": "",\n			"rel": ""\n		}\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": "46"\n}'),
(12, 3, 'tac-pham', 'Harry Potter và Tên tù nhân ngục Azkaban', 'harry-potter-va-ten-tu-nhan-nguc-azkaban', '2014-09-30 11:11:34', '2014-09-30 11:12:25', 585, '2014-09-30 11:11:34', '0000-00-00 00:00:00', 0, 0, 1, 1, 585, '', 1, ' {\n	"84202d33-adbc-4a87-9113-fb286416ee4f":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"c57cb1d8-2195-43e8-a1f6-bfee0c025973":  {\n		"option":  {\n			"0": "tieng-viet",\n			"1": "tieng-anh"\n		},\n		"select": "1"\n	},\n	"252d93a7-e9d3-40f9-b56d-155faf1faa10":  {\n		"file": "",\n		"title": "",\n		"link": "",\n		"target": "0",\n		"rel": "",\n		"lightbox_image": "",\n		"spotlight_effect": "",\n		"caption": ""\n	},\n	"77132b90-fe4f-40a1-963f-4e8c8749a55d":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"f808f10a-b32d-4350-9e2c-26329877979d":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"0081b1b9-23c7-4e9d-aacb-c2caa3b2adb5":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"8a57c3e5-8e00-4ae9-b3da-7d844af9ab9e":  {\n\n	},\n	"5955ce16-9453-4ee5-b2b4-edb148ceb5fb":  {\n\n	},\n	"5c0566bd-581c-4404-8947-c621d98b39df":  {\n		"0":  {\n			"value": ""\n		}\n	},\n	"84cc9780-390e-4b50-92df-df2f4c15d35f":  {\n		"votes": 0,\n		"value": 0\n	},\n	"8c504b3c-6667-4f5b-8aae-e84ffd33e083":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "1",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"4c16262a-2080-4d3d-ba85-82e4c629065b":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "1",\n			"custom_title": "",\n			"rel": ""\n		}\n	},\n	"284cc0f3-b896-4ddd-a9d4-80b1e60fa4eb":  {\n		"0":  {\n			"value": "",\n			"text": "",\n			"target": "0",\n			"custom_title": "",\n			"rel": ""\n		}\n	}\n}', ' {\n	"metadata.title": "",\n	"metadata.description": "",\n	"metadata.keywords": "",\n	"metadata.robots": "",\n	"metadata.author": "",\n	"config.enable_comments": "1",\n	"config.primary_category": "10"\n}');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_zoo_rating`
--

CREATE TABLE IF NOT EXISTS `zjw8d_zoo_rating` (
`id` int(11) NOT NULL,
  `item_id` int(11) DEFAULT NULL,
  `element_id` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `value` tinyint(4) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `zjw8d_zoo_rating`
--

INSERT INTO `zjw8d_zoo_rating` (`id`, `item_id`, `element_id`, `user_id`, `value`, `ip`, `created`) VALUES
(1, 8, '84cc9780-390e-4b50-92df-df2f4c15d35f', 0, 5, '::1', '2014-10-14 22:18:31');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_zoo_search_index`
--

CREATE TABLE IF NOT EXISTS `zjw8d_zoo_search_index` (
  `item_id` int(11) NOT NULL,
  `element_id` varchar(255) NOT NULL,
  `value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_zoo_search_index`
--

INSERT INTO `zjw8d_zoo_search_index` (`item_id`, `element_id`, `value`) VALUES
(5, 'cf6dd846-5774-47aa-8ca7-c1623c06e130', '0.0'),
(6, 'c57cb1d8-2195-43e8-a1f6-bfee0c025973', 'Tiếng Việt'),
(6, '84cc9780-390e-4b50-92df-df2f4c15d35f', '0.0'),
(7, 'c57cb1d8-2195-43e8-a1f6-bfee0c025973', 'Tiếng Việt'),
(7, '84cc9780-390e-4b50-92df-df2f4c15d35f', '0.0'),
(8, '84cc9780-390e-4b50-92df-df2f4c15d35f', '5.0'),
(9, 'c57cb1d8-2195-43e8-a1f6-bfee0c025973', 'Tiếng Việt'),
(9, '84cc9780-390e-4b50-92df-df2f4c15d35f', '0.0'),
(10, 'c57cb1d8-2195-43e8-a1f6-bfee0c025973', 'Tiếng Việt'),
(10, '84cc9780-390e-4b50-92df-df2f4c15d35f', '0.0'),
(11, 'c57cb1d8-2195-43e8-a1f6-bfee0c025973', 'Tiếng Việt'),
(11, '84cc9780-390e-4b50-92df-df2f4c15d35f', '0.0'),
(8, 'c57cb1d8-2195-43e8-a1f6-bfee0c025973', 'Tiếng Việt'),
(12, 'c57cb1d8-2195-43e8-a1f6-bfee0c025973', 'Tiếng Việt\nTiếng Anh'),
(12, '84cc9780-390e-4b50-92df-df2f4c15d35f', '0.0'),
(13, '2994648a-c963-4351-9cb1-6c874c787431', '1965-07-30 17:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_zoo_submission`
--

CREATE TABLE IF NOT EXISTS `zjw8d_zoo_submission` (
`id` int(11) NOT NULL,
  `application_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `state` tinyint(3) NOT NULL,
  `access` int(11) NOT NULL,
  `params` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_zoo_tag`
--

CREATE TABLE IF NOT EXISTS `zjw8d_zoo_tag` (
  `item_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_zoo_tag`
--

INSERT INTO `zjw8d_zoo_tag` (`item_id`, `name`) VALUES
(7, 'Harry Potter'),
(7, 'JK Rowling');

-- --------------------------------------------------------

--
-- Table structure for table `zjw8d_zoo_version`
--

CREATE TABLE IF NOT EXISTS `zjw8d_zoo_version` (
  `version` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `zjw8d_zoo_version`
--

INSERT INTO `zjw8d_zoo_version` (`version`) VALUES
('3.2.2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `zjw8d_assets`
--
ALTER TABLE `zjw8d_assets`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `idx_asset_name` (`name`), ADD KEY `idx_lft_rgt` (`lft`,`rgt`), ADD KEY `idx_parent_id` (`parent_id`);

--
-- Indexes for table `zjw8d_associations`
--
ALTER TABLE `zjw8d_associations`
 ADD PRIMARY KEY (`context`,`id`), ADD KEY `idx_key` (`key`);

--
-- Indexes for table `zjw8d_banners`
--
ALTER TABLE `zjw8d_banners`
 ADD PRIMARY KEY (`id`), ADD KEY `idx_state` (`state`), ADD KEY `idx_own_prefix` (`own_prefix`), ADD KEY `idx_metakey_prefix` (`metakey_prefix`), ADD KEY `idx_banner_catid` (`catid`), ADD KEY `idx_language` (`language`);

--
-- Indexes for table `zjw8d_banner_clients`
--
ALTER TABLE `zjw8d_banner_clients`
 ADD PRIMARY KEY (`id`), ADD KEY `idx_own_prefix` (`own_prefix`), ADD KEY `idx_metakey_prefix` (`metakey_prefix`);

--
-- Indexes for table `zjw8d_banner_tracks`
--
ALTER TABLE `zjw8d_banner_tracks`
 ADD PRIMARY KEY (`track_date`,`track_type`,`banner_id`), ADD KEY `idx_track_date` (`track_date`), ADD KEY `idx_track_type` (`track_type`), ADD KEY `idx_banner_id` (`banner_id`);

--
-- Indexes for table `zjw8d_categories`
--
ALTER TABLE `zjw8d_categories`
 ADD PRIMARY KEY (`id`), ADD KEY `cat_idx` (`extension`,`published`,`access`), ADD KEY `idx_access` (`access`), ADD KEY `idx_checkout` (`checked_out`), ADD KEY `idx_path` (`path`), ADD KEY `idx_left_right` (`lft`,`rgt`), ADD KEY `idx_alias` (`alias`), ADD KEY `idx_language` (`language`);

--
-- Indexes for table `zjw8d_cmc_lists`
--
ALTER TABLE `zjw8d_cmc_lists`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zjw8d_cmc_register`
--
ALTER TABLE `zjw8d_cmc_register`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zjw8d_cmc_users`
--
ALTER TABLE `zjw8d_cmc_users`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zjw8d_contact_details`
--
ALTER TABLE `zjw8d_contact_details`
 ADD PRIMARY KEY (`id`), ADD KEY `idx_access` (`access`), ADD KEY `idx_checkout` (`checked_out`), ADD KEY `idx_state` (`published`), ADD KEY `idx_catid` (`catid`), ADD KEY `idx_createdby` (`created_by`), ADD KEY `idx_featured_catid` (`featured`,`catid`), ADD KEY `idx_language` (`language`), ADD KEY `idx_xreference` (`xreference`);

--
-- Indexes for table `zjw8d_content`
--
ALTER TABLE `zjw8d_content`
 ADD PRIMARY KEY (`id`), ADD KEY `idx_access` (`access`), ADD KEY `idx_checkout` (`checked_out`), ADD KEY `idx_state` (`state`), ADD KEY `idx_catid` (`catid`), ADD KEY `idx_createdby` (`created_by`), ADD KEY `idx_featured_catid` (`featured`,`catid`), ADD KEY `idx_language` (`language`), ADD KEY `idx_xreference` (`xreference`);

--
-- Indexes for table `zjw8d_contentitem_tag_map`
--
ALTER TABLE `zjw8d_contentitem_tag_map`
 ADD UNIQUE KEY `uc_ItemnameTagid` (`type_id`,`content_item_id`,`tag_id`), ADD KEY `idx_tag_type` (`tag_id`,`type_id`), ADD KEY `idx_date_id` (`tag_date`,`tag_id`), ADD KEY `idx_tag` (`tag_id`), ADD KEY `idx_type` (`type_id`), ADD KEY `idx_core_content_id` (`core_content_id`);

--
-- Indexes for table `zjw8d_content_frontpage`
--
ALTER TABLE `zjw8d_content_frontpage`
 ADD PRIMARY KEY (`content_id`);

--
-- Indexes for table `zjw8d_content_rating`
--
ALTER TABLE `zjw8d_content_rating`
 ADD PRIMARY KEY (`content_id`);

--
-- Indexes for table `zjw8d_content_types`
--
ALTER TABLE `zjw8d_content_types`
 ADD PRIMARY KEY (`type_id`), ADD KEY `idx_alias` (`type_alias`);

--
-- Indexes for table `zjw8d_extensions`
--
ALTER TABLE `zjw8d_extensions`
 ADD PRIMARY KEY (`extension_id`), ADD KEY `element_clientid` (`element`,`client_id`), ADD KEY `element_folder_clientid` (`element`,`folder`,`client_id`), ADD KEY `extension` (`type`,`element`,`folder`,`client_id`);

--
-- Indexes for table `zjw8d_finder_filters`
--
ALTER TABLE `zjw8d_finder_filters`
 ADD PRIMARY KEY (`filter_id`);

--
-- Indexes for table `zjw8d_finder_links`
--
ALTER TABLE `zjw8d_finder_links`
 ADD PRIMARY KEY (`link_id`), ADD KEY `idx_type` (`type_id`), ADD KEY `idx_title` (`title`), ADD KEY `idx_md5` (`md5sum`), ADD KEY `idx_url` (`url`(75)), ADD KEY `idx_published_list` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`list_price`), ADD KEY `idx_published_sale` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`sale_price`);

--
-- Indexes for table `zjw8d_finder_links_terms0`
--
ALTER TABLE `zjw8d_finder_links_terms0`
 ADD PRIMARY KEY (`link_id`,`term_id`), ADD KEY `idx_term_weight` (`term_id`,`weight`), ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Indexes for table `zjw8d_finder_links_terms1`
--
ALTER TABLE `zjw8d_finder_links_terms1`
 ADD PRIMARY KEY (`link_id`,`term_id`), ADD KEY `idx_term_weight` (`term_id`,`weight`), ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Indexes for table `zjw8d_finder_links_terms2`
--
ALTER TABLE `zjw8d_finder_links_terms2`
 ADD PRIMARY KEY (`link_id`,`term_id`), ADD KEY `idx_term_weight` (`term_id`,`weight`), ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Indexes for table `zjw8d_finder_links_terms3`
--
ALTER TABLE `zjw8d_finder_links_terms3`
 ADD PRIMARY KEY (`link_id`,`term_id`), ADD KEY `idx_term_weight` (`term_id`,`weight`), ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Indexes for table `zjw8d_finder_links_terms4`
--
ALTER TABLE `zjw8d_finder_links_terms4`
 ADD PRIMARY KEY (`link_id`,`term_id`), ADD KEY `idx_term_weight` (`term_id`,`weight`), ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Indexes for table `zjw8d_finder_links_terms5`
--
ALTER TABLE `zjw8d_finder_links_terms5`
 ADD PRIMARY KEY (`link_id`,`term_id`), ADD KEY `idx_term_weight` (`term_id`,`weight`), ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Indexes for table `zjw8d_finder_links_terms6`
--
ALTER TABLE `zjw8d_finder_links_terms6`
 ADD PRIMARY KEY (`link_id`,`term_id`), ADD KEY `idx_term_weight` (`term_id`,`weight`), ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Indexes for table `zjw8d_finder_links_terms7`
--
ALTER TABLE `zjw8d_finder_links_terms7`
 ADD PRIMARY KEY (`link_id`,`term_id`), ADD KEY `idx_term_weight` (`term_id`,`weight`), ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Indexes for table `zjw8d_finder_links_terms8`
--
ALTER TABLE `zjw8d_finder_links_terms8`
 ADD PRIMARY KEY (`link_id`,`term_id`), ADD KEY `idx_term_weight` (`term_id`,`weight`), ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Indexes for table `zjw8d_finder_links_terms9`
--
ALTER TABLE `zjw8d_finder_links_terms9`
 ADD PRIMARY KEY (`link_id`,`term_id`), ADD KEY `idx_term_weight` (`term_id`,`weight`), ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Indexes for table `zjw8d_finder_links_termsa`
--
ALTER TABLE `zjw8d_finder_links_termsa`
 ADD PRIMARY KEY (`link_id`,`term_id`), ADD KEY `idx_term_weight` (`term_id`,`weight`), ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Indexes for table `zjw8d_finder_links_termsb`
--
ALTER TABLE `zjw8d_finder_links_termsb`
 ADD PRIMARY KEY (`link_id`,`term_id`), ADD KEY `idx_term_weight` (`term_id`,`weight`), ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Indexes for table `zjw8d_finder_links_termsc`
--
ALTER TABLE `zjw8d_finder_links_termsc`
 ADD PRIMARY KEY (`link_id`,`term_id`), ADD KEY `idx_term_weight` (`term_id`,`weight`), ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Indexes for table `zjw8d_finder_links_termsd`
--
ALTER TABLE `zjw8d_finder_links_termsd`
 ADD PRIMARY KEY (`link_id`,`term_id`), ADD KEY `idx_term_weight` (`term_id`,`weight`), ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Indexes for table `zjw8d_finder_links_termse`
--
ALTER TABLE `zjw8d_finder_links_termse`
 ADD PRIMARY KEY (`link_id`,`term_id`), ADD KEY `idx_term_weight` (`term_id`,`weight`), ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Indexes for table `zjw8d_finder_links_termsf`
--
ALTER TABLE `zjw8d_finder_links_termsf`
 ADD PRIMARY KEY (`link_id`,`term_id`), ADD KEY `idx_term_weight` (`term_id`,`weight`), ADD KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`);

--
-- Indexes for table `zjw8d_finder_taxonomy`
--
ALTER TABLE `zjw8d_finder_taxonomy`
 ADD PRIMARY KEY (`id`), ADD KEY `parent_id` (`parent_id`), ADD KEY `state` (`state`), ADD KEY `ordering` (`ordering`), ADD KEY `access` (`access`), ADD KEY `idx_parent_published` (`parent_id`,`state`,`access`);

--
-- Indexes for table `zjw8d_finder_taxonomy_map`
--
ALTER TABLE `zjw8d_finder_taxonomy_map`
 ADD PRIMARY KEY (`link_id`,`node_id`), ADD KEY `link_id` (`link_id`), ADD KEY `node_id` (`node_id`);

--
-- Indexes for table `zjw8d_finder_terms`
--
ALTER TABLE `zjw8d_finder_terms`
 ADD PRIMARY KEY (`term_id`), ADD UNIQUE KEY `idx_term` (`term`), ADD KEY `idx_term_phrase` (`term`,`phrase`), ADD KEY `idx_stem_phrase` (`stem`,`phrase`), ADD KEY `idx_soundex_phrase` (`soundex`,`phrase`);

--
-- Indexes for table `zjw8d_finder_terms_common`
--
ALTER TABLE `zjw8d_finder_terms_common`
 ADD KEY `idx_word_lang` (`term`,`language`), ADD KEY `idx_lang` (`language`);

--
-- Indexes for table `zjw8d_finder_tokens`
--
ALTER TABLE `zjw8d_finder_tokens`
 ADD KEY `idx_word` (`term`), ADD KEY `idx_context` (`context`);

--
-- Indexes for table `zjw8d_finder_tokens_aggregate`
--
ALTER TABLE `zjw8d_finder_tokens_aggregate`
 ADD KEY `token` (`term`), ADD KEY `keyword_id` (`term_id`);

--
-- Indexes for table `zjw8d_finder_types`
--
ALTER TABLE `zjw8d_finder_types`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `title` (`title`);

--
-- Indexes for table `zjw8d_kunena_aliases`
--
ALTER TABLE `zjw8d_kunena_aliases`
 ADD UNIQUE KEY `alias` (`alias`), ADD KEY `state` (`state`), ADD KEY `item` (`item`), ADD KEY `type` (`type`);

--
-- Indexes for table `zjw8d_kunena_announcement`
--
ALTER TABLE `zjw8d_kunena_announcement`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zjw8d_kunena_attachments`
--
ALTER TABLE `zjw8d_kunena_attachments`
 ADD PRIMARY KEY (`id`), ADD KEY `mesid` (`mesid`), ADD KEY `userid` (`userid`), ADD KEY `hash` (`hash`), ADD KEY `filename` (`filename`);

--
-- Indexes for table `zjw8d_kunena_categories`
--
ALTER TABLE `zjw8d_kunena_categories`
 ADD PRIMARY KEY (`id`), ADD KEY `parent_id` (`parent_id`), ADD KEY `category_access` (`accesstype`,`access`), ADD KEY `published_pubaccess_id` (`published`,`pub_access`,`id`);

--
-- Indexes for table `zjw8d_kunena_configuration`
--
ALTER TABLE `zjw8d_kunena_configuration`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zjw8d_kunena_keywords`
--
ALTER TABLE `zjw8d_kunena_keywords`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `name` (`name`), ADD KEY `public_count` (`public_count`), ADD KEY `total_count` (`total_count`);

--
-- Indexes for table `zjw8d_kunena_keywords_map`
--
ALTER TABLE `zjw8d_kunena_keywords_map`
 ADD UNIQUE KEY `keyword_user_topic` (`keyword_id`,`user_id`,`topic_id`), ADD KEY `user_id` (`user_id`), ADD KEY `topic_user` (`topic_id`,`user_id`);

--
-- Indexes for table `zjw8d_kunena_messages`
--
ALTER TABLE `zjw8d_kunena_messages`
 ADD PRIMARY KEY (`id`), ADD KEY `thread` (`thread`), ADD KEY `ip` (`ip`), ADD KEY `userid` (`userid`), ADD KEY `time` (`time`), ADD KEY `locked` (`locked`), ADD KEY `hold_time` (`hold`,`time`), ADD KEY `parent_hits` (`parent`,`hits`), ADD KEY `catid_parent` (`catid`,`parent`);

--
-- Indexes for table `zjw8d_kunena_messages_text`
--
ALTER TABLE `zjw8d_kunena_messages_text`
 ADD PRIMARY KEY (`mesid`);

--
-- Indexes for table `zjw8d_kunena_polls`
--
ALTER TABLE `zjw8d_kunena_polls`
 ADD PRIMARY KEY (`id`), ADD KEY `threadid` (`threadid`);

--
-- Indexes for table `zjw8d_kunena_polls_options`
--
ALTER TABLE `zjw8d_kunena_polls_options`
 ADD PRIMARY KEY (`id`), ADD KEY `pollid` (`pollid`);

--
-- Indexes for table `zjw8d_kunena_polls_users`
--
ALTER TABLE `zjw8d_kunena_polls_users`
 ADD UNIQUE KEY `pollid` (`pollid`,`userid`);

--
-- Indexes for table `zjw8d_kunena_ranks`
--
ALTER TABLE `zjw8d_kunena_ranks`
 ADD PRIMARY KEY (`rank_id`);

--
-- Indexes for table `zjw8d_kunena_sessions`
--
ALTER TABLE `zjw8d_kunena_sessions`
 ADD PRIMARY KEY (`userid`), ADD KEY `currvisit` (`currvisit`);

--
-- Indexes for table `zjw8d_kunena_smileys`
--
ALTER TABLE `zjw8d_kunena_smileys`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zjw8d_kunena_thankyou`
--
ALTER TABLE `zjw8d_kunena_thankyou`
 ADD UNIQUE KEY `postid` (`postid`,`userid`), ADD KEY `userid` (`userid`), ADD KEY `targetuserid` (`targetuserid`);

--
-- Indexes for table `zjw8d_kunena_topics`
--
ALTER TABLE `zjw8d_kunena_topics`
 ADD PRIMARY KEY (`id`), ADD KEY `category_id` (`category_id`), ADD KEY `locked` (`locked`), ADD KEY `hold` (`hold`), ADD KEY `posts` (`posts`), ADD KEY `hits` (`hits`), ADD KEY `first_post_userid` (`first_post_userid`), ADD KEY `last_post_userid` (`last_post_userid`), ADD KEY `first_post_time` (`first_post_time`), ADD KEY `last_post_time` (`last_post_time`);

--
-- Indexes for table `zjw8d_kunena_users`
--
ALTER TABLE `zjw8d_kunena_users`
 ADD PRIMARY KEY (`userid`), ADD KEY `group_id` (`group_id`), ADD KEY `posts` (`posts`), ADD KEY `uhits` (`uhits`), ADD KEY `banned` (`banned`), ADD KEY `moderator` (`moderator`);

--
-- Indexes for table `zjw8d_kunena_users_banned`
--
ALTER TABLE `zjw8d_kunena_users_banned`
 ADD PRIMARY KEY (`id`), ADD KEY `userid` (`userid`), ADD KEY `ip` (`ip`), ADD KEY `expiration` (`expiration`), ADD KEY `created_time` (`created_time`);

--
-- Indexes for table `zjw8d_kunena_user_categories`
--
ALTER TABLE `zjw8d_kunena_user_categories`
 ADD PRIMARY KEY (`user_id`,`category_id`), ADD KEY `category_subscribed` (`category_id`,`subscribed`), ADD KEY `role` (`role`);

--
-- Indexes for table `zjw8d_kunena_user_read`
--
ALTER TABLE `zjw8d_kunena_user_read`
 ADD UNIQUE KEY `user_topic_id` (`user_id`,`topic_id`), ADD KEY `category_user_id` (`category_id`,`user_id`), ADD KEY `time` (`time`);

--
-- Indexes for table `zjw8d_kunena_user_topics`
--
ALTER TABLE `zjw8d_kunena_user_topics`
 ADD UNIQUE KEY `user_topic_id` (`user_id`,`topic_id`), ADD KEY `topic_id` (`topic_id`), ADD KEY `posts` (`posts`), ADD KEY `owner` (`owner`), ADD KEY `favorite` (`favorite`), ADD KEY `subscribed` (`subscribed`);

--
-- Indexes for table `zjw8d_kunena_version`
--
ALTER TABLE `zjw8d_kunena_version`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zjw8d_languages`
--
ALTER TABLE `zjw8d_languages`
 ADD PRIMARY KEY (`lang_id`), ADD UNIQUE KEY `idx_sef` (`sef`), ADD UNIQUE KEY `idx_image` (`image`), ADD UNIQUE KEY `idx_langcode` (`lang_code`), ADD KEY `idx_access` (`access`), ADD KEY `idx_ordering` (`ordering`);

--
-- Indexes for table `zjw8d_menu`
--
ALTER TABLE `zjw8d_menu`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `idx_client_id_parent_id_alias_language` (`client_id`,`parent_id`,`alias`,`language`), ADD KEY `idx_componentid` (`component_id`,`menutype`,`published`,`access`), ADD KEY `idx_menutype` (`menutype`), ADD KEY `idx_left_right` (`lft`,`rgt`), ADD KEY `idx_alias` (`alias`), ADD KEY `idx_path` (`path`(255)), ADD KEY `idx_language` (`language`);

--
-- Indexes for table `zjw8d_menu_types`
--
ALTER TABLE `zjw8d_menu_types`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `idx_menutype` (`menutype`);

--
-- Indexes for table `zjw8d_messages`
--
ALTER TABLE `zjw8d_messages`
 ADD PRIMARY KEY (`message_id`), ADD KEY `useridto_state` (`user_id_to`,`state`);

--
-- Indexes for table `zjw8d_messages_cfg`
--
ALTER TABLE `zjw8d_messages_cfg`
 ADD UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`);

--
-- Indexes for table `zjw8d_modules`
--
ALTER TABLE `zjw8d_modules`
 ADD PRIMARY KEY (`id`), ADD KEY `published` (`published`,`access`), ADD KEY `newsfeeds` (`module`,`published`), ADD KEY `idx_language` (`language`);

--
-- Indexes for table `zjw8d_modules_menu`
--
ALTER TABLE `zjw8d_modules_menu`
 ADD PRIMARY KEY (`moduleid`,`menuid`);

--
-- Indexes for table `zjw8d_newsfeeds`
--
ALTER TABLE `zjw8d_newsfeeds`
 ADD PRIMARY KEY (`id`), ADD KEY `idx_access` (`access`), ADD KEY `idx_checkout` (`checked_out`), ADD KEY `idx_state` (`published`), ADD KEY `idx_catid` (`catid`), ADD KEY `idx_createdby` (`created_by`), ADD KEY `idx_language` (`language`), ADD KEY `idx_xreference` (`xreference`);

--
-- Indexes for table `zjw8d_overrider`
--
ALTER TABLE `zjw8d_overrider`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zjw8d_postinstall_messages`
--
ALTER TABLE `zjw8d_postinstall_messages`
 ADD PRIMARY KEY (`postinstall_message_id`);

--
-- Indexes for table `zjw8d_redirect_links`
--
ALTER TABLE `zjw8d_redirect_links`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `idx_link_old` (`old_url`), ADD KEY `idx_link_modifed` (`modified_date`);

--
-- Indexes for table `zjw8d_schemas`
--
ALTER TABLE `zjw8d_schemas`
 ADD PRIMARY KEY (`extension_id`,`version_id`);

--
-- Indexes for table `zjw8d_session`
--
ALTER TABLE `zjw8d_session`
 ADD PRIMARY KEY (`session_id`), ADD KEY `userid` (`userid`), ADD KEY `time` (`time`);

--
-- Indexes for table `zjw8d_sh404sef_aliases`
--
ALTER TABLE `zjw8d_sh404sef_aliases`
 ADD PRIMARY KEY (`id`), ADD KEY `newurl` (`newurl`), ADD KEY `alias` (`alias`), ADD KEY `type` (`type`);

--
-- Indexes for table `zjw8d_sh404sef_metas`
--
ALTER TABLE `zjw8d_sh404sef_metas`
 ADD PRIMARY KEY (`id`), ADD KEY `newurl` (`newurl`);

--
-- Indexes for table `zjw8d_sh404sef_pageids`
--
ALTER TABLE `zjw8d_sh404sef_pageids`
 ADD PRIMARY KEY (`id`), ADD KEY `newurl` (`newurl`), ADD KEY `alias` (`pageid`), ADD KEY `type` (`type`);

--
-- Indexes for table `zjw8d_sh404sef_urls`
--
ALTER TABLE `zjw8d_sh404sef_urls`
 ADD PRIMARY KEY (`id`), ADD KEY `newurl` (`newurl`), ADD KEY `rank` (`rank`), ADD KEY `oldurl` (`oldurl`);

--
-- Indexes for table `zjw8d_shlib_consumers`
--
ALTER TABLE `zjw8d_shlib_consumers`
 ADD PRIMARY KEY (`id`), ADD KEY `idx_context` (`context`);

--
-- Indexes for table `zjw8d_shlib_resources`
--
ALTER TABLE `zjw8d_shlib_resources`
 ADD PRIMARY KEY (`id`), ADD KEY `idx_resource` (`resource`);

--
-- Indexes for table `zjw8d_tags`
--
ALTER TABLE `zjw8d_tags`
 ADD PRIMARY KEY (`id`), ADD KEY `tag_idx` (`published`,`access`), ADD KEY `idx_access` (`access`), ADD KEY `idx_checkout` (`checked_out`), ADD KEY `idx_path` (`path`), ADD KEY `idx_left_right` (`lft`,`rgt`), ADD KEY `idx_alias` (`alias`), ADD KEY `idx_language` (`language`);

--
-- Indexes for table `zjw8d_template_styles`
--
ALTER TABLE `zjw8d_template_styles`
 ADD PRIMARY KEY (`id`), ADD KEY `idx_template` (`template`), ADD KEY `idx_home` (`home`);

--
-- Indexes for table `zjw8d_ucm_base`
--
ALTER TABLE `zjw8d_ucm_base`
 ADD PRIMARY KEY (`ucm_id`), ADD KEY `idx_ucm_item_id` (`ucm_item_id`), ADD KEY `idx_ucm_type_id` (`ucm_type_id`), ADD KEY `idx_ucm_language_id` (`ucm_language_id`);

--
-- Indexes for table `zjw8d_ucm_content`
--
ALTER TABLE `zjw8d_ucm_content`
 ADD PRIMARY KEY (`core_content_id`), ADD KEY `tag_idx` (`core_state`,`core_access`), ADD KEY `idx_access` (`core_access`), ADD KEY `idx_alias` (`core_alias`), ADD KEY `idx_language` (`core_language`), ADD KEY `idx_title` (`core_title`), ADD KEY `idx_modified_time` (`core_modified_time`), ADD KEY `idx_created_time` (`core_created_time`), ADD KEY `idx_content_type` (`core_type_alias`), ADD KEY `idx_core_modified_user_id` (`core_modified_user_id`), ADD KEY `idx_core_checked_out_user_id` (`core_checked_out_user_id`), ADD KEY `idx_core_created_user_id` (`core_created_user_id`), ADD KEY `idx_core_type_id` (`core_type_id`);

--
-- Indexes for table `zjw8d_ucm_history`
--
ALTER TABLE `zjw8d_ucm_history`
 ADD PRIMARY KEY (`version_id`), ADD KEY `idx_ucm_item_id` (`ucm_type_id`,`ucm_item_id`), ADD KEY `idx_save_date` (`save_date`);

--
-- Indexes for table `zjw8d_updates`
--
ALTER TABLE `zjw8d_updates`
 ADD PRIMARY KEY (`update_id`);

--
-- Indexes for table `zjw8d_update_sites`
--
ALTER TABLE `zjw8d_update_sites`
 ADD PRIMARY KEY (`update_site_id`);

--
-- Indexes for table `zjw8d_update_sites_extensions`
--
ALTER TABLE `zjw8d_update_sites_extensions`
 ADD PRIMARY KEY (`update_site_id`,`extension_id`);

--
-- Indexes for table `zjw8d_usergroups`
--
ALTER TABLE `zjw8d_usergroups`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `idx_usergroup_parent_title_lookup` (`parent_id`,`title`), ADD KEY `idx_usergroup_title_lookup` (`title`), ADD KEY `idx_usergroup_adjacency_lookup` (`parent_id`), ADD KEY `idx_usergroup_nested_set_lookup` (`lft`,`rgt`) USING BTREE;

--
-- Indexes for table `zjw8d_users`
--
ALTER TABLE `zjw8d_users`
 ADD PRIMARY KEY (`id`), ADD KEY `idx_name` (`name`), ADD KEY `idx_block` (`block`), ADD KEY `username` (`username`), ADD KEY `email` (`email`);

--
-- Indexes for table `zjw8d_user_keys`
--
ALTER TABLE `zjw8d_user_keys`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `series` (`series`), ADD UNIQUE KEY `series_2` (`series`), ADD UNIQUE KEY `series_3` (`series`), ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `zjw8d_user_notes`
--
ALTER TABLE `zjw8d_user_notes`
 ADD PRIMARY KEY (`id`), ADD KEY `idx_user_id` (`user_id`), ADD KEY `idx_category_id` (`catid`);

--
-- Indexes for table `zjw8d_user_profiles`
--
ALTER TABLE `zjw8d_user_profiles`
 ADD UNIQUE KEY `idx_user_id_profile_key` (`user_id`,`profile_key`);

--
-- Indexes for table `zjw8d_user_usergroup_map`
--
ALTER TABLE `zjw8d_user_usergroup_map`
 ADD PRIMARY KEY (`user_id`,`group_id`);

--
-- Indexes for table `zjw8d_viewlevels`
--
ALTER TABLE `zjw8d_viewlevels`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `idx_assetgroup_title_lookup` (`title`);

--
-- Indexes for table `zjw8d_weblinks`
--
ALTER TABLE `zjw8d_weblinks`
 ADD PRIMARY KEY (`id`), ADD KEY `idx_access` (`access`), ADD KEY `idx_checkout` (`checked_out`), ADD KEY `idx_state` (`state`), ADD KEY `idx_catid` (`catid`), ADD KEY `idx_createdby` (`created_by`), ADD KEY `idx_featured_catid` (`featured`,`catid`), ADD KEY `idx_language` (`language`), ADD KEY `idx_xreference` (`xreference`);

--
-- Indexes for table `zjw8d_widgetkit_widget`
--
ALTER TABLE `zjw8d_widgetkit_widget`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zjw8d_zoo_application`
--
ALTER TABLE `zjw8d_zoo_application`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zjw8d_zoo_category`
--
ALTER TABLE `zjw8d_zoo_category`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `ALIAS_INDEX` (`alias`), ADD KEY `PUBLISHED_INDEX` (`published`), ADD KEY `APPLICATIONID_ID_INDEX` (`application_id`,`published`,`id`), ADD KEY `APPLICATIONID_ID_INDEX2` (`application_id`,`id`);

--
-- Indexes for table `zjw8d_zoo_category_item`
--
ALTER TABLE `zjw8d_zoo_category_item`
 ADD PRIMARY KEY (`category_id`,`item_id`), ADD KEY `ITEMID_INDEX` (`item_id`), ADD KEY `CATEGORYID_INDEX` (`category_id`);

--
-- Indexes for table `zjw8d_zoo_comment`
--
ALTER TABLE `zjw8d_zoo_comment`
 ADD PRIMARY KEY (`id`), ADD KEY `STATE_INDEX` (`state`), ADD KEY `CREATED_INDEX` (`created`), ADD KEY `ITEMID_INDEX` (`item_id`), ADD KEY `AUTHOR_INDEX` (`author`), ADD KEY `ITEMID_STATE_INDEX` (`item_id`,`state`);

--
-- Indexes for table `zjw8d_zoo_item`
--
ALTER TABLE `zjw8d_zoo_item`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `ALIAS_INDEX` (`alias`), ADD KEY `PUBLISH_INDEX` (`publish_up`,`publish_down`), ADD KEY `STATE_INDEX` (`state`), ADD KEY `ACCESS_INDEX` (`access`), ADD KEY `CREATED_BY_INDEX` (`created_by`), ADD KEY `NAME_INDEX` (`name`), ADD KEY `APPLICATIONID_INDEX` (`application_id`), ADD KEY `TYPE_INDEX` (`type`), ADD KEY `MULTI_INDEX` (`application_id`,`access`,`state`,`publish_up`,`publish_down`), ADD KEY `MULTI_INDEX2` (`id`,`access`,`state`,`publish_up`,`publish_down`), ADD KEY `ID_APPLICATION_INDEX` (`id`,`application_id`), ADD FULLTEXT KEY `SEARCH_FULLTEXT` (`name`);

--
-- Indexes for table `zjw8d_zoo_rating`
--
ALTER TABLE `zjw8d_zoo_rating`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zjw8d_zoo_search_index`
--
ALTER TABLE `zjw8d_zoo_search_index`
 ADD PRIMARY KEY (`item_id`,`element_id`), ADD FULLTEXT KEY `SEARCH_FULLTEXT` (`value`);

--
-- Indexes for table `zjw8d_zoo_submission`
--
ALTER TABLE `zjw8d_zoo_submission`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `ALIAS_INDEX` (`alias`);

--
-- Indexes for table `zjw8d_zoo_tag`
--
ALTER TABLE `zjw8d_zoo_tag`
 ADD PRIMARY KEY (`item_id`,`name`), ADD UNIQUE KEY `NAME_ITEMID_INDEX` (`name`,`item_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `zjw8d_assets`
--
ALTER TABLE `zjw8d_assets`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',AUTO_INCREMENT=84;
--
-- AUTO_INCREMENT for table `zjw8d_banners`
--
ALTER TABLE `zjw8d_banners`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_banner_clients`
--
ALTER TABLE `zjw8d_banner_clients`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_categories`
--
ALTER TABLE `zjw8d_categories`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `zjw8d_cmc_lists`
--
ALTER TABLE `zjw8d_cmc_lists`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_cmc_register`
--
ALTER TABLE `zjw8d_cmc_register`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_cmc_users`
--
ALTER TABLE `zjw8d_cmc_users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_contact_details`
--
ALTER TABLE `zjw8d_contact_details`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `zjw8d_content`
--
ALTER TABLE `zjw8d_content`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `zjw8d_content_types`
--
ALTER TABLE `zjw8d_content_types`
MODIFY `type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `zjw8d_extensions`
--
ALTER TABLE `zjw8d_extensions`
MODIFY `extension_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10094;
--
-- AUTO_INCREMENT for table `zjw8d_finder_filters`
--
ALTER TABLE `zjw8d_finder_filters`
MODIFY `filter_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_finder_links`
--
ALTER TABLE `zjw8d_finder_links`
MODIFY `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=59;
--
-- AUTO_INCREMENT for table `zjw8d_finder_taxonomy`
--
ALTER TABLE `zjw8d_finder_taxonomy`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `zjw8d_finder_terms`
--
ALTER TABLE `zjw8d_finder_terms`
MODIFY `term_id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4934;
--
-- AUTO_INCREMENT for table `zjw8d_finder_types`
--
ALTER TABLE `zjw8d_finder_types`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `zjw8d_kunena_announcement`
--
ALTER TABLE `zjw8d_kunena_announcement`
MODIFY `id` int(3) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_kunena_attachments`
--
ALTER TABLE `zjw8d_kunena_attachments`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_kunena_categories`
--
ALTER TABLE `zjw8d_kunena_categories`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=83;
--
-- AUTO_INCREMENT for table `zjw8d_kunena_keywords`
--
ALTER TABLE `zjw8d_kunena_keywords`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_kunena_messages`
--
ALTER TABLE `zjw8d_kunena_messages`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `zjw8d_kunena_polls`
--
ALTER TABLE `zjw8d_kunena_polls`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_kunena_polls_options`
--
ALTER TABLE `zjw8d_kunena_polls_options`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_kunena_ranks`
--
ALTER TABLE `zjw8d_kunena_ranks`
MODIFY `rank_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `zjw8d_kunena_smileys`
--
ALTER TABLE `zjw8d_kunena_smileys`
MODIFY `id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=67;
--
-- AUTO_INCREMENT for table `zjw8d_kunena_topics`
--
ALTER TABLE `zjw8d_kunena_topics`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `zjw8d_kunena_users_banned`
--
ALTER TABLE `zjw8d_kunena_users_banned`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_kunena_version`
--
ALTER TABLE `zjw8d_kunena_version`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `zjw8d_languages`
--
ALTER TABLE `zjw8d_languages`
MODIFY `lang_id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `zjw8d_menu`
--
ALTER TABLE `zjw8d_menu`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=269;
--
-- AUTO_INCREMENT for table `zjw8d_menu_types`
--
ALTER TABLE `zjw8d_menu_types`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `zjw8d_messages`
--
ALTER TABLE `zjw8d_messages`
MODIFY `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_modules`
--
ALTER TABLE `zjw8d_modules`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=132;
--
-- AUTO_INCREMENT for table `zjw8d_newsfeeds`
--
ALTER TABLE `zjw8d_newsfeeds`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_overrider`
--
ALTER TABLE `zjw8d_overrider`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key';
--
-- AUTO_INCREMENT for table `zjw8d_postinstall_messages`
--
ALTER TABLE `zjw8d_postinstall_messages`
MODIFY `postinstall_message_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `zjw8d_redirect_links`
--
ALTER TABLE `zjw8d_redirect_links`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `zjw8d_sh404sef_aliases`
--
ALTER TABLE `zjw8d_sh404sef_aliases`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_sh404sef_metas`
--
ALTER TABLE `zjw8d_sh404sef_metas`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_sh404sef_pageids`
--
ALTER TABLE `zjw8d_sh404sef_pageids`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_sh404sef_urls`
--
ALTER TABLE `zjw8d_sh404sef_urls`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_shlib_consumers`
--
ALTER TABLE `zjw8d_shlib_consumers`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `zjw8d_shlib_resources`
--
ALTER TABLE `zjw8d_shlib_resources`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `zjw8d_tags`
--
ALTER TABLE `zjw8d_tags`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `zjw8d_template_styles`
--
ALTER TABLE `zjw8d_template_styles`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `zjw8d_ucm_content`
--
ALTER TABLE `zjw8d_ucm_content`
MODIFY `core_content_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_ucm_history`
--
ALTER TABLE `zjw8d_ucm_history`
MODIFY `version_id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_updates`
--
ALTER TABLE `zjw8d_updates`
MODIFY `update_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `zjw8d_update_sites`
--
ALTER TABLE `zjw8d_update_sites`
MODIFY `update_site_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `zjw8d_usergroups`
--
ALTER TABLE `zjw8d_usergroups`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `zjw8d_users`
--
ALTER TABLE `zjw8d_users`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=586;
--
-- AUTO_INCREMENT for table `zjw8d_user_keys`
--
ALTER TABLE `zjw8d_user_keys`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_user_notes`
--
ALTER TABLE `zjw8d_user_notes`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `zjw8d_viewlevels`
--
ALTER TABLE `zjw8d_viewlevels`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `zjw8d_weblinks`
--
ALTER TABLE `zjw8d_weblinks`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `zjw8d_widgetkit_widget`
--
ALTER TABLE `zjw8d_widgetkit_widget`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=65;
--
-- AUTO_INCREMENT for table `zjw8d_zoo_application`
--
ALTER TABLE `zjw8d_zoo_application`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `zjw8d_zoo_category`
--
ALTER TABLE `zjw8d_zoo_category`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=62;
--
-- AUTO_INCREMENT for table `zjw8d_zoo_comment`
--
ALTER TABLE `zjw8d_zoo_comment`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `zjw8d_zoo_item`
--
ALTER TABLE `zjw8d_zoo_item`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `zjw8d_zoo_rating`
--
ALTER TABLE `zjw8d_zoo_rating`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `zjw8d_zoo_submission`
--
ALTER TABLE `zjw8d_zoo_submission`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
